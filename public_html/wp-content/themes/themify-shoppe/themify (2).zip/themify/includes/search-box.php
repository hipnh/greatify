<div class="search-lightbox-wrap tf_hide tf_w tf_scrollbar">
	<div class="search-lightbox">
		<div class="searchform-wrap">
			<?php get_search_form(); ?>
		</div>
		<!-- /searchform wrap -->
		<div class="search-results-wrap tf_rel"></div>
	</div>
	<a class="close-search-box tf_close" href="#"><span class="screen-reader-text"><?php _e('Close','themify'); ?></span></a>
</div>
<!-- /search-lightbox -->
