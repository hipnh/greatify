<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 2,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 3,
  'name' => 'simple',
  'slug' => 'simple',
  'term_group' => 0,
  'taxonomy' => 'product_type',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 17,
  'name' => 'Hair Treatment',
  'slug' => 'hair-treatment',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 18,
  'name' => 'Hair Vitamin',
  'slug' => 'hair-vitamin',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 19,
  'name' => 'Styling Gel',
  'slug' => 'styling-gel',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 20,
  'name' => 'Beard Oil',
  'slug' => 'beard-oil',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 142,
  'post_date' => '2021-10-01 06:40:45',
  'post_date_gmt' => '2021-10-01 06:40:45',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>About Ultra Salon</h1> <p>Found in 2010, we\'ve been providing salon &amp; spa services to more than 20k happy customers.</p>
<img loading="lazy" width="1158" height="600" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/about-profile.jpg" title="about-profile" alt="about-profile" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/about-profile.jpg 1158w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/about-profile-600x311.jpg 600w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/about-profile-768x398.jpg 768w" sizes="(max-width: 1158px) 100vw, 1158px" />
<img loading="lazy" width="495" height="600" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/flawless.jpg" title="flawless" alt="flawless">
<h2>Prepare to be pampered at our salon. Freshen yourself with a relaxing salon &amp; spa experience.</h2>
<h3>10+</h3> <p>Years of experience</p>
<ul> <li>Hair cuts</li> <li>Coloring</li> <li>Treatments</li> <li>Make-up</li> </ul>
<h3>20k+</h3> <p>Happy customers</p>
<ul> <li>Beauty spa</li> <li>Facial</li> <li>Nails</li> <li>Barber services</li> </ul>
<h2>Top hair stylists &amp; make-up artists</h2> <p>Our team of stylists and artists are top notch in the field. We listen to your requests, assess your image, and achieve the best look to your desire. Book your appointment now to experience the ultra salon services.</p>
<img loading="lazy" width="267" height="280" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/artist-1.jpg" title="Sandy Isbell" alt="Hair Stylist"> <h3> Sandy Isbell </h3> Hair Stylist
<img loading="lazy" width="267" height="280" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/artist-2.jpg" title="Celine Li" alt="Hair Stylist"> <h3> Celine Li </h3> Hair Stylist
<img loading="lazy" width="267" height="280" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/artist-3.jpg" title="Sara" alt="Makeup Artist"> <h3> Sara </h3> Makeup Artist
<img loading="lazy" width="267" height="280" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/artist-4.jpg" title="Shawn" alt="Barber"> <h3> Shawn </h3> Barber
<h4>BOOK AN APPOINTMENT</h4> <h2>312-234-5789</h2> <p style="color: #494949; font-family: Quicksand, sans-serif; font-size: 16px; font-weight: 400; letter-spacing: normal; text-transform: none;">4096 North Street<br>New York City, NY</p> <p style="color: #494949; font-family: Quicksand, sans-serif; font-size: 16px; font-weight: 400; letter-spacing: normal; text-transform: none;">MON - FRI 11:00 am -  8:00 pm<br>SAT &amp; SUN 11:00 am -  9:00 pm</p>
<form action="https://themify.me/demo/themes/shoppe-salon/wp-admin/admin-ajax.php" class="builder-contact" id="tb_pq4o13-form" method="post" data-post-id="0" data-element-id="pq4o13" data-orig-id="" > <label for="tb_pq4o13-contact-name"></label> <input type="text" name="contact-name" placeholder="Enter Name" id="tb_pq4o13-contact-name" value="" required> <label for="tb_pq4o13-contact-email"></label> <input type="text" name="contact-email" placeholder="Type e-mail address" id="tb_pq4o13-contact-email" value="" required> <label for="field_extra_tb_pq4o13_0"> <input type="hidden" name="field_extra_name_0" value=""> </label> <input type="text" name="field_extra_0" id="field_extra_tb_pq4o13_0" placeholder="Phone Number"> <label for="tb_pq4o13-contact-message"></label> <textarea name="contact-message" placeholder="Write a Message" id="tb_pq4o13-contact-message" required></textarea> <button type="submit">Send Message</button> </form><!--/themify_builder_static-->',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2021-10-05 12:14:31',
  'post_modified_gmt' => '2021-10-05 12:14:31',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?page_id=142',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"195c997\\",\\"cols\\":[{\\"element_id\\":\\"q8ap0\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0b8r1\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>About Ultra Salon<\\\\/h1>\\\\n<p>Found in 2010, we\\\'ve been providing salon &amp; spa services to more than 20k happy customers.<\\\\/p>\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"gyhi1\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/about-profile.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"animation_effect\\":\\"fadeInUp\\"}},{\\"element_id\\":\\"w1m51\\",\\"cols\\":[{\\"element_id\\":\\"ptp01\\",\\"grid_class\\":\\"col-full\\"}]}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"4\\",\\"padding_top\\":\\"8\\"}},{\\"element_id\\":\\"c7l8998\\",\\"cols\\":[{\\"element_id\\":\\"tzs24\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"xowo4\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/flawless.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false},\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}}}}]},{\\"element_id\\":\\"hr4w5\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"utez6\\",\\"cols\\":[{\\"element_id\\":\\"jxym6\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"aqlm7\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Prepare to be pampered at our salon. Freshen yourself with a relaxing salon &amp; spa experience.<\\\\/h2>\\"}}]}]},{\\"element_id\\":\\"jpwn7\\",\\"cols\\":[{\\"element_id\\":\\"iuha7\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"vujt8\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>10+<\\\\/h3>\\\\n<p>Years of experience<\\\\/p>\\",\\"h3_margin_bottom\\":\\"0\\",\\"font_size_h3\\":\\"80\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"1\\",\\"margin_bottom\\":\\"10\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"gu3i8\\",\\"mod_settings\\":{\\"content_text\\":\\"<ul>\\\\n<li>Hair cuts<\\\\/li>\\\\n<li>Coloring<\\\\/li>\\\\n<li>Treatments<\\\\/li>\\\\n<li>Make-up<\\\\/li>\\\\n<\\\\/ul>\\"}}]},{\\"element_id\\":\\"73k18\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"veud8\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>20k+<\\\\/h3>\\\\n<p>Happy customers<\\\\/p>\\",\\"h3_margin_bottom\\":\\"0\\",\\"font_size_h3\\":\\"80\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"1\\",\\"margin_bottom\\":\\"10\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"gsqo8\\",\\"mod_settings\\":{\\"content_text\\":\\"<ul>\\\\n<li>Beauty spa<\\\\/li>\\\\n<li>Facial<\\\\/li>\\\\n<li>Nails<\\\\/li>\\\\n<li>Barber services<\\\\/li>\\\\n<\\\\/ul>\\"}}]}],\\"col_mobile\\":\\"column4-2\\"}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"4\\",\\"padding_top\\":\\"4\\"}},{\\"element_id\\":\\"17kf998\\",\\"cols\\":[{\\"element_id\\":\\"8ufr9\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"1w459\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Top hair stylists &amp; make-up artists<\\\\/h2>\\\\n<p>Our team of stylists and artists are top notch in the field. We listen to your requests, assess your image, and achieve the best look to your desire. <span style=\\\\\\"background-color: initial; font-size: 1em;\\\\\\">Book your appointment now to experience the ultra salon services.<\\\\/span><\\\\/p>\\"}}],\\"styling\\":{\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"6\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_right\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}}},{\\"element_id\\":\\"lgo79\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"1izl9\\",\\"cols\\":[{\\"element_id\\":\\"tj3g10\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"f5jj10\\",\\"mod_settings\\":{\\"caption_image\\":\\"Hair Stylist\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Sandy Isbell\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/artist-1.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_bottom\\":false,\\"title_margin_top\\":\\"10\\",\\"font_size_title_unit\\":\\"em\\",\\"font_size_title\\":\\"1.2\\",\\"title_margin_bottom\\":\\"0\\",\\"animation_effect\\":\\"fadeInUp\\"}}]},{\\"element_id\\":\\"ayx310\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"lauw11\\",\\"mod_settings\\":{\\"caption_image\\":\\"Hair Stylist\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Celine Li\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/artist-2.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_bottom\\":false,\\"title_margin_top\\":\\"10\\",\\"font_size_title_unit\\":\\"em\\",\\"font_size_title\\":\\"1.2\\",\\"title_margin_bottom\\":\\"0\\",\\"animation_effect\\":\\"fadeInUp\\"}}]}],\\"col_mobile\\":\\"column4-2\\"},{\\"element_id\\":\\"l82a11\\",\\"cols\\":[{\\"element_id\\":\\"9k1011\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"616b12\\",\\"mod_settings\\":{\\"caption_image\\":\\"Makeup Artist\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Sara\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/artist-3.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_bottom\\":false,\\"title_margin_top\\":\\"10\\",\\"font_size_title_unit\\":\\"em\\",\\"font_size_title\\":\\"1.2\\",\\"title_margin_bottom\\":\\"0\\",\\"animation_effect\\":\\"fadeInUp\\"}}]},{\\"element_id\\":\\"dmm812\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"5gh712\\",\\"mod_settings\\":{\\"caption_image\\":\\"Barber\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Shawn\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/artist-4.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"title_margin_opp_left\\":false,\\"title_margin_opp_bottom\\":false,\\"title_margin_top\\":\\"10\\",\\"font_size_title_unit\\":\\"em\\",\\"font_size_title\\":\\"1.2\\",\\"title_margin_bottom\\":\\"0\\",\\"animation_effect\\":\\"fadeInUp\\"}}]}],\\"col_mobile\\":\\"column4-2\\"}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"4\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"4\\"}},{\\"element_id\\":\\"ewqt998\\",\\"cols\\":[{\\"element_id\\":\\"7ov212\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"niqo12\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>BOOK AN APPOINTMENT<\\\\/h4>\\\\n<h2>312-234-5789<\\\\/h2>\\\\n<p style=\\\\\\"color: #494949; font-family: Quicksand, sans-serif; font-size: 16px; font-weight: 400; letter-spacing: normal; text-transform: none;\\\\\\">4096 North Street<br>New York City, NY<\\\\/p>\\\\n<p style=\\\\\\"color: #494949; font-family: Quicksand, sans-serif; font-size: 16px; font-weight: 400; letter-spacing: normal; text-transform: none;\\\\\\">MON - FRI 11:00 am -  8:00 pm<br>SAT &amp; SUN 11:00 am -  9:00 pm<\\\\/p>\\",\\"margin_bottom\\":\\"50\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"17\\"}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_top\\":\\"10\\"}},{\\"element_id\\":\\"6jtc12\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"pq4o13\\",\\"mod_settings\\":{\\"field_subject_label\\":\\"Subject\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_sendcopy_subject\\":\\"COPY:\\",\\"field_send_label\\":\\"Send Message\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"field_name_require\\":\\"yes\\",\\"field_email_require\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_email_active\\":\\"yes\\",\\"field_subject_active\\":false,\\"field_subject_require\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_extra\\":\\"{\\\\\\"fields\\\\\\":[{\\\\\\"type\\\\\\":\\\\\\"text\\\\\\",\\\\\\"order\\\\\\":3,\\\\\\"id\\\\\\":\\\\\\"ex3\\\\\\",\\\\\\"value\\\\\\":\\\\\\"Phone Number\\\\\\"}]}\\",\\"field_order\\":\\"{\\\\\\"field_name_label\\\\\\":0,\\\\\\"field_email_label\\\\\\":1,\\\\\\"field_subject_label\\\\\\":2,\\\\\\"field_message_label\\\\\\":4}\\",\\"field_optin_label\\":\\"Subscribe to my newsletter.\\",\\"field_optin_active\\":false,\\"provider\\":\\"mailchimp\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"field_message_placeholder\\":\\"Write a Message\\",\\"field_email_placeholder\\":\\"Type e-mail address\\",\\"field_name_placeholder\\":\\"Enter Name\\",\\"include_name_mail\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"user_role\\":\\"admin\\",\\"send_to_admins\\":\\"true\\",\\"layout_contact\\":\\"style1\\",\\"checkbox_r_c_sd_apply_all\\":\\"1\\",\\"r_c_sd_opp_left\\":false,\\"r_c_sd_opp_top\\":false,\\"r_c_sd_top\\":\\"0\\",\\"p_sd_right\\":\\"34\\",\\"p_sd_left\\":\\"34\\",\\"p_sd_opp_left\\":\\"1\\",\\"p_sd_bottom\\":\\"19\\",\\"p_sd_opp_bottom\\":\\"1\\",\\"p_sd_top\\":\\"19\\",\\"background_color_send_h\\":\\"#8d5822\\",\\"background_color_send\\":\\"#000000\\",\\"checkbox_in_r_c_apply_all\\":\\"1\\",\\"in_r_c_opp_left\\":false,\\"in_r_c_opp_top\\":false,\\"in_r_c_top\\":\\"0\\",\\"border_inputs-type\\":\\"left\\",\\"font_color_send\\":\\"#ffffff\\"}}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"}}],\\"styling\\":{\\"border_inner-type\\":\\"top\\",\\"checkbox_padding_inner_apply_all\\":\\"1\\",\\"padding_inner_opp_left\\":false,\\"padding_inner_opp_bottom\\":false,\\"background_position_inner\\":\\"0,0\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_repeat_inner\\":\\"repeat-none\\",\\"background_image_inner\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/circle-bg.png\\",\\"padding_bottom\\":8,\\"padding_bottom_unit\\":\\"%\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 148,
  'post_date' => '2021-10-01 06:43:17',
  'post_date_gmt' => '2021-10-01 06:43:17',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Contact</h1>
<h5>Shop Location</h5> <p>4096 North Street<br>New York City, NY</p>
<h5>Call Us</h5> <p><a href="tel:416-233-4499">416-233-4499</a></p>
<h5>Email Us</h5> <p><a href="mailto:hello@ultrasalon.com">hello@ultrasalon.com</a></p>
<img loading="lazy" width="1158" height="520" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/contact-img.jpg" title="contact-img" alt="contact-img" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/contact-img.jpg 1158w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/contact-img-600x269.jpg 600w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/contact-img-768x345.jpg 768w" sizes="(max-width: 1158px) 100vw, 1158px" />
<h4>Business Hours</h4> <p>MON – FRI 11:00 am –  8:00 pm<br>SAT &amp; SUN 11:00 am –  9:00 pm</p>
<img loading="lazy" width="663" height="689" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/map-sketch.png" title="map-sketch" alt="map-sketch" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/map-sketch.png 663w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/map-sketch-577x600.png 577w" sizes="(max-width: 663px) 100vw, 663px" />
<h3>Book an Appointment</h3> <form action="https://themify.me/demo/themes/shoppe-salon/wp-admin/admin-ajax.php" class="builder-contact" id="tb_bm30585-form" method="post" data-post-id="0" data-element-id="bm30585" data-orig-id="" > <label for="tb_bm30585-contact-name"></label> <input type="text" name="contact-name" placeholder="Enter Name" id="tb_bm30585-contact-name" value="" required> <label for="tb_bm30585-contact-email"></label> <input type="text" name="contact-email" placeholder="Type e-mail address" id="tb_bm30585-contact-email" value="" required> <label for="tb_bm30585-contact-message"></label> <textarea name="contact-message" placeholder="Write Message" id="tb_bm30585-contact-message" required></textarea> <button type="submit">Send Message</button> </form>
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/pexels-samantha-kandinsky-6470305-364x364.jpg" width="364" height="364" title="pexels-samantha-kandinsky-6470305" alt="pexels-samantha-kandinsky-6470305" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/pexels-samantha-kandinsky-6470305.jpg 364w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/pexels-samantha-kandinsky-6470305-150x150.jpg 150w" sizes="(max-width: 364px) 100vw, 364px" />
<h2>For Her</h2>
<p>Hair Cuts</p> <p>Nails</p> <p>Make-up</p> <p>Spa</p> <p>Facial</p> <p>Massage</p>
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/barber-cut-364x364.jpg" width="364" height="364" title="barber-cut" alt="barber-cut" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/barber-cut-364x364.jpg 364w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/barber-cut-150x150.jpg 150w" sizes="(max-width: 364px) 100vw, 364px" />
<h2>For Him</h2>
<p>Hair Cut</p> <p>Bread Shave</p> <p>Waxing</p> <p>Hair Cut</p> <p>Bread Shave</p> <p>Waxing</p><!--/themify_builder_static-->',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2021-10-05 12:19:40',
  'post_modified_gmt' => '2021-10-05 12:19:40',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?page_id=148',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"35bh578\\",\\"cols\\":[{\\"element_id\\":\\"evzi580\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"p7e2580\\",\\"cols\\":[{\\"element_id\\":\\"fr3x580\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ygcp580\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Contact<\\\\/h1>\\",\\"margin_bottom\\":\\"20\\"}}]}]},{\\"element_id\\":\\"x7bw582\\",\\"cols\\":[{\\"element_id\\":\\"cayd582\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"5lia582\\",\\"mod_settings\\":{\\"content_text\\":\\"<h5>Shop Location<\\\\/h5>\\\\n<p>4096 North Street<br>New York City, NY<\\\\/p>\\",\\"margin_bottom\\":\\"20\\"}}]},{\\"element_id\\":\\"qi35582\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"3ddc582\\",\\"mod_settings\\":{\\"content_text\\":\\"<h5>Call Us<\\\\/h5>\\\\n<p><a href=\\\\\\"tel:416-233-4499\\\\\\">416-233-4499<\\\\/a><\\\\/p>\\"}}]},{\\"element_id\\":\\"s03c582\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"h68z583\\",\\"mod_settings\\":{\\"content_text\\":\\"<h5>Email Us<\\\\/h5>\\\\n<p><a href=\\\\\\"mailto:hello@ultrasalon.com\\\\\\">hello@ultrasalon.com<\\\\/a><\\\\/p>\\",\\"margin_bottom\\":\\"20\\"}}]}]},{\\"element_id\\":\\"0he4583\\",\\"cols\\":[{\\"element_id\\":\\"9wku583\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"sdsd583\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/contact-img.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]}]},{\\"element_id\\":\\"d55j583\\",\\"cols\\":[{\\"element_id\\":\\"tz54584\\",\\"grid_class\\":\\"col3-1\\"},{\\"element_id\\":\\"bfcm584\\",\\"grid_class\\":\\"col3-1\\"},{\\"element_id\\":\\"1fvh584\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"vw8f584\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Business Hours<\\\\/h4>\\\\n<p>MON – FRI 11:00 am –  8:00 pm<br>SAT &amp; SUN 11:00 am –  9:00 pm<\\\\/p>\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":\\"1\\",\\"font_color\\":\\"#ffffff\\",\\"font_color_type\\":\\"font_color_solid\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#8d5822\\",\\"background_image-type\\":\\"image\\",\\"padding_right\\":\\"25\\",\\"padding_left\\":\\"25\\",\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\".9\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}}}}],\\"styling\\":{\\"padding_right\\":\\"35\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_right\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false},\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_right\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}}}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet\\":\\"column-full\\",\\"styling\\":{\\"margin_top\\":\\"-80\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"margin_top\\":\\"0\\"}}}]}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"}},{\\"element_id\\":\\"wseo578\\",\\"cols\\":[{\\"element_id\\":\\"ckpm584\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"rfvv584\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/map-sketch.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]},{\\"element_id\\":\\"5g9w585\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"bm30585\\",\\"mod_settings\\":{\\"field_subject_label\\":\\"Subject\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_sendcopy_subject\\":\\"COPY:\\",\\"field_send_label\\":\\"Send Message\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"field_name_require\\":\\"yes\\",\\"field_email_require\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_email_active\\":\\"yes\\",\\"field_subject_active\\":false,\\"field_subject_require\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_extra\\":\\"{\\\\\\"fields\\\\\\":[]}\\",\\"field_order\\":\\"{\\\\\\"field_name_label\\\\\\":0,\\\\\\"field_email_label\\\\\\":1,\\\\\\"field_subject_label\\\\\\":2,\\\\\\"field_message_label\\\\\\":3}\\",\\"field_optin_label\\":\\"Subscribe to my newsletter.\\",\\"field_optin_active\\":false,\\"provider\\":\\"mailchimp\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"field_message_placeholder\\":\\"Write Message\\",\\"field_email_placeholder\\":\\"Type e-mail address\\",\\"field_name_placeholder\\":\\"Enter Name\\",\\"include_name_mail\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"user_role\\":\\"admin\\",\\"send_to_admins\\":false,\\"layout_contact\\":\\"style1\\",\\"p_sd_right\\":\\"36\\",\\"p_sd_left\\":\\"36\\",\\"p_sd_opp_left\\":\\"1\\",\\"p_sd_bottom\\":\\"19\\",\\"p_sd_opp_bottom\\":\\"1\\",\\"p_sd_top\\":\\"19\\",\\"font_color_send\\":\\"#ffffff\\",\\"background_color_send_h\\":\\"#8d5822\\",\\"background_color_send\\":\\"#000000\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\",\\"background_color\\":\\"#ffffff\\",\\"mod_title_contact\\":\\"Book an Appointment\\",\\"font_size_module_title\\":\\"30\\",\\"b_sh_color\\":\\"#000000_0.05\\",\\"b_sh_spread\\":\\"1\\",\\"b_sh_blur\\":\\"10\\",\\"b_sh_vOffset\\":\\"2\\",\\"b_sh_hOffset\\":\\"0\\",\\"in_m_opp_left\\":false,\\"in_m_bottom\\":\\"0\\",\\"in_m_opp_bottom\\":false,\\"margin_left\\":\\"-90\\",\\"w_auto_width\\":false,\\"w_unit\\":\\"px\\",\\"breakpoint_mobile\\":{\\"w_auto_width\\":false,\\"w_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"template\\":\\"From: %name% @ %email%<br>\\\\n<b>Subject:<\\\\/b> %subject%\\\\n\\\\n%message%\\\\n<br>Sent from: %referer%<br>\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_top\\":\\"8\\"}},{\\"element_id\\":\\"l4cm578\\",\\"cols\\":[{\\"element_id\\":\\"e6td585\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"wphv585\\",\\"cols\\":[{\\"element_id\\":\\"u4ip585\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"4q22585\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"circle\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/pexels-samantha-kandinsky-6470305.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"364\\",\\"width_image\\":\\"364\\",\\"animation_effect\\":\\"fadeInLeft\\"}}],\\"styling\\":{\\"text_align\\":\\"right\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\"}},{\\"element_id\\":\\"8uy0585\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"yibf586\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>For Her<\\\\/h2>\\",\\"column_count\\":\\"0\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"rv4f586\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Hair Cuts<\\\\/p>\\\\n<p>Nails<\\\\/p>\\\\n<p>Make-up<\\\\/p>\\\\n<p><span style=\\\\\\"background-color: initial; font-size: 1em;\\\\\\">Spa<\\\\/span><\\\\/p>\\\\n<p><span style=\\\\\\"background-color: initial; font-size: 1em;\\\\\\">Facial<\\\\/span><\\\\/p>\\\\n<p>Massage<\\\\/p>\\",\\"column_count\\":\\"2\\",\\"margin_bottom_unit\\":\\"em\\",\\"margin_bottom\\":\\"1\\",\\"p_margin_bottom\\":\\"5\\",\\"text_transform\\":\\"uppercase\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_right\\":\\"30\\",\\"padding_left\\":\\"30\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":8,\\"padding_top\\":\\"2.3\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"breakpoint_mobile\\":{\\"padding_bottom\\":8,\\"padding_bottom_unit\\":\\"%\\"}}},{\\"element_id\\":\\"lyim586\\",\\"cols\\":[{\\"element_id\\":\\"o9pv586\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"uyza586\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"circle\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/barber-cut-364x364.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"364\\",\\"width_image\\":\\"364\\",\\"animation_effect\\":\\"fadeInRight\\"}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false},\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}}},{\\"element_id\\":\\"jhxm586\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"kxh0586\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>For Him<\\\\/h2>\\",\\"column_count\\":\\"0\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"3kte586\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Hair Cut<\\\\/p>\\\\n<p>Bread Shave<\\\\/p>\\\\n<p>Waxing<\\\\/p>\\\\n<p>Hair Cut<\\\\/p>\\\\n<p>Bread Shave<\\\\/p>\\\\n<p>Waxing<\\\\/p>\\",\\"column_count\\":\\"2\\",\\"margin_bottom_unit\\":\\"em\\",\\"margin_bottom\\":\\"1\\",\\"p_margin_bottom\\":\\"5\\",\\"text_transform\\":\\"uppercase\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"desktop_dir\\":\\"rtl\\",\\"tablet_dir\\":\\"rtl\\",\\"tablet_landscape_dir\\":\\"rtl\\",\\"styling\\":{\\"padding_right\\":\\"30\\",\\"padding_left\\":\\"30\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":12,\\"padding_top\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"breakpoint_mobile\\":{\\"padding_bottom\\":8,\\"padding_bottom_unit\\":\\"%\\"}}}]}],\\"column_alignment\\":\\"col_align_middle\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 139,
  'post_date' => '2021-10-01 06:39:52',
  'post_date_gmt' => '2021-10-01 06:39:52',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>It is more than just a cut &amp; style</h1>
<p>Ultra Salon is a full service hair salon and spa located in NYC. Come visit us for a relaxing yet luxurious experience. </p>
<a href="https://themify.me/" > Book Now </a>
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/hero-home-1000x743.jpg" width="1000" height="743" title="hero-home" alt="hero-home" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/hero-home-1000x743.jpg 1000w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/hero-home-600x446.jpg 600w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/hero-home-768x571.jpg 768w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/hero-home.jpg 1116w" sizes="(max-width: 1000px) 100vw, 1000px" />
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/woman-stylist-310x437.jpg" width="310" height="437" title="woman-stylist" alt="woman-stylist">
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/hair-treatment-310x280.jpg" width="310" height="280" title="hair-treatment" alt="hair-treatment">
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/haircut-310x280.jpg" width="310" height="280" title="haircut" alt="haircut">

<h2>Hair salon, spa &amp; make-up services</h2> <p>With more than 10-year in the industry, our team of hair stylists, colourists, and artists are specializing in hair cuts, colouring, extensions, make-up, and treatments.</p>
<h3>10+</h3>
<p>Years of Experience</p>
<h3>20K+</h3>
<p>Happy Customers</p>
<h2>Barber services</h2> <p>For the guys out there, we have a dedicated barber team who can give cool cuts and hot shaves.</p>
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/man-barber-310x437.jpg" width="310" height="437" title="man-barber" alt="man-barber">
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/barber-cut-310x280.jpg" width="310" height="280" title="barber-cut" alt="barber-cut">
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/man-stylish-310x280.jpg" width="310" height="280" title="man-stylish" alt="man-stylish">
<img loading="lazy" width="393" height="565" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/natasha.jpg" title="natasha" alt="natasha">
<img loading="lazy" width="389" height="272" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/rianna.jpg" title="rianna" alt="rianna">
<img loading="lazy" width="389" height="272" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/sthephany.jpg" title="sthephany" alt="sthephany">
<p>Got my hair extension done today. The service and quality is amazing. The extension matches with my hair seamlessly. Highly recommended.</p> Wendy 
 <p>I\'ve been going to this salon for a few years. The services and attention to details are perfect. The staffs are clean and courteous. </p> Stephanie Z. 
 <p>I\'m impressed with my first experience with this salon. Will definitely come back again with my friends to their facial and spa services.</p> Chole
<h2>Price List</h2> <p>Our experienced team offers a wide range of services from hair cut to styling/make-up, coloring, spa and barber services.</p>
<a href="https://themify.me/" > Book Now </a>
<h4 class=\'tb-menu-title\'>Junior Cut</h4> Hair cut by a junior stylist, included wash & dry. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Senior Cut</h4> Hair cut by a senior stylist, included wash & dry. 
 $80+ <br/>
<h4 class=\'tb-menu-title\'>Hair Coloring</h4> Balayage, highlight, creative colors, blending. 
 $140+ <br/>
<h4 class=\'tb-menu-title\'>Hair Treatments</h4> Intense treatments to repair all hair types. 
 $100+ <br/>
<h4 class=\'tb-menu-title\'>Styling</h4> Freshen your look by our experienced stylists. 
 $60+ <br/>
<h4 class=\'tb-menu-title\'>Make-up</h4> Our beauty artists are by appointment only. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Nail Services</h4> We cover head to toe - don\'t forget your nails. 
 $30+ <br/>
<h4 class=\'tb-menu-title\'>Men Cuts & Shaves</h4> Male hair cuts, beard shaves and trims.  
 $40+ <br/>
<h4>Book an Appointment</h4> <h2>312-234-5789</h2> <p>4096 North Street<br>New York City, NY</p> <p>MON - FRI 11:00 am -  8:00 pm<br>SAT &amp; SUN 11:00 am -  9:00 pm</p>
<form action="https://themify.me/demo/themes/shoppe-salon/wp-admin/admin-ajax.php" class="builder-contact" id="tb_ata2280-form" method="post" data-post-id="0" data-element-id="ata2280" data-orig-id="" > <label for="tb_ata2280-contact-name"></label> <input type="text" name="contact-name" placeholder="Enter Name" id="tb_ata2280-contact-name" value="" required> <label for="tb_ata2280-contact-email"></label> <input type="text" name="contact-email" placeholder="Type e-mail address" id="tb_ata2280-contact-email" value="" required> <label for="field_extra_tb_ata2280_0"> <input type="hidden" name="field_extra_name_0" value=""> </label> <input type="text" name="field_extra_0" id="field_extra_tb_ata2280_0" placeholder="Phone Number"> <label for="tb_ata2280-contact-message"></label> <textarea name="contact-message" placeholder="Write a Message" id="tb_ata2280-contact-message" required></textarea> <button type="submit">Send Message</button> </form>
<h2>Our Shop</h2> <p>High quality hair and skin care products</p>
<ul data-lazy="1"> <li> <figure> <a href="https://themify.me/demo/themes/shoppe-salon/product/woman-hair-vitamin-180/" title="Woman Hair Vitamin 180"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/09/zotos-180pro-265x285.jpg" width="265" height="285" title="zotos-180pro" alt="zotos-180pro"></a> </figure> <h3> <a href="https://themify.me/demo/themes/shoppe-salon/product/woman-hair-vitamin-180/" title="Woman Hair Vitamin 180"> Woman Hair Vitamin 180 </a> </h3> 
 <bdi>&#36;15.00</bdi> <p><a href="?add-to-cart=131" data-quantity="1" data-product_id="131" data-product_sku="" aria-label="Add &ldquo;Woman Hair Vitamin 180&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/shoppe-salon/product/hairdyer-serum/" title="Hairdyer Serum"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/09/spun-satin-hairdyer-265x285.jpg" width="265" height="285" title="spun-satin-hairdyer" alt="spun-satin-hairdyer"></a> </figure> <h3> <a href="https://themify.me/demo/themes/shoppe-salon/product/hairdyer-serum/" title="Hairdyer Serum"> Hairdyer Serum </a> </h3> 
 <bdi>&#36;15.00</bdi> <p><a href="?add-to-cart=129" data-quantity="1" data-product_id="129" data-product_sku="" aria-label="Add &ldquo;Hairdyer Serum&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/shoppe-salon/product/hair-vitamin-serum/" title="Hair Vitamin Serum"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/09/moss-chandler-265x285.jpg" width="265" height="285" title="moss-chandler" alt="moss-chandler"></a> </figure> <h3> <a href="https://themify.me/demo/themes/shoppe-salon/product/hair-vitamin-serum/" title="Hair Vitamin Serum"> Hair Vitamin Serum </a> </h3> 
 <bdi>&#36;20.00</bdi> <p><a href="?add-to-cart=126" data-quantity="1" data-product_id="126" data-product_sku="" aria-label="Add &ldquo;Hair Vitamin Serum&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/shoppe-salon/product/woman-hair-vitamin/" title="Woman Hair Vitamin"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/09/clinique-hair-gel-265x285.jpg" width="265" height="285" title="clinique-hair-gel" alt="clinique-hair-gel"></a> </figure> <h3> <a href="https://themify.me/demo/themes/shoppe-salon/product/woman-hair-vitamin/" title="Woman Hair Vitamin"> Woman Hair Vitamin </a> </h3> 
 <bdi>&#36;25.00</bdi> <p><a href="?add-to-cart=124" data-quantity="1" data-product_id="124" data-product_sku="" aria-label="Add &ldquo;Woman Hair Vitamin&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> </ul><!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2021-10-13 08:31:01',
  'post_modified_gmt' => '2021-10-13 08:31:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?page_id=139',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"mf75267\\",\\"cols\\":[{\\"element_id\\":\\"9ihk269\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"8fsp270\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>It is more than just a cut &amp; style<\\\\/h1>\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"3sdc270\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Ultra Salon is a full service hair salon and spa located in NYC. Come visit us for a relaxing yet luxurious experience. <\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"1ths270\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Book Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"black\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_shape\\":\\"squared\\",\\"buttons_size\\":\\"normal\\",\\"link_border_top_width\\":\\"1\\",\\"link_border_top_color\\":\\"#000000\\",\\"link_border-type\\":\\"all\\",\\"buttons_style\\":\\"outline\\"}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"12\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\"}},{\\"element_id\\":\\"n3gj270\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"roo9270\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/hero-home.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"width_image\\":\\"1000\\",\\"animation_effect\\":\\"fadeInRight\\"}}]}],\\"column_alignment\\":\\"col_align_bottom\\",\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"7\\",\\"background_color\\":\\"#f4f3ef\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"xq4w267\\",\\"cols\\":[{\\"element_id\\":\\"uv44271\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"2k92271\\",\\"cols\\":[{\\"element_id\\":\\"kpk6271\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ema6271\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"437\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/woman-stylist.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_left\\":\\"0\\"},\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"20\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}}}}]},{\\"element_id\\":\\"1not272\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"67tl272\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"280\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/hair-treatment.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_bottom\\":\\"20\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false},\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"2\\",\\"v_dir\\":\\"up\\"}}}}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"a1wj272\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"280\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/haircut.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}}}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_mobile\\":\\"column4-2\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"10\\",\\"breakpoint_tablet_landscape\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\",\\"tr_position\\":\\"50,50\\",\\"tr_skew_opp_bottom\\":false,\\"tr_translate_opp_bottom\\":false,\\"tr_translate_top_unit\\":\\"%\\",\\"tr_translate_top\\":\\"0\\",\\"tr_scale_opp_bottom\\":false},\\"tr_position\\":\\"50,50\\",\\"tr_skew_opp_bottom\\":false,\\"tr_translate_opp_bottom\\":false,\\"tr_scale_opp_bottom\\":false,\\"po_left_auto\\":false,\\"po_bottom_auto\\":false,\\"po_right_auto\\":false,\\"po_top_auto\\":false,\\"po-type\\":\\"top\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"ht_auto_height\\":false,\\"bl_m\\":\\"normal\\",\\"border-type\\":\\"top\\",\\"top-frame_location\\":\\"in_bellow\\",\\"top-frame_type\\":\\"top-presets\\",\\"border_inner-type\\":\\"top\\",\\"padding_inner_opp_left\\":false,\\"padding_inner_opp_bottom\\":false,\\"background_position_inner\\":\\"50,50\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_repeat_inner\\":\\"repeat\\",\\"cover_color-type\\":\\"color\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"tr_translate_top_unit\\":\\"%\\",\\"tr_translate_top\\":\\"20\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"8n9x272\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}],\\"styling\\":{\\"background_color\\":\\"#eae4dd\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"xiae272\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"952i272\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Hair salon, spa &amp; make-up services<\\\\/h2>\\\\n<p>With more than 10-year in the industry, our team of hair stylists, colourists, and artists are specializing in hair cuts, colouring, extensions, make-up, and treatments.<\\\\/p>\\",\\"margin_bottom\\":\\"50\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"5pxq273\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>10+<\\\\/h3>\\",\\"line_height_h3\\":\\"1\\",\\"font_size_h3\\":\\"80\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2ceq273\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Years of Experience<\\\\/p>\\",\\"margin_bottom\\":40}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ktpz273\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>20K+<\\\\/h3>\\",\\"line_height_h3\\":\\"1\\",\\"font_size_h3\\":\\"80\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"tbw8274\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Happy Customers<\\\\/p>\\",\\"margin_bottom\\":\\"20\\"}}],\\"styling\\":{\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":\\"8\\",\\"padding_left\\":\\"12\\",\\"padding_bottom\\":\\"50\\",\\"padding_top\\":\\"50\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"e3c3267\\",\\"cols\\":[{\\"element_id\\":\\"tjn9274\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"qiv6274\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Barber services<\\\\/h2>\\\\n<p>For the guys out there, we have a dedicated barber team who can give cool cuts and hot shaves.<\\\\/p>\\",\\"margin_bottom\\":\\"50\\"}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":\\"12\\",\\"padding_left\\":\\"8\\",\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"12\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"8\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"}}},{\\"element_id\\":\\"xn54274\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"gie1275\\",\\"cols\\":[{\\"element_id\\":\\"d4yx275\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"unt7275\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"437\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/man-barber.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_left\\":\\"0\\"},\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"20\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"1\\",\\"v_dir\\":\\"up\\"}}}}}]},{\\"element_id\\":\\"71t8275\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"psmv275\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"280\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/barber-cut.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_bottom\\":\\"20\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false},\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_speed\\":\\"2\\",\\"v_dir\\":\\"up\\"}}}}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"tgwi275\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"height_image\\":\\"280\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"310\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/man-stylish.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_dir\\":\\"up\\"}}}}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"col_mobile\\":\\"column4-2\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"10\\",\\"breakpoint_tablet_landscape\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false},\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"tr_position\\":\\"50,50\\",\\"tr_skew_opp_bottom\\":false,\\"tr_translate_opp_bottom\\":false,\\"tr_translate_top_unit\\":\\"%\\",\\"tr_translate_top\\":\\"0\\",\\"tr_scale_opp_bottom\\":false},\\"tr_position\\":\\"50,50\\",\\"tr_skew_opp_bottom\\":false,\\"tr_translate_opp_bottom\\":false,\\"tr_translate_top_unit\\":\\"%\\",\\"tr_translate_top\\":\\"-20\\",\\"tr_scale_opp_bottom\\":false}}],\\"styling\\":{\\"background_color\\":\\"#f4f3ef\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"mobile_dir\\":\\"rtl\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"rttr267\\",\\"cols\\":[{\\"element_id\\":\\"as6m276\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"d4pg276\\",\\"cols\\":[{\\"element_id\\":\\"a4w8276\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"hl3r276\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/natasha.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_bottom\\":\\"0\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"10\\",\\"margin_opp_bottom\\":false},\\"animation_effect\\":\\"fadeInLeft\\"}}],\\"styling\\":{\\"padding_opp_bottom\\":\\"1\\"}},{\\"element_id\\":\\"4yqc276\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"9hog276\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/rianna.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_bottom\\":\\"10\\",\\"animation_effect\\":\\"fadeInRight\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"goix276\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/sthephany.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"margin_bottom\\":\\"0\\",\\"animation_effect\\":\\"fadeInRight\\"}}]}],\\"col_mobile\\":\\"column4-2\\"}]},{\\"element_id\\":\\"di6n276\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"testimonial-slider\\",\\"element_id\\":\\"35rg277\\",\\"mod_settings\\":{\\"layout_testimonial\\":\\"image-top\\",\\"img_h_slider\\":\\"100\\",\\"img_w_slider\\":\\"100\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"off\\",\\"tab_content_testimonial\\":[{\\"content_testimonial\\":\\"<p>Got my hair extension done today. The service and quality is amazing. The extension matches with my hair seamlessly. Highly recommended.<\\\\/p>\\",\\"person_name_testimonial\\":\\"Wendy\\"},{\\"content_testimonial\\":\\"<p>I\\\'ve been going to this salon for a few years. The services and attention to details are perfect. The staffs are clean and courteous. <\\\\/p>\\",\\"person_name_testimonial\\":\\"Stephanie Z.\\"},{\\"content_testimonial\\":\\"<p>I\\\'m impressed with my first experience with this salon. Will definitely come back again with my friends to their facial and spa services.<\\\\/p>\\",\\"person_name_testimonial\\":\\"Chole\\"}],\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"1\\",\\"tab_visible_opt_slider\\":\\"1\\",\\"effect_slider\\":\\"scroll\\",\\"masonry\\":\\"disable\\",\\"grid_layout_testimonial\\":\\"list-post\\",\\"type_testimonial\\":\\"slider\\",\\"text_align\\":\\"left\\",\\"font_color_type\\":\\"font_color_solid\\",\\"text_transform_person_name\\":\\"uppercase\\",\\"font_size_person_name_unit\\":\\"em\\",\\"font_size_person_name\\":\\".8\\",\\"font_size_content_unit\\":\\"em\\",\\"font_size_content\\":\\"1.1\\",\\"font_size_unit\\":\\"em\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"8\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":\\"6\\",\\"padding_left\\":\\"6\\"}}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"background_color\\":\\"#eae4dd\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_top\\":30,\\"padding_opp_top\\":\\"1\\",\\"padding_bottom\\":30,\\"padding_opp_bottom\\":\\"1\\"}},{\\"element_id\\":\\"cmtv267\\",\\"cols\\":[{\\"element_id\\":\\"qbsu277\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"x0l4277\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Price List<\\\\/h2>\\\\n<p>Our experienced team offers a wide range of services from hair cut to styling\\\\/make-up, coloring, spa and barber services.<\\\\/p>\\",\\"padding_top\\":\\"20\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"jjnb277\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Book Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"black\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_shape\\":\\"squared\\",\\"buttons_size\\":\\"normal\\",\\"link_border_top_width\\":\\"1\\",\\"link_border_top_color\\":\\"#000000\\",\\"link_border-type\\":\\"all\\",\\"buttons_style\\":\\"outline\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false}}}]},{\\"element_id\\":\\"4ws2277\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"9yvg278\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Junior Cut\\",\\"description_service_menu\\":\\"Hair cut by a junior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"5e0g278\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Senior Cut\\",\\"description_service_menu\\":\\"Hair cut by a senior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$80+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"k92a278\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Hair Coloring\\",\\"description_service_menu\\":\\"Balayage, highlight, creative colors, blending.\\",\\"price_service_menu\\":\\"$140+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"1sh7278\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Hair Treatments\\",\\"description_service_menu\\":\\"Intense treatments to repair all hair types.\\",\\"price_service_menu\\":\\"$100+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]},{\\"element_id\\":\\"leu7278\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"80zb278\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Styling\\",\\"description_service_menu\\":\\"Freshen your look by our experienced stylists.\\",\\"price_service_menu\\":\\"$60+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"khr1278\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Make-up\\",\\"description_service_menu\\":\\"Our beauty artists are by appointment only.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"ay6u278\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Nail Services\\",\\"description_service_menu\\":\\"We cover head to toe - don\\\'t forget your nails.\\",\\"price_service_menu\\":\\"$30+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"vcao278\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Men Cuts & Shaves\\",\\"description_service_menu\\":\\"Male hair cuts, beard shaves and trims. \\",\\"price_service_menu\\":\\"$40+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"8\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"8\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":\\"8\\",\\"padding_left\\":\\"8\\"}},{\\"element_id\\":\\"riqz267\\",\\"cols\\":[{\\"element_id\\":\\"nenm279\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"36s8279\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Book an Appointment<\\\\/h4>\\\\n<h2>312-234-5789<\\\\/h2>\\\\n<p>4096 North Street<br>New York City, NY<\\\\/p>\\\\n<p>MON - FRI 11:00 am -  8:00 pm<br>SAT &amp; SUN 11:00 am -  9:00 pm<\\\\/p>\\",\\"margin_bottom\\":\\"50\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"17\\"}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_top\\":\\"10\\"}},{\\"element_id\\":\\"9jpq280\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"ata2280\\",\\"mod_settings\\":{\\"field_subject_label\\":\\"Subject\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_sendcopy_subject\\":\\"COPY:\\",\\"field_send_label\\":\\"Send Message\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"field_name_require\\":\\"yes\\",\\"field_email_require\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_email_active\\":\\"yes\\",\\"field_subject_active\\":false,\\"field_subject_require\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_extra\\":\\"{\\\\\\"fields\\\\\\":[{\\\\\\"type\\\\\\":\\\\\\"text\\\\\\",\\\\\\"order\\\\\\":3,\\\\\\"id\\\\\\":\\\\\\"ex3\\\\\\",\\\\\\"value\\\\\\":\\\\\\"Phone Number\\\\\\"}]}\\",\\"field_order\\":\\"{\\\\\\"field_name_label\\\\\\":0,\\\\\\"field_email_label\\\\\\":1,\\\\\\"field_subject_label\\\\\\":2,\\\\\\"field_message_label\\\\\\":4}\\",\\"field_optin_label\\":\\"Subscribe to my newsletter.\\",\\"field_optin_active\\":false,\\"provider\\":\\"mailchimp\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"field_message_placeholder\\":\\"Write a Message\\",\\"field_email_placeholder\\":\\"Type e-mail address\\",\\"field_name_placeholder\\":\\"Enter Name\\",\\"include_name_mail\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"user_role\\":\\"admin\\",\\"send_to_admins\\":\\"true\\",\\"layout_contact\\":\\"style1\\",\\"checkbox_r_c_sd_apply_all\\":\\"1\\",\\"r_c_sd_opp_left\\":false,\\"r_c_sd_opp_top\\":false,\\"r_c_sd_top\\":\\"0\\",\\"p_sd_right\\":\\"34\\",\\"p_sd_left\\":\\"34\\",\\"p_sd_opp_left\\":\\"1\\",\\"p_sd_bottom\\":\\"19\\",\\"p_sd_opp_bottom\\":\\"1\\",\\"p_sd_top\\":\\"19\\",\\"background_color_send_h\\":\\"#8d5822\\",\\"background_color_send\\":\\"#000000\\",\\"checkbox_in_r_c_apply_all\\":\\"1\\",\\"in_r_c_opp_left\\":false,\\"in_r_c_opp_top\\":false,\\"in_r_c_top\\":\\"0\\",\\"border_inputs-type\\":\\"left\\",\\"font_color_send\\":\\"#ffffff\\"}}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"10\\"}}],\\"styling\\":{\\"border_inner-type\\":\\"top\\",\\"checkbox_padding_inner_apply_all\\":\\"1\\",\\"padding_inner_opp_left\\":false,\\"padding_inner_opp_bottom\\":false,\\"background_position_inner\\":\\"0,0\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_repeat_inner\\":\\"repeat-none\\",\\"background_image_inner\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-salon\\\\/files\\\\/2021\\\\/04\\\\/circle-bg.png\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\"}},{\\"element_id\\":\\"be2v267\\",\\"cols\\":[{\\"element_id\\":\\"frrd280\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"zhzs281\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Shop<\\\\/h2>\\\\n<p>High quality hair and skin care products<\\\\/p>\\",\\"padding_top\\":\\"20\\",\\"margin_bottom\\":\\"72\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_right_unit\\":\\"%\\",\\"margin_left_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"margin_left\\":\\"20\\",\\"margin_opp_left\\":\\"1\\"}},{\\"mod_name\\":\\"products\\",\\"element_id\\":\\"7ql8281\\",\\"mod_settings\\":{\\"post_per_page_products\\":\\"4\\",\\"hide_page_nav_products\\":\\"yes\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"layout_products\\":\\"grid4\\",\\"post_type\\":\\"product\\",\\"hide_sales_badge\\":\\"no\\",\\"show_empty_rating\\":false,\\"hide_rating_products\\":\\"no\\",\\"hide_add_to_cart_products\\":\\"no\\",\\"hide_price_products\\":\\"no\\",\\"show_product_tags\\":\\"no\\",\\"show_product_categories\\":\\"no\\",\\"unlink_post_title_products\\":\\"no\\",\\"title_tag\\":\\"h3\\",\\"hide_post_title_products\\":\\"no\\",\\"unlink_feat_img_products\\":\\"no\\",\\"img_height_products\\":\\"285\\",\\"img_width_products\\":\\"265\\",\\"hide_feat_img_products\\":\\"no\\",\\"description_products\\":\\"none\\",\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"1\\",\\"tab_visible_opt_slider\\":\\"1\\",\\"visible_opt_slider\\":\\"1\\",\\"effect_slider\\":\\"scroll\\",\\"layout_slider\\":\\"slider-default\\",\\"template_products\\":\\"list\\",\\"order_products\\":\\"desc\\",\\"orderby_products\\":\\"date\\",\\"hide_outofstock_products\\":\\"no\\",\\"hide_free_products\\":\\"no\\",\\"hide_child_products\\":\\"no\\",\\"product_cat_terms\\":\\"0|single\\",\\"query_type\\":\\"product_cat\\",\\"query_products\\":\\"all\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => 'tb_gs238614',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 146,
  'post_date' => '2021-10-01 06:41:56',
  'post_date_gmt' => '2021-10-01 06:41:56',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Services</h1>
<h4 class=\'tb-menu-title\'>Junior Cut</h4> Hair cut by a junior stylist, included wash & dry. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Senior Cut</h4> Hair cut by a junior stylist, included wash & dry. 
 $80+ <br/>
<h4 class=\'tb-menu-title\'>Hair Coloring</h4> Balayage, highlight, creative colors, blending. 
 $140+ <br/>
<h4 class=\'tb-menu-title\'>Hair Treatments</h4> Intense treatments to repair all hair types. 
 $100+ <br/>
<h4 class=\'tb-menu-title\'>Styling</h4> Freshen your look by our experienced stylists. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Make-up</h4> Our beauty artists are by appointment only. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Nail Services</h4> We cover head to toe - don\'t forget your nails. 
 $50+ <br/>
<h4 class=\'tb-menu-title\'>Men Cuts & Shaves</h4> Male hair cuts, beard shaves and trims.  
 $50+ <br/>
<h2>Spa Packages</h2>
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/pexels-samantha-kandinsky-6470305-364x364.jpg" width="364" height="364" title="pexels-samantha-kandinsky-6470305" alt="pexels-samantha-kandinsky-6470305" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/pexels-samantha-kandinsky-6470305.jpg 364w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/pexels-samantha-kandinsky-6470305-150x150.jpg 150w" sizes="(max-width: 364px) 100vw, 364px" />
<h3 class=\'tb-menu-title\'>Facial & Body Massage</h3> Full 2-hour of facial and massage relaxation. Your choice of facial cream, massage oil and music. 
 $200+ <br/>
<h3 class=\'tb-menu-title\'>Deep Tissue Facial Massage</h3> Facial treatment & massage focus specifically on the face to restore youthful tone and contour. 
 $120+ <br/>
<h3 class=\'tb-menu-title\'>Two-for-one Spa Package </h3> Bring your special person to enjoy our special 2-for-1 spa package. 
 $200+ <br/>
<h2>Hair Treatments</h2>
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/contact-img-364x364.jpg" width="364" height="364" title="contact-img" alt="contact-img" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/contact-img-364x364.jpg 364w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/contact-img-150x150.jpg 150w" sizes="(max-width: 364px) 100vw, 364px" />
<h3 class=\'tb-menu-title\'>Basic Treatment</h3> Repair your damaged hair and restore its natural definition.  
 $80+ <br/>
<h3 class=\'tb-menu-title\'>Deep Conditioning</h3> Deep conditioning treatments are essential to help repairing severe damaged hair, 
 $120+ <br/>
<h3 class=\'tb-menu-title\'>Multiple-sessions</h3> Sometimes it takes more than a session to ensure damaged hair is fully repaired. 
 $160+ <br/>
<h2>Men Services</h2>
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide3-364x364.jpg" width="364" height="364" title="f-slide3" alt="f-slide3" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide3-364x364.jpg 364w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide3-150x150.jpg 150w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide3.jpg 320w" sizes="(max-width: 364px) 100vw, 364px" />
<h3 class=\'tb-menu-title\'>Junior Men Cut</h3> Hair cut by a junior stylist, included wash & dry. 
 $50+ <br/>
<h3 class=\'tb-menu-title\'>Senior Men Cut</h3> Hair cut by a junior stylist, included wash & dry. 
 $75+ <br/>
<h3 class=\'tb-menu-title\'>Shaves</h3> Trim, shave, however you want to style it. 
 $40+ <br/><!--/themify_builder_static-->',
  'post_title' => 'Services',
  'post_excerpt' => '',
  'post_name' => 'services',
  'post_modified' => '2021-10-05 12:17:49',
  'post_modified_gmt' => '2021-10-05 12:17:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?page_id=146',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ylx3117\\",\\"cols\\":[{\\"element_id\\":\\"zl1f119\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"w6t3119\\",\\"cols\\":[{\\"element_id\\":\\"h1eu120\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"pog0120\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Services<\\\\/h1>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}]}]}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"8\\"}},{\\"element_id\\":\\"l466118\\",\\"cols\\":[{\\"element_id\\":\\"le5r120\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"v4h6121\\",\\"cols\\":[{\\"element_id\\":\\"t6xy121\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"f0do121\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Junior Cut\\",\\"description_service_menu\\":\\"Hair cut by a junior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"salz121\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Senior Cut\\",\\"description_service_menu\\":\\"Hair cut by a junior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$80+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"six6121\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Hair Coloring\\",\\"description_service_menu\\":\\"Balayage, highlight, creative colors, blending.\\",\\"price_service_menu\\":\\"$140+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"yshc121\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Hair Treatments\\",\\"description_service_menu\\":\\"Intense treatments to repair all hair types.\\",\\"price_service_menu\\":\\"$100+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]},{\\"element_id\\":\\"7e47121\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"0179121\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Styling\\",\\"description_service_menu\\":\\"Freshen your look by our experienced stylists.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"ua0i122\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Make-up\\",\\"description_service_menu\\":\\"Our beauty artists are by appointment only.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"o3rg122\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Nail Services\\",\\"description_service_menu\\":\\"We cover head to toe - don\\\'t forget your nails.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"z9s8122\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Men Cuts & Shaves\\",\\"description_service_menu\\":\\"Male hair cuts, beard shaves and trims. \\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"global_styles\\":\\"tb_gs238614\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]}]}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":8}},{\\"element_id\\":\\"pr78118\\",\\"cols\\":[{\\"element_id\\":\\"tayu122\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"xtot122\\",\\"cols\\":[{\\"element_id\\":\\"r1y8122\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"iohk122\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Spa Packages<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom\\":\\"30\\"}}]}]},{\\"element_id\\":\\"fh9p123\\",\\"cols\\":[{\\"element_id\\":\\"j9ou123\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"85rm123\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"circle\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/pexels-samantha-kandinsky-6470305.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"364\\",\\"width_image\\":\\"364\\",\\"animation_effect\\":\\"fadeInLeft\\"}}],\\"styling\\":{\\"text_align\\":\\"right\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\"}},{\\"element_id\\":\\"irte123\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"mfob125\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Facial & Body Massage\\",\\"description_service_menu\\":\\"Full 2-hour of facial and massage relaxation. Your choice of facial cream, massage oil and music.\\",\\"price_service_menu\\":\\"$200+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"vapc125\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Deep Tissue Facial Massage\\",\\"description_service_menu\\":\\"Facial treatment & massage focus specifically on the face to restore youthful tone and contour.\\",\\"price_service_menu\\":\\"$120+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"zm5c125\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Two-for-one Spa Package \\",\\"description_service_menu\\":\\"Bring your special person to enjoy our special 2-for-1 spa package.\\",\\"price_service_menu\\":\\"$200+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]}]}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\"}},{\\"element_id\\":\\"022e118\\",\\"cols\\":[{\\"element_id\\":\\"75lp126\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"8hg8126\\",\\"cols\\":[{\\"element_id\\":\\"8xz6126\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"1na5127\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Hair Treatments<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom\\":\\"30\\"}}]}]},{\\"element_id\\":\\"t4lp127\\",\\"cols\\":[{\\"element_id\\":\\"ecsx128\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"pmaz128\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"circle\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/contact-img-364x364.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"364\\",\\"width_image\\":\\"364\\",\\"animation_effect\\":\\"fadeInRight\\"}}],\\"styling\\":{\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false},\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}}},{\\"element_id\\":\\"14by128\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"s2zn128\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Basic Treatment\\",\\"description_service_menu\\":\\"Repair your damaged hair and restore its natural definition. \\",\\"price_service_menu\\":\\"$80+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"f78o128\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Deep Conditioning\\",\\"description_service_menu\\":\\"Deep conditioning treatments are essential to help repairing severe damaged hair,\\",\\"price_service_menu\\":\\"$120+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"kb71129\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Multiple-sessions\\",\\"description_service_menu\\":\\"Sometimes it takes more than a session to ensure damaged hair is fully repaired.\\",\\"price_service_menu\\":\\"$160+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]}],\\"desktop_dir\\":\\"rtl\\",\\"tablet_dir\\":\\"rtl\\",\\"tablet_landscape_dir\\":\\"rtl\\"}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\"}},{\\"element_id\\":\\"ioqc118\\",\\"cols\\":[{\\"element_id\\":\\"8tex129\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"1p9g130\\",\\"cols\\":[{\\"element_id\\":\\"1pfl130\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"k1cn130\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Men Services<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom\\":\\"30\\"}}]}]},{\\"element_id\\":\\"blwe130\\",\\"cols\\":[{\\"element_id\\":\\"7bdz131\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"whc2131\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_tag\\":\\"h3\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":\\"circle\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide3-364x364.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"364\\",\\"width_image\\":\\"364\\",\\"animation_effect\\":\\"fadeInLeft\\"}}],\\"styling\\":{\\"text_align\\":\\"right\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\"}},{\\"element_id\\":\\"1mj0131\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"qyhv131\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Junior Men Cut\\",\\"description_service_menu\\":\\"Hair cut by a junior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"29rz131\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Senior Men Cut\\",\\"description_service_menu\\":\\"Hair cut by a junior stylist, included wash & dry.\\",\\"price_service_menu\\":\\"$75+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}},{\\"mod_name\\":\\"service-menu\\",\\"element_id\\":\\"0v4c132\\",\\"mod_settings\\":{\\"title_tag\\":\\"h3\\",\\"title_service_menu\\":\\"Shaves\\",\\"description_service_menu\\":\\"Trim, shave, however you want to style it.\\",\\"price_service_menu\\":\\"$40+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"highlight_service_menu\\":false,\\"image_zoom_icon\\":false,\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":false,\\"add_price_check\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\",\\"highlight_color_service_menu\\":\\"tb_default_color\\"}}]}]}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":10}}]',
    'themify_used_global_styles' => 
    array (
      0 => 'tb_gs238614',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 77,
  'post_date' => '2021-09-21 07:35:27',
  'post_date_gmt' => '2021-09-21 07:35:27',
  'post_content' => '<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Wishlist',
  'post_excerpt' => '',
  'post_name' => 'wishlist',
  'post_modified' => '2021-09-21 07:35:28',
  'post_modified_gmt' => '2021-09-21 07:35:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?page_id=77',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"qfxj890\\",\\"cols\\":[{\\"element_id\\":\\"0lr2891\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 55,
  'post_date' => '2021-04-27 14:27:44',
  'post_date_gmt' => '2021-04-27 14:27:44',
  'post_content' => '<!--themify_builder_static--><img src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide1-320x320.jpg" height="320" title="f-slide1" alt="f-slide1" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide1.jpg 320w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide1-150x150.jpg 150w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide1-364x364.jpg 364w" sizes="(max-width: 320px) 100vw, 320px" /> <img src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide2-320x320.jpg" height="320" title="f-slide2" alt="f-slide2" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide2.jpg 320w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide2-150x150.jpg 150w" sizes="(max-width: 320px) 100vw, 320px" /> <img src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide3-320x320.jpg" height="320" title="f-slide3" alt="f-slide3" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide3.jpg 320w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide3-150x150.jpg 150w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide3-364x364.jpg 364w" sizes="(max-width: 320px) 100vw, 320px" /> <img src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide4-320x320.jpg" height="320" title="f-slide4" alt="f-slide4" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide4.jpg 320w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide4-150x150.jpg 150w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide4-364x364.jpg 364w" sizes="(max-width: 320px) 100vw, 320px" /> <img src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide5-320x320.jpg" height="320" title="f-slide5" alt="f-slide5" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide5.jpg 320w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide5-150x150.jpg 150w" sizes="(max-width: 320px) 100vw, 320px" /> <img src="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide6-320x320.jpg" height="320" title="f-slide6" alt="f-slide6" srcset="https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide6.jpg 320w, https://themify.me/demo/themes/shoppe-salon/files/2021/04/f-slide6-150x150.jpg 150w" sizes="(max-width: 320px) 100vw, 320px" /><!--/themify_builder_static-->',
  'post_title' => 'Footer Layout',
  'post_excerpt' => '',
  'post_name' => 'footer-layout',
  'post_modified' => '2021-10-01 06:59:34',
  'post_modified_gmt' => '2021-10-01 06:59:34',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=tbuilder_layout_part&#038;p=55',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout_part',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"q7lx639\\",\\"cols\\":[{\\"element_id\\":\\"xvr6640\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"slider\\",\\"element_id\\":\\"zyv8641\\",\\"mod_settings\\":{\\"posts_per_page_slider\\":\\"4\\",\\"display_slider\\":\\"none\\",\\"img_h_slider\\":\\"320\\",\\"horizontal\\":\\"no\\",\\"visible_opt_slider\\":\\"6\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"play_pause_control\\":\\"no\\",\\"show_arrow_slider\\":\\"no\\",\\"show_nav_slider\\":\\"no\\",\\"wrap_slider\\":\\"yes\\",\\"auto_scroll_opt_slider\\":\\"5\\",\\"post_type\\":\\"post\\",\\"hide_post_date\\":\\"yes\\",\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"1\\",\\"tab_visible_opt_slider\\":\\"1\\",\\"effect_slider\\":\\"continuously\\",\\"img_fullwidth_slider\\":false,\\"layout_slider\\":\\"slider-default\\",\\"img_content_slider\\":[{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide1.jpg\\",\\"img_title_tag\\":\\"h3\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide2.jpg\\",\\"img_title_tag\\":\\"h3\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide3.jpg\\",\\"img_title_tag\\":\\"h3\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide4.jpg\\",\\"img_title_tag\\":\\"h3\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide5.jpg\\",\\"img_title_tag\\":\\"h3\\"},{\\"img_url_slider\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-salon\\\\/files\\\\/2021\\\\/04\\\\/f-slide6.jpg\\",\\"img_title_tag\\":\\"h3\\"}],\\"open_link_new_tab_slider\\":\\"no\\",\\"unlink_feat_img_slider\\":\\"no\\",\\"hide_feat_img_slider\\":\\"no\\",\\"unlink_post_title_slider\\":\\"no\\",\\"hide_post_title_slider\\":\\"no\\",\\"orderby_slider\\":\\"date\\",\\"order_slider\\":\\"desc\\",\\"blog_category_slider\\":\\"0|single\\",\\"taxonomy\\":\\"category\\",\\"layout_display_slider\\":\\"image\\",\\"margin_bottom\\":\\"0\\",\\"i_m_opp_left\\":false,\\"i_m_bottom\\":\\"0\\",\\"i_m_opp_bottom\\":false,\\"i_p_opp_left\\":false,\\"i_p_opp_bottom\\":false,\\"css_slider\\":\\"ftr-slider\\",\\"video_content_slider\\":[{\\"video_title_tag\\":\\"h3\\"}]}}]}],\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 65,
  'post_date' => '2021-09-18 08:13:18',
  'post_date_gmt' => '2021-09-18 08:13:18',
  'post_content' => '<!--themify_builder_static--><img src="https://themify.me/demo/themes/wp-content/uploads/addon-samples/menu-pizza.png" width="100" height="49" alt="Female Hair Cut"> 
 <h4>Female Hair Cut</h4> Hair cut with wash & blow dry 
 $50+ <br/><!--/themify_builder_static-->',
  'post_title' => 'Price List Menu',
  'post_excerpt' => '',
  'post_name' => 'tb_gs238614',
  'post_modified' => '2021-09-18 08:13:18',
  'post_modified_gmt' => '2021-09-18 08:13:18',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/tglobal-style/tb_gs238614/',
  'menu_order' => 0,
  'post_type' => 'tglobal_style',
  'meta_input' => 
  array (
    'themify_global_style_type' => 'service-menu',
    'hide_page_title' => 'yes',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"row61459f9e9efa1\\",\\"styling\\":[],\\"cols\\":[{\\"element_id\\":\\"col61459f9e9efa1\\",\\"grid_class\\":\\"col-full\\",\\"styling\\":[],\\"modules\\":[{\\"element_id\\":\\"mod61459f9e9efa1\\",\\"mod_name\\":\\"service-menu\\",\\"mod_settings\\":{\\"title_tag\\":\\"h4\\",\\"title_service_menu\\":\\"Female Hair Cut\\",\\"description_service_menu\\":\\"Hair cut with wash & blow dry\\",\\"price_service_menu\\":\\"$50+\\",\\"style_service_menu\\":\\"image-horizontal\\",\\"image_service_menu\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/wp-content\\\\/uploads\\\\/addon-samples\\\\/menu-pizza.png\\",\\"width_service_menu\\":100,\\"highlight_color_service_menu\\":\\"tb_default_color\\",\\"highlight_service_menu\\":\\"false\\",\\"image_zoom_icon\\":\\"false\\",\\"link_options\\":\\"regular\\",\\"appearance_image_service_menu\\":\\"false\\",\\"add_price_check\\":\\"false\\",\\"b_ra_opp_left\\":\\"false\\",\\"b_ra_opp_top\\":\\"false\\",\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#e5e5e5\\",\\"border-type\\":\\"bottom\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":\\"20\\"}}]}]}]',
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 131,
  'post_date' => '2021-09-23 04:40:35',
  'post_date_gmt' => '2021-09-23 04:40:35',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Woman Hair Vitamin 180',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'woman-hair-vitamin-180',
  'post_modified' => '2021-09-23 04:40:35',
  'post_modified_gmt' => '2021-09-23 04:40:35',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=131',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632989508:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"5iuf742\\",\\"cols\\":[{\\"element_id\\":\\"fhkf743\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '132',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/zotos-180pro.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 129,
  'post_date' => '2021-09-23 04:39:49',
  'post_date_gmt' => '2021-09-23 04:39:49',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam.',
  'post_title' => 'Hairdyer Serum',
  'post_excerpt' => 'Aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam.',
  'post_name' => 'hairdyer-serum',
  'post_modified' => '2021-09-23 04:39:49',
  'post_modified_gmt' => '2021-09-23 04:39:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=129',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632990268:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"equa798\\",\\"cols\\":[{\\"element_id\\":\\"megy799\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '130',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, styling-gel',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/spun-satin-hairdyer.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 126,
  'post_date' => '2021-09-23 04:38:57',
  'post_date_gmt' => '2021-09-23 04:38:57',
  'post_content' => 'Teleniti atque corrupti ero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum  quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.',
  'post_title' => 'Hair Vitamin  Serum',
  'post_excerpt' => 'Yeleniti atque corrupti olores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia.',
  'post_name' => 'hair-vitamin-serum',
  'post_modified' => '2021-09-23 04:38:57',
  'post_modified_gmt' => '2021-09-23 04:38:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=126',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632990268:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"q8k0153\\",\\"cols\\":[{\\"element_id\\":\\"49yx155\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '127',
    '_regular_price' => '20',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '20',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/moss-chandler.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 124,
  'post_date' => '2021-09-23 04:37:49',
  'post_date_gmt' => '2021-09-23 04:37:49',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit.',
  'post_title' => 'Woman Hair Vitamin',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'woman-hair-vitamin',
  'post_modified' => '2021-09-23 04:37:49',
  'post_modified_gmt' => '2021-09-23 04:37:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=124',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632990269:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"2r0k921\\",\\"cols\\":[{\\"element_id\\":\\"ezka921\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '125',
    '_regular_price' => '25',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '25',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/clinique-hair-gel.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 122,
  'post_date' => '2021-09-23 04:36:50',
  'post_date_gmt' => '2021-09-23 04:36:50',
  'post_content' => ' Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Woman Organic Serum',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam.',
  'post_name' => 'woman-organic-serum',
  'post_modified' => '2021-09-23 04:36:50',
  'post_modified_gmt' => '2021-09-23 04:36:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=122',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632990269:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"xi8u476\\",\\"cols\\":[{\\"element_id\\":\\"0cnk477\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '123',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/avalon-organics.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 120,
  'post_date' => '2021-09-23 04:34:54',
  'post_date_gmt' => '2021-09-23 04:34:54',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Hair Treatment Deluxe',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est.',
  'post_name' => 'hair-treatment-deluxe',
  'post_modified' => '2021-09-23 04:34:54',
  'post_modified_gmt' => '2021-09-23 04:34:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=120',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371614:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"xgy2242\\",\\"cols\\":[{\\"element_id\\":\\"nyto244\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '121',
    '_regular_price' => '18',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '18',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/argan-deluxe.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 118,
  'post_date' => '2021-09-23 04:33:55',
  'post_date_gmt' => '2021-09-23 04:33:55',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Woman Treatment Shampoo',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est qui dolorem ipsum quia dolor sit amet consectetur adipisci velit.',
  'post_name' => 'woman-treatment-shampoo',
  'post_modified' => '2021-09-23 04:33:55',
  'post_modified_gmt' => '2021-09-23 04:33:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=118',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371497:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"3qv2345\\",\\"cols\\":[{\\"element_id\\":\\"dd2c346\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '119',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/capelli-shampoo.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 116,
  'post_date' => '2021-09-23 04:32:33',
  'post_date_gmt' => '2021-09-23 04:32:33',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Blacksheed Shampoo',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'blacksheed-shampoo',
  'post_modified' => '2021-09-23 04:32:33',
  'post_modified_gmt' => '2021-09-23 04:32:33',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=116',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371420:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"sdq7703\\",\\"cols\\":[{\\"element_id\\":\\"w68s704\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '117',
    '_regular_price' => '14',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '14',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/apple-sheed.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 114,
  'post_date' => '2021-09-23 04:30:19',
  'post_date_gmt' => '2021-09-23 04:30:19',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Men Hair Vitamin',
  'post_excerpt' => 'Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
  'post_name' => 'men-hair-vitamin-2',
  'post_modified' => '2021-09-23 04:30:20',
  'post_modified_gmt' => '2021-09-23 04:30:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=114',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371279:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"zo84313\\",\\"cols\\":[{\\"element_id\\":\\"gg0f320\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '115',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/dove-men-care.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 112,
  'post_date' => '2021-09-23 04:28:26',
  'post_date_gmt' => '2021-09-23 04:28:26',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Treatment Shampoo',
  'post_excerpt' => 'Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_name' => 'treatment-shampoo',
  'post_modified' => '2021-09-23 04:28:26',
  'post_modified_gmt' => '2021-09-23 04:28:26',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=112',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632371231:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"8cp1436\\",\\"cols\\":[{\\"element_id\\":\\"kc0r436\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '113',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/garniaer-watze.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 110,
  'post_date' => '2021-09-23 04:27:13',
  'post_date_gmt' => '2021-09-23 04:27:13',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Beard Oil',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'beard-oil',
  'post_modified' => '2021-09-23 04:27:13',
  'post_modified_gmt' => '2021-09-23 04:27:13',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=110',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632990272:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"dfjb681\\",\\"cols\\":[{\\"element_id\\":\\"0b9n681\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '111',
    '_regular_price' => '20',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '20',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'beard-oil',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/lambert-beard-oil.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 108,
  'post_date' => '2021-09-23 04:26:16',
  'post_date_gmt' => '2021-09-23 04:26:16',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Gelatine Hair Styling',
  'post_excerpt' => 'Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
  'post_name' => 'gelatine-hair-styling',
  'post_modified' => '2021-09-23 04:26:16',
  'post_modified_gmt' => '2021-09-23 04:26:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=108',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632990271:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"6sph819\\",\\"cols\\":[{\\"element_id\\":\\"2tdw819\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '109',
    '_regular_price' => '14',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '14',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'styling-gel',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/gelatin-hair-spray.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 106,
  'post_date' => '2021-09-23 04:23:56',
  'post_date_gmt' => '2021-09-23 04:23:56',
  'post_content' => ' Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid.',
  'post_title' => 'Honey Shampoo',
  'post_excerpt' => 'Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
  'post_name' => 'honey-shampoo',
  'post_modified' => '2021-09-23 04:24:09',
  'post_modified_gmt' => '2021-09-23 04:24:09',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=106',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632990271:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '107',
    '_regular_price' => '16',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '16',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"1jo656\\",\\"cols\\":[{\\"element_id\\":\\"ez3x56\\",\\"grid_class\\":\\"col-full\\"}]}]',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/garnier-honey-shampoo.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 104,
  'post_date' => '2021-09-23 04:22:01',
  'post_date_gmt' => '2021-09-23 04:22:01',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_title' => 'Woman Hair Perfume',
  'post_excerpt' => 'Nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam.',
  'post_name' => 'woman-hair-perfume',
  'post_modified' => '2021-09-23 04:22:01',
  'post_modified_gmt' => '2021-09-23 04:22:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=104',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370842:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"u5r1218\\",\\"cols\\":[{\\"element_id\\":\\"t2kg219\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '105',
    '_regular_price' => '20',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '20',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/Mor-hair-perfume.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 102,
  'post_date' => '2021-09-23 04:21:03',
  'post_date_gmt' => '2021-09-23 04:21:03',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid.',
  'post_title' => 'Men Styling Gel',
  'post_excerpt' => 'Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
  'post_name' => 'men-styling-gel',
  'post_modified' => '2021-09-23 04:21:03',
  'post_modified_gmt' => '2021-09-23 04:21:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=102',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370725:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"s5c0374\\",\\"cols\\":[{\\"element_id\\":\\"dk1d374\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '103',
    '_regular_price' => '10',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '10',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'styling-gel',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/rausch-styling-gel.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 100,
  'post_date' => '2021-09-23 04:18:27',
  'post_date_gmt' => '2021-09-23 04:18:27',
  'post_content' => 'Deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum. Excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum.',
  'post_title' => 'Damage Hair Shampoo',
  'post_excerpt' => 'Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias.',
  'post_name' => 'damage-hair-shampoo',
  'post_modified' => '2021-09-23 04:18:27',
  'post_modified_gmt' => '2021-09-23 04:18:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=100',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632990270:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"qf38155\\",\\"cols\\":[{\\"element_id\\":\\"08ms156\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '101',
    '_regular_price' => '14',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '14',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/pantene-damage-hair.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 98,
  'post_date' => '2021-09-23 04:16:01',
  'post_date_gmt' => '2021-09-23 04:16:01',
  'post_content' => 'Molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Woman Hair Serum',
  'post_excerpt' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo.',
  'post_name' => 'woman-hair-serum',
  'post_modified' => '2021-09-23 04:16:01',
  'post_modified_gmt' => '2021-09-23 04:16:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=98',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370510:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"56si668\\",\\"cols\\":[{\\"element_id\\":\\"j61u668\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '99',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/perfect-hair-serum.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 94,
  'post_date' => '2021-09-23 04:14:43',
  'post_date_gmt' => '2021-09-23 04:14:43',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Soft Styling Gel',
  'post_excerpt' => 'Ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit sed quia.',
  'post_name' => 'soft-styling-gel',
  'post_modified' => '2021-09-23 04:14:43',
  'post_modified_gmt' => '2021-09-23 04:14:43',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=94',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370360:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"sked471\\",\\"cols\\":[{\\"element_id\\":\\"69p5471\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '95',
    '_regular_price' => '14',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '14',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'styling-gel',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/styling-gel.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 91,
  'post_date' => '2021-09-23 04:10:26',
  'post_date_gmt' => '2021-09-23 04:10:26',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Rebonding Serum',
  'post_excerpt' => 'Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_name' => 'rebonding-serum',
  'post_modified' => '2021-09-23 04:10:26',
  'post_modified_gmt' => '2021-09-23 04:10:26',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=91',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632370133:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"yqik373\\",\\"cols\\":[{\\"element_id\\":\\"spvj374\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '92',
    '_regular_price' => '25',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '25',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/makarizo-rebonding.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 89,
  'post_date' => '2021-09-23 04:09:17',
  'post_date_gmt' => '2021-09-23 04:09:17',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_title' => 'Men Hair Vitamin',
  'post_excerpt' => 'Nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.',
  'post_name' => 'men-hair-vitamin',
  'post_modified' => '2021-09-23 04:09:17',
  'post_modified_gmt' => '2021-09-23 04:09:17',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?post_type=product&#038;p=89',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1632990272:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"6p9g707\\",\\"cols\\":[{\\"element_id\\":\\"4u8k708\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '90',
    '_regular_price' => '15',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '15',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hair-treatment, hair-vitamin',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-salon/files/2021/09/kevin-murphy.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 155,
  'post_date' => '2021-10-01 06:44:29',
  'post_date_gmt' => '2021-10-01 06:44:29',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '155',
  'post_modified' => '2021-10-01 06:44:29',
  'post_modified_gmt' => '2021-10-01 06:44:29',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?p=155',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '139',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 156,
  'post_date' => '2021-10-01 06:44:29',
  'post_date_gmt' => '2021-10-01 06:44:29',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '156',
  'post_modified' => '2021-10-01 06:44:29',
  'post_modified_gmt' => '2021-10-01 06:44:29',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?p=156',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => 'shop',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 154,
  'post_date' => '2021-10-01 06:44:29',
  'post_date_gmt' => '2021-10-01 06:44:29',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '154',
  'post_modified' => '2021-10-01 06:44:29',
  'post_modified_gmt' => '2021-10-01 06:44:29',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?p=154',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '142',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 153,
  'post_date' => '2021-10-01 06:44:29',
  'post_date_gmt' => '2021-10-01 06:44:29',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '153',
  'post_modified' => '2021-10-01 06:44:29',
  'post_modified_gmt' => '2021-10-01 06:44:29',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?p=153',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '146',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 152,
  'post_date' => '2021-10-01 06:44:29',
  'post_date_gmt' => '2021-10-01 06:44:29',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '152',
  'post_modified' => '2021-10-01 06:44:29',
  'post_modified_gmt' => '2021-10-01 06:44:29',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-salon/?p=152',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '148',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_search" );
$widgets[1002] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1003] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1004] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1005] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1006] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1007] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );



$sidebars_widgets = array (
  'sidebar-main' => 
  array (
    0 => 'search-1002',
    1 => 'recent-posts-1003',
    2 => 'recent-comments-1004',
    3 => 'archives-1005',
    4 => 'categories-1006',
    5 => 'meta-1007',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-search_post_type' => 'all',
  'setting-webfonts_list' => 'recommended',
  'setting-customizer_responsive_design_tablet_landscape' => '1024',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '480',
  'setting-mobile_menu_trigger_point' => '900',
  'setting-header_design' => 'header-logo-left',
  'setting-exclude_site_tagline' => 'on',
  'setting-exclude_search_button' => 'on',
  'setting-footer_design' => 'footer-horizontal-left',
  'setting-use_float_back' => 'on',
  'setting-footer_widgets' => 'footerwidget-3col',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-imagefilter_applyto' => 'featuredonly',
  'setting-more_posts' => 'infinite',
  'setting-entries_nav' => 'numbered',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-lazy-blur' => '25',
  'setting-cache-live' => '10080',
  'setting-webp-quality' => '5',
  'setting-default_layout' => 'sidebar1',
  'setting-default_post_layout' => 'list-post',
  'setting-post_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar1',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-search-result_layout' => 'sidebar1',
  'setting-search-result_post_layout' => 'list-post',
  'setting-search-result_layout_display' => 'excerpt',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar1',
  'setting-shop_layout' => 'sidebar-none',
  'setting-shop_content_width' => 'default_width',
  'setting-shop_archive_layout' => 'sidebar-none',
  'setting-custom_post_product_archive_content_width' => 'default_width',
  'setting-products_layout' => 'grid4',
  'setting-product_post_gutter' => 'gutter',
  'setting-products_slider' => 'enable',
  'setting-single_product_layout' => 'sidebar-none',
  'setting-custom_post_product_single_content_width' => 'default_width',
  'setting-related_products_limit' => '3',
  'setting-product_description_type' => 'long',
  'setting-wishlist_page' => '77',
  'setting-cart_style' => 'slide-out',
  'setting-cart_show_seconds' => 'off',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/shoppe-salon/wp-content/themes/themify-shoppe/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/shoppe-salon/wp-content/themes/themify-shoppe/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'YouTube',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/shoppe-salon/wp-content/themes/themify-shoppe/themify/img/social/youtube.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'Pinterest',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/shoppe-salon/wp-content/themes/themify-shoppe/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-4' => 'font-icon',
  'setting-link_title_themify-link-4' => 'Twitter',
  'setting-link_ficon_themify-link-4' => 'fa-twitter',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Facebook',
  'setting-link_ficon_themify-link-5' => 'fa-facebook',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'YouTube',
  'setting-link_ficon_themify-link-6' => 'fa-youtube',
  'setting-link_type_themify-link-7' => 'font-icon',
  'setting-link_title_themify-link-7' => 'Pinterest',
  'setting-link_ficon_themify-link-7' => 'fa-pinterest',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-5":"themify-link-5","themify-link-6":"themify-link-6","themify-link-7":"themify-link-7"}',
  'setting-link_field_hash' => '8',
  'setting-twitter_settings_cache' => '10',
  'setting-recaptcha_version' => 'v2',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_gallery_lightbox' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'setting-hooks-1-location' => 'themify_layout_after',
  'setting-hooks-1-code' => '[themify_layout_part id="55"]',
  'setting-hooks_field_ids' => '[1]',
  'skin' => 'salon',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'custom_css_post_id' => -1,
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
