<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 16,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 2,
  'name' => 'simple',
  'slug' => 'simple',
  'term_group' => 0,
  'taxonomy' => 'product_type',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 17,
  'name' => 'Segway',
  'slug' => 'segway',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 18,
  'name' => 'Hub',
  'slug' => 'hub',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 19,
  'name' => 'Smartwatch',
  'slug' => 'smartwatch',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 20,
  'name' => 'Audio',
  'slug' => 'audio',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 21,
  'name' => 'Smartphone',
  'slug' => 'smartphone',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 81,
  'post_date' => '2021-03-20 06:06:14',
  'post_date_gmt' => '2021-03-20 06:06:14',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/about.jpg" width="1380" height="395" title="" alt="">
<h1>About Us</h1>
<p>Our vision is to provide the highest quality and the most-up-to-date gadgets available in the market. We believe that technology enhances people\'s lives so we ensure that we make it readily available to everyone - anytime, anywhere. With a vast selection of gadgets and accessories, we will be your one-stop shop for all your technology needs.</p>
<p>Dating back to the year 2000, we operated as a reseller, making newly released gadgets readily available to consumers at limited quantities. We were operating as a team of two with the goal of creating a platform where everyone can stay up to date with the latest technology and gadgets. Over the years, we have made a mark on the industry as the leading gadget provider.</p>
<p>We feature a vast collection of the latest gadgets and technologies, with new discounts and deals daily. Watch product reviews and stay up to date to new releases and latest tech news. You can also discover our products in VR, AR and 3D to help you in your purchasing decision. Make sure to get notified for product releases, product reminders or sale reminders.</p>
<p>The best way to discover new products is through Gadgets. With a team of researchers, we ensure that we provide only the best selection of gadgets. We present the products the right way, to be as transparent and as informative about the product as possible. We specifically curate all the gadgets hand-picked by our team of technophiles.</p>
<h3> Why Choose Us</h3> <p>We are your one-stop shop for all your technology needs, and your up-to-date tech news. With guaranteed low prices and daily support available, you can be assured that you will be making the best purchase decision.</p>
<img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/free.png" width="61" height="59" title="Free Shipping" alt="For orders over $200"> <h3> Free Shipping </h3> For orders over $200
<img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/free-return.png" width="61" height="59" title="Free Returns" alt="30-day refund policy"> <h3> Free Returns </h3> 30-day refund policy
<img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/low-price.png" width="61" height="59" title="Low Price " alt="Guaranteed Low Prices"> <h3> Low Price </h3> Guaranteed Low Prices
<img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/support.png" width="61" height="59" title="Support" alt="Daily 9AM to 8PM EST"> <h3> Support </h3> Daily 9AM to 8PM EST
<h2>Our Headquarter</h2>
<h4>416-123-8899</h4> <p>123 Main Street Toronto, ON</p>
<a href="https://themify.me/" > Contact </a>
<p>Mon-Fri: 11am - 8pm<br />Sat - Sun: 11am - 6pm</p>
<img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/hq.jpg" width="690" height="511" title="" alt="">
<h2>Shop Categories</h2>
<a href="https://themify.me/demo/themes/ultra-gadgets/product/xiaomi-poco-m3/" > <img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/xiomipoco.png" width="74" height="112" title="POCO M3 " alt="MI"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/xiaomi-poco-m3/" > POCO M3 </a> </h3> MI
<a href="https://themify.me/demo/themes/ultra-gadgets/product/google-chrome-cast/" > <img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/chromecast.png" width="74" height="112" title="Chromecast" alt="Google"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/google-chrome-cast/" > Chromecast </a> </h3> Google
<a href="https://themify.me/demo/themes/ultra-gadgets/product/redmi-powerbank/" > <img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/redmi-powerbank.png" width="74" height="112" title="Powerbank" alt="Redmi"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/redmi-powerbank/" > Powerbank </a> </h3> Redmi
<a href="https://themify.me/demo/themes/ultra-gadgets/product/samsung-galaxy-sport-gear/" > <img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/samsung-smartwatch.png" width="74" height="112" title="Smartwatch" alt="Samsung"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/samsung-galaxy-sport-gear/" > Smartwatch </a> </h3> Samsung
<a href="https://themify.me/demo/themes/ultra-gadgets/product/airpods/" > <img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/airpods.png" width="74" height="112" title="Airpods" alt="Apple"> </a> <h3> <a href="https://themify.me/demo/themes/ultra-gadgets/product/airpods/" > Airpods </a> </h3> Apple
<img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/more.png" width="74" height="112" title="More" alt="More"> <h3> More </h3><!--/themify_builder_static-->',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2021-04-27 19:30:00',
  'post_modified_gmt' => '2021-04-27 19:30:00',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?page_id=81',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ax0n247\\",\\"cols\\":[{\\"element_id\\":\\"zgeo248\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"mj4s248\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":\\"rounded\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/about.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}},{\\"element_id\\":\\"kaaj248\\",\\"cols\\":[{\\"element_id\\":\\"wmxw248\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"j8ax248\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>About Us<\\\\/h1>\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"defi249\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Our vision is to provide the highest quality and the most-up-to-date gadgets available in the market. We believe that technology enhances people\\\'s lives so we ensure that we make it readily available to everyone - anytime, anywhere. With a vast selection of gadgets and accessories, we will be your one-stop shop for all your technology needs.<\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"line_height_unit\\":\\"em\\",\\"line_height\\":\\"1.5\\",\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.2\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"em\\",\\"line_height\\":\\"1.5\\",\\"font_size_unit\\":\\"em\\",\\"font_size\\":\\"1.2\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}}]}],\\"styling\\":{\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":8,\\"padding_left\\":8,\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"6\\",\\"text_align\\":\\"center\\",\\"padding_bottom\\":\\"20\\",\\"breakpoint_mobile\\":{\\"padding_left\\":5,\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":5,\\"padding_right_unit\\":\\"%\\"}}},{\\"element_id\\":\\"shxr249\\",\\"cols\\":[{\\"element_id\\":\\"dzl4249\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"u8ln249\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Dating back to the year 2000, we operated as a reseller, making newly released gadgets readily available to consumers at limited quantities. We were operating as a team of two with the goal of creating a platform where everyone can stay up to date with the latest technology and gadgets. Over the years, we have made a mark on the industry as the leading gadget provider.<\\\\/p>\\"}}]},{\\"element_id\\":\\"bgj4249\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ihla249\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>We feature a vast collection of the latest gadgets and technologies, with new discounts and deals daily. Watch product reviews and stay up to date to new releases and latest tech news. You can also discover our products in VR, AR and 3D to help you in your purchasing decision. Make sure to get notified for product releases, product reminders or sale reminders.<\\\\/p>\\"}}]},{\\"element_id\\":\\"j6i8249\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"m76b249\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>The best way to discover new products is through Gadgets. With a team of researchers, we ensure that we provide only the best selection of gadgets. We present the products the right way, to be as transparent and as informative about the product as possible. We specifically curate all the gadgets hand-picked by our team of technophiles.<\\\\/p>\\"}}]}]}]}],\\"styling\\":{\\"padding_top\\":\\"4\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"4\\",\\"padding_opp_bottom\\":\\"1\\"}},{\\"element_id\\":\\"iukh247\\",\\"cols\\":[{\\"element_id\\":\\"3ocb250\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"atez250\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3> Why Choose Us<\\\\/h3>\\\\n<p>We are your one-stop shop for all your technology needs, and your up-to-date tech news. With guaranteed low prices and daily support available, you can be assured that you will be making the best purchase decision.<\\\\/p>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"font_size_unit\\":\\"px\\",\\"font_size\\":\\"26\\",\\"padding_right\\":\\"80\\",\\"padding_left\\":\\"80\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_right\\":\\"0\\",\\"padding_left_unit\\":\\"px\\",\\"padding_left\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"px\\"}}}]}],\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"padding_top\\":\\"8\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":12,\\"padding_opp_bottom\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/banner-about.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"font_color\\":\\"#ffffff\\",\\"cover_color\\":\\"#000000_0.23\\",\\"cover_color-type\\":\\"color\\"}},{\\"element_id\\":\\"61qx247\\",\\"cols\\":[{\\"element_id\\":\\"8mvp250\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"p32a250\\",\\"cols\\":[{\\"element_id\\":\\"pit4250\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"j347250\\",\\"mod_settings\\":{\\"caption_image\\":\\"For orders over $200\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Free Shipping\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/free.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\"}}]},{\\"element_id\\":\\"8ne4250\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"33wt250\\",\\"mod_settings\\":{\\"caption_image\\":\\"30-day refund policy\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Free Returns\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/free-return.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\"}}]},{\\"element_id\\":\\"ukfl250\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3cuo250\\",\\"mod_settings\\":{\\"caption_image\\":\\"Guaranteed Low Prices\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Low Price \\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/low-price.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\"}}]},{\\"element_id\\":\\"6xo5251\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"qyao251\\",\\"mod_settings\\":{\\"caption_image\\":\\"Daily 9AM to 8PM EST\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Support\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/support.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\"}}]}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"background_color\\":\\"#ffffff\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_left\\":\\"5\\",\\"padding_bottom\\":\\"5\\",\\"padding_top\\":4,\\"b_ra_opp_left\\":false,\\"b_ra_right\\":\\"10\\",\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"10\\"}}]}],\\"styling\\":{\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":\\"1\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"%\\",\\"margin-top\\":\\"-7\\"}},{\\"element_id\\":\\"1xes247\\",\\"cols\\":[{\\"element_id\\":\\"73ua251\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"caji251\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Headquarter<\\\\/h2>\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false}},{\\"element_id\\":\\"flx8251\\",\\"cols\\":[{\\"element_id\\":\\"mc1b251\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"n423251\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>416-123-8899<\\\\/h4>\\\\n<p>123 Main Street Toronto, ON<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"7e3u251\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Contact\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}]},{\\"element_id\\":\\"qqgg251\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"a18n252\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Mon-Fri: 11am - 8pm<br \\\\/>Sat - Sun: 11am - 6pm<\\\\/p>\\"}}]}]}]},{\\"element_id\\":\\"8ceq252\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"n9mv252\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"511\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"690\\",\\"appearance_image\\":\\"rounded\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/hq.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\"},{\\"element_id\\":\\"zsi5247\\",\\"cols\\":[{\\"element_id\\":\\"zblc252\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"cr7a252\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Shop Categories<\\\\/h2>\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"30\\",\\"margin_opp_bottom\\":false}},{\\"element_id\\":\\"w6gz252\\",\\"cols\\":[{\\"element_id\\":\\"q5bg252\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"009b252\\",\\"mod_settings\\":{\\"caption_image\\":\\"MI\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"POCO M3 \\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/xiomipoco.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/xiaomi-poco-m3\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_bottom\\":\\"15\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"sc07252\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"gk06253\\",\\"mod_settings\\":{\\"caption_image\\":\\"Google\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Chromecast\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/chromecast.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":\\"1\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/google-chrome-cast\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"297a253\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"xp86253\\",\\"mod_settings\\":{\\"caption_image\\":\\"Redmi\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Powerbank\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/redmi-powerbank.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/redmi-powerbank\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"dddy253\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2nsf253\\",\\"mod_settings\\":{\\"caption_image\\":\\"Samsung\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Smartwatch\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/samsung-smartwatch.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/samsung-galaxy-sport-gear\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"8rvd253\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"xk74253\\",\\"mod_settings\\":{\\"caption_image\\":\\"Apple\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Airpods\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/airpods.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/product\\\\/airpods\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"t6m7253\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3s8w253\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"More\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/more.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}]}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"4\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":7,\\"text_align\\":\\"center\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 89,
  'post_date' => '2021-03-20 06:59:04',
  'post_date_gmt' => '2021-03-20 06:59:04',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/contact-banner-no-corner.jpg" width="1200" height="395" title="" alt="">
<h2>Contact Us</h2> <p>For quickest answers to common questions, refer to our FAQ below. </p> <p>Couldn\'t find the answer your looking for? Contact us at 1-800-000-000 or email us at info@gadgets.com and we\'ll make sure you get the information you need.</p>
<img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/customer-support.png" width="61" height="59" title="Customer Support" alt="Available Monday-Friday between 9am-8pm EST"> <h3> Customer Support </h3> Available Monday-Friday between 9am-8pm EST
<a href="https://themify.me/" > Get Support </a>
<img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/partnership.png" width="61" height="59" title="Partnership Info" alt="We are always seeking for partnership opportunities."> <h3> Partnership Info </h3> We are always seeking for partnership opportunities.
<a href="https://themify.me/" > Partner With Us </a>
<img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/03/return-policy.png" width="61" height="59" title="Shipping &amp; Return Policy" alt="Fast, Free Shipping and Easy Returns."> <h3> Shipping & Return Policy </h3> Fast, Free Shipping and Easy Returns.
<a href="https://themify.me/" > Return Policy </a>
<h2>Our Stores</h2>
<h3>Store Electronic Center</h3>
<i><svg aria-hidden="true"><use href="#tf-ti-location-pin"></use></svg></i> 2406 Brook St, Newcombville Nova Scotia, Canada
<i><svg aria-hidden="true"><use href="#tf-ti-mobile"></use></svg></i> (514)849-123
<i><svg aria-hidden="true"><use href="#tf-ti-time"></use></svg></i> Mon-Fri: 11am - 8pm <br/>Sat & Sun: 11am - 6pm
<a href="https://themify.me"> <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> Get Direction </a>
<h3>Store Electronic Center</h3>
<i><svg aria-hidden="true"><use href="#tf-ti-location-pin"></use></svg></i> 2406 Brook St, Newcombville Nova Scotia, Canada
<i><svg aria-hidden="true"><use href="#tf-ti-mobile"></use></svg></i> (514)849-123
<i><svg aria-hidden="true"><use href="#tf-ti-time"></use></svg></i> Mon-Fri: 11am - 8pm <br/>Sat & Sun: 11am - 6pm
<a href="https://themify.me"> <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> Get Direction </a>
<h3>Store Electronic Center</h3>
<i><svg aria-hidden="true"><use href="#tf-ti-location-pin"></use></svg></i> 2406 Brook St, Newcombville Nova Scotia, Canada
<i><svg aria-hidden="true"><use href="#tf-ti-mobile"></use></svg></i> (514)849-123
<i><svg aria-hidden="true"><use href="#tf-ti-time"></use></svg></i> Mon-Fri: 11am - 8pm <br/>Sat & Sun: 11am - 6pm
<a href="https://themify.me"> <i><svg aria-hidden="true"><use href="#tf-ti-arrow-right"></use></svg></i> Get Direction </a>
<h2>FAQs</h2>
<ul><li><h4>How to Buy?</h4><p>You can either Order online or Shop in-store.</p> <p><strong>Order Online</strong></p> <p>Place an order online by selecting the items you wish to purchase and adding them to cart and checkout.</p> <p><strong>Shop In-store</strong></p> <p>Visit any one of our three stores to shop.</p></li><li><h4>How to Checkout?</h4><p>When checking out, ensure that you fill in your complete shipping address and payment details, and place your order. You will receive a confirmation email of your order and a separate email when your items have been shipped.</p></li><li><h4>How to Payment?</h4><p>We accept all major credit cards and debit cards. Other payment method also include Paypal.</p></li><li><h4>How to Cancel Order?</h4><p>You can cancel your order online within 24 hours of placing it.</p> <p>If you created an account online, follow these steps to cancel your order:</p> <ul> <li>Login into My Account</li> <li>Click on Orders and select the order # you wish to cancel</li> <li>Click "Cancel"</li> </ul> <p>If you wish to cancel after 24 hours and we still have\'t shipped your order, please send us an email at orders@gadgets.com.</p></li><li><h4>How to Become Reseller?</h4><p>We have a number of packages available for resellers. Contact us at reselling@gadgets.com to get in touch with one of our agents to provide you with more information, as well as, the terms and conditions.</p></li></ul><!--/themify_builder_static-->',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2021-04-27 19:31:57',
  'post_modified_gmt' => '2021-04-27 19:31:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?page_id=89',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"rscp34\\",\\"cols\\":[{\\"element_id\\":\\"b8a535\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"lsac35\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/contact-banner-no-corner.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"checkbox_i_t_r_c_apply_all\\":\\"1\\",\\"i_t_r_c_opp_left\\":false,\\"i_t_r_c_opp_top\\":false,\\"i_t_r_c_top\\":\\"8\\"}},{\\"element_id\\":\\"178w35\\",\\"cols\\":[{\\"element_id\\":\\"rx0h35\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"w50n35\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Contact Us<\\\\/h2>\\\\n<p>For quickest answers to common questions, refer to our FAQ below. <\\\\/p>\\\\n<p>Couldn\\\'t find the answer your looking for? Contact us at 1-800-000-000 or email us at info@gadgets.com and we\\\'ll make sure you get the information you need.<\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"margin_top\\":\\"50\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_right\\":\\"19\\",\\"padding_left\\":\\"19\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"0\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"0\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"px\\"},\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\"}}]}],\\"gutter\\":\\"gutter-none\\"},{\\"element_id\\":\\"cd6p35\\",\\"cols\\":[{\\"element_id\\":\\"mioq36\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"87a036\\",\\"mod_settings\\":{\\"caption_image\\":\\"Available Monday-Friday between 9am-8pm EST\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Customer Support\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/customer-support.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\",\\"font_color_type\\":\\"font_color_solid\\",\\"border-type\\":\\"right\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_right_width\\":\\"0\\",\\"border_right_color\\":\\"#000000_0.00\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top_unit\\":\\"px\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"10xb36\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Get Support\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2\\",\\"text_align\\":\\"center\\",\\"border-type\\":\\"right\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"breakpoint_mobile\\":{\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_left\\":\\"0\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_opp_top\\":false,\\"b_ra_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_right_width\\":\\"0\\",\\"border_right_color\\":\\"#000000_0.00\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"5\\"},\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#000000_0.10\\",\\"border_top_style\\":\\"solid\\",\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_top_unit\\":\\"px\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\"}},{\\"element_id\\":\\"ktss36\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"glen36\\",\\"mod_settings\\":{\\"caption_image\\":\\"We are always seeking for partnership opportunities.\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Partnership Info\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/partnership.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\",\\"font_color_type\\":\\"font_color_solid\\",\\"border-type\\":\\"right\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_right_width\\":\\"0\\",\\"border_right_color\\":\\"#000000_0.00\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"checkbox_padding_apply_all\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top_unit\\":\\"px\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"bw3n36\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Partner With Us\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2\\",\\"text_align\\":\\"center\\",\\"border-type\\":\\"right\\",\\"padding_bottom\\":\\"2\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"border_right_width\\":\\"1\\",\\"border_right_color\\":\\"#000000_0.10\\",\\"breakpoint_mobile\\":{\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_right_width\\":\\"0\\",\\"border_right_color\\":\\"#000000_0.00\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"right\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"5\\"},\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_opp_top\\":false,\\"b_ra_top_unit\\":\\"px\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\"}},{\\"element_id\\":\\"545n36\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"1gmw37\\",\\"mod_settings\\":{\\"caption_image\\":\\"Fast, Free Shipping and Easy Returns.\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Shipping & Return Policy\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/return-policy.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"59\\",\\"width_image\\":\\"61\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"w03b37\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Return Policy\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2\\",\\"text_align\\":\\"center\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"breakpoint_mobile\\":{\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_bottom\\":\\"8\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_left\\":\\"8\\",\\"b_ra_opp_left\\":false,\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_opp_top\\":false,\\"b_ra_top_unit\\":\\"px\\"},\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"top\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"padding_right\\":\\"5\\",\\"padding_left\\":\\"5\\",\\"padding_bottom\\":\\"2\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"zi\\":\\"1\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false,\\"ht_auto_height\\":false,\\"motion_effects\\":{\\"s\\":{\\"val\\":{\\"s_origin\\":\\"50,50\\"}}},\\"cover_gradient-circle-radial\\":false,\\"cover_gradient-gradient-angle\\":\\"180\\",\\"cover_gradient-gradient-type\\":\\"linear\\",\\"cover_color-type\\":\\"color\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"checkbox_margin_apply_all\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_b_ra_apply_all\\":false,\\"b_ra_bottom_unit\\":\\"px\\",\\"b_ra_bottom\\":\\"8\\",\\"b_ra_left_unit\\":\\"px\\",\\"b_ra_left\\":\\"8\\",\\"b_ra_right_unit\\":\\"px\\",\\"b_ra_top_unit\\":\\"px\\",\\"background_color\\":\\"#ffffff\\",\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_bottom\\":\\"3\\",\\"padding_top\\":\\"2\\"}}]}],\\"styling\\":{\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"4\\"}},{\\"element_id\\":\\"823134\\",\\"cols\\":[{\\"element_id\\":\\"nrfy37\\",\\"grid_class\\":\\"col-full\\"}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"20\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/03\\\\/laptops.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\",\\"margin-top\\":\\"-150\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\"}},{\\"element_id\\":\\"5zna34\\",\\"cols\\":[{\\"element_id\\":\\"7r4z37\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ki6d37\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Our Stores<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom_unit\\":\\"%\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"3\\",\\"margin_opp_bottom\\":false}},{\\"element_id\\":\\"nzv137\\",\\"cols\\":[{\\"element_id\\":\\"lonu37\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"jqiz37\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Store Electronic Center<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"1.04\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"vrgj38\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-location-pin\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"2406 Brook St, Newcombville Nova Scotia, Canada\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_bottom\\":\\"25\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"m_i_top\\":\\"0\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"m_i_right\\":\\"15\\",\\"p_i_right\\":\\"0\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"5qxv38\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-mobile\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"(514)849-123\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"2jx138\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-time\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Mon-Fri: 11am - 8pm <br\\\\/>Sat & Sun: 11am - 6pm\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"m_i_bottom\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"cu1138\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Get Direction\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_vertical\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"icon_position\\":\\"right\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border_top_width\\":\\"1\\",\\"border_top_color\\":\\"#dedede\\",\\"border-type\\":\\"top\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\"}}],\\"styling\\":{\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2.5\\",\\"background_color\\":\\"#eef0f4\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right\\":\\"3\\",\\"padding_left\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"1.5\\"}},{\\"element_id\\":\\"dp1o38\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ar4338\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Store Electronic Center<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"1.04\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"961e38\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-location-pin\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"2406 Brook St, Newcombville Nova Scotia, Canada\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_bottom\\":\\"25\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"m_i_top\\":\\"0\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"m_i_right\\":\\"15\\",\\"p_i_right\\":\\"0\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"qsdm38\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-mobile\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"(514)849-123\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"g8ax38\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-time\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Mon-Fri: 11am - 8pm <br\\\\/>Sat & Sun: 11am - 6pm\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"m_i_bottom\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"78ni38\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Get Direction\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_vertical\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"icon_position\\":\\"right\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border_top_width\\":\\"1\\",\\"border_top_color\\":\\"#dedede\\",\\"border-type\\":\\"top\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\"}}],\\"styling\\":{\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2.5\\",\\"background_color\\":\\"#eef0f4\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right\\":\\"3\\",\\"padding_left\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"1.5\\"}},{\\"element_id\\":\\"zjae38\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"w5iq38\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Store Electronic Center<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"1.04\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"ld5h38\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-location-pin\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"2406 Brook St, Newcombville Nova Scotia, Canada\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_bottom\\":\\"25\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"m_i_top\\":\\"0\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"m_i_right\\":\\"15\\",\\"p_i_right\\":\\"0\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"ad8738\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-mobile\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"(514)849-123\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"c06c38\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-time\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Mon-Fri: 11am - 8pm <br\\\\/>Sat & Sun: 11am - 6pm\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"m_i_bottom\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\",\\"m_i_right\\":\\"15\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_right\\":\\"0\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_left\\":\\"0\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"f_s_i_unit\\":\\"px\\",\\"f_s_i\\":\\"24\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"2f9738\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-arrow-right\\",\\"icon_color_bg\\":\\"transparent\\",\\"label\\":\\"Get Direction\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_vertical\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_m_i_apply_all\\":false,\\"m_i_right_unit\\":\\"px\\",\\"m_i_left_unit\\":\\"px\\",\\"m_i_opp_left\\":false,\\"m_i_bottom_unit\\":\\"px\\",\\"m_i_opp_bottom\\":false,\\"m_i_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_bottom\\":false,\\"margin_top_unit\\":\\"px\\",\\"icon_position\\":\\"right\\",\\"checkbox_p_i_apply_all\\":false,\\"p_i_right_unit\\":\\"px\\",\\"p_i_left_unit\\":\\"px\\",\\"p_i_opp_left\\":false,\\"p_i_bottom_unit\\":\\"px\\",\\"p_i_opp_bottom\\":false,\\"p_i_top_unit\\":\\"px\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border_top_width\\":\\"1\\",\\"border_top_color\\":\\"#dedede\\",\\"border-type\\":\\"top\\",\\"checkbox_padding_apply_all\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_opp_bottom\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"20\\",\\"font_color_icon\\":\\"#198be3\\"}}],\\"styling\\":{\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"2.5\\",\\"background_color\\":\\"#eef0f4\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_right\\":\\"3\\",\\"padding_left\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"1.5\\"}}]}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"5\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"5\\"}},{\\"element_id\\":\\"pvrf34\\",\\"cols\\":[{\\"element_id\\":\\"fc1439\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2vf139\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>FAQs<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_bottom_unit\\":\\"%\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"3\\",\\"margin_opp_bottom\\":false}},{\\"mod_name\\":\\"accordion\\",\\"element_id\\":\\"6uyc39\\",\\"mod_settings\\":{\\"content_accordion\\":[{\\"title_accordion\\":\\"How to Buy?\\",\\"text_accordion\\":\\"<p>You can either Order online or Shop in-store.<\\\\/p>\\\\n<p><strong>Order Online<\\\\/strong><\\\\/p>\\\\n<p>Place an order online by selecting the items you wish to purchase and adding them to cart and checkout.<\\\\/p>\\\\n<p><strong>Shop In-store<\\\\/strong><\\\\/p>\\\\n<p>Visit any one of our three stores to shop.<\\\\/p>\\",\\"default_accordion\\":\\"open\\"},{\\"title_accordion\\":\\"How to Checkout?\\",\\"text_accordion\\":\\"<p>When checking out, ensure that you fill in your complete shipping address and payment details, and place your order. You will receive a confirmation email of your order and a separate email when your items have been shipped.<\\\\/p>\\",\\"default_accordion\\":\\"closed\\"},{\\"title_accordion\\":\\"How to Payment?\\",\\"text_accordion\\":\\"<p>We accept all major credit cards and debit cards. Other payment method also include Paypal.<\\\\/p>\\",\\"default_accordion\\":\\"closed\\"},{\\"title_accordion\\":\\"How to Cancel Order?\\",\\"text_accordion\\":\\"<p>You can cancel your order online within 24 hours of placing it.<\\\\/p>\\\\n<p>If you created an account online, follow these steps to cancel your order:<\\\\/p>\\\\n<ul>\\\\n<li>Login into My Account<\\\\/li>\\\\n<li>Click on Orders and select the order # you wish to cancel<\\\\/li>\\\\n<li>Click \\\\\\"Cancel\\\\\\"<\\\\/li>\\\\n<\\\\/ul>\\\\n<p>If you wish to cancel after 24 hours and we still have\\\'t shipped your order, please send us an email at orders@gadgets.com.<\\\\/p>\\",\\"default_accordion\\":\\"closed\\"},{\\"title_accordion\\":\\"How to Become Reseller?\\",\\"text_accordion\\":\\"<p>We have a number of packages available for resellers. Contact us at reselling@gadgets.com to get in touch with one of our agents to provide you with more information, as well as, the terms and conditions.<\\\\/p>\\",\\"default_accordion\\":\\"closed\\"}],\\"accordion_appearance_accordion\\":false,\\"expand_collapse_accordion\\":\\"toggle\\",\\"icon_active_accordion\\":\\"ti-minus\\",\\"icon_accordion\\":\\"ti-plus\\",\\"color_accordion\\":\\"transparent\\",\\"b_ct_left_style\\":\\"solid\\",\\"b_ct_bottom_style\\":\\"solid\\",\\"b_ct_right_style\\":\\"solid\\",\\"b_ct_top_style\\":\\"solid\\",\\"b_ct_top_width\\":\\"1\\",\\"b_ct_top_color\\":\\"#dddddd\\",\\"b_ct-type\\":\\"top\\",\\"icon_size_unit\\":\\"px\\",\\"icon_active_color\\":\\"#198be3\\",\\"icon_color\\":\\"#198be3\\",\\"checkbox_p_a_t_apply_all\\":false,\\"p_a_t_right_unit\\":\\"px\\",\\"p_a_t_left_unit\\":\\"px\\",\\"p_a_t_opp_left\\":false,\\"p_a_t_bottom_unit\\":\\"px\\",\\"p_a_t_bottom\\":\\"26\\",\\"p_a_t_opp_bottom\\":\\"1\\",\\"p_a_t_top_unit\\":\\"px\\",\\"p_a_t_top\\":\\"26\\",\\"t_sh_t_blur_unit\\":\\"px\\",\\"t_sh_t_vShadow_unit\\":\\"px\\",\\"t_sh_t_hShadow_unit\\":\\"px\\",\\"l_s_t_unit\\":\\"em\\",\\"line_height_title_unit\\":\\"px\\",\\"font_size_title_unit\\":\\"em\\",\\"font_size_title\\":\\"1.4\\",\\"font_color_title\\":\\"#000000\\",\\"checkbox_p_ct_apply_all\\":false,\\"p_ct_right_unit\\":\\"px\\",\\"p_ct_left_unit\\":\\"px\\",\\"p_ct_opp_left\\":false,\\"p_ct_bottom_unit\\":\\"px\\",\\"p_ct_opp_bottom\\":false,\\"p_ct_top_unit\\":\\"px\\",\\"l_s_t\\":\\".03\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"4\\",\\"padding_opp_bottom\\":false}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 6,
  'post_date' => '2021-03-04 05:23:42',
  'post_date_gmt' => '2021-03-04 05:23:42',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><p><small><strong>FEATURED PRODUCT</strong></small></p> <h1>Stay connected with Google Duo</h1> <p>Make calling your loved ones much easier and much more intimate, so you never have to miss a moment!</p>
<a href="https://themify.me/" > View details </a>
<img src="https://themify.me/demo/themes/ultra-gadgets/files/2021/02/Gadget-featured-600x410.jpg" width="600" height="410" title="" alt="">
<a href="https://themify.me/demo/themes/shoppe-gadgets/product/xiaomi-poco-m3/" > <img loading="lazy" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/xiomipoco-74x112.png" width="74" height="112" title="POCO M3 " alt="MI"> </a> <h3> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/xiaomi-poco-m3/" > POCO M3 </a> </h3> MI

<a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-chrome-cast/" > <img loading="lazy" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/chromecast-74x112.png" width="74" height="112" title="Chromecast" alt="Google"> </a> <h3> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-chrome-cast/" > Chromecast </a> </h3> Google
<a href="https://themify.me/demo/themes/shoppe-gadgets/product/redmi-powerbank/" > <img loading="lazy" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/redmi-powerbank-74x112.png" width="74" height="112" title="Powerbank" alt="Redmi"> </a> <h3> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/redmi-powerbank/" > Powerbank </a> </h3> Redmi
<a href="https://themify.me/demo/themes/shoppe-gadgets/product/samsung-galaxy-sport-gear/" > <img loading="lazy" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/samsung-smartwatch-74x112.png" width="74" height="112" title="Smartwatch" alt="Samsung"> </a> <h3> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/samsung-galaxy-sport-gear/" > Smartwatch </a> </h3> Samsung
<a href="https://themify.me/demo/themes/shoppe-gadgets/product/airpods/" > <img loading="lazy" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/airpods-74x112.png" width="74" height="112" title="Airpods" alt="Apple"> </a> <h3> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/airpods/" > Airpods </a> </h3> Apple
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/more-74x112.png" width="74" height="112" title="More" alt="More"> <h3> More </h3>
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-vr-690x498.jpg" width="690" height="498" title="google-vr" alt="google-vr" srcset="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-vr.jpg 690w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-vr-600x433.jpg 600w" sizes="(max-width: 690px) 100vw, 690px" />
<h2>Entertainment that you love. With a little help from Google.</h2> <p>Exclusive Google Store bundle: Buy Chromecast with Google TV and 6 months of Netflix for just $119.99 CAD.*</p>
<a href="https://themify.me/" > View product </a>
<h2>Helpful thermostat cosy price.</h2> <p>The new Nest Thermostat</p>
<a href="https://themify.me/" > View product </a>
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/thermo-690x498.jpg" width="690" height="498" title="thermo" alt="thermo" srcset="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/thermo.jpg 690w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/thermo-600x433.jpg 600w" sizes="(max-width: 690px) 100vw, 690px" />
<h2>Recommended Product</h2>
<h3>Room-filling Audio Package</h3> <p>2 Nest Audio speakers</p>
<a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-nest-speaker/" > <img loading="lazy" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/nest-room-428x323.jpg" width="428" height="323" title="nest-room" alt="nest-room"> </a>
<p>Save $25</p> <h3> $234.98</h3>
<a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-nest-speaker/" > View product </a>
<h3>Nested Mini Speakers</h3> <p>2 Nest Audio speakers</p>
<a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-nest-mini-speakers/" > <img loading="lazy" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/nest-audio-428x323.jpg" width="428" height="323" title="nest-audio" alt="nest-audio"> </a>
<p>Save $25</p> <h3> $234.98</h3>
<a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-nest-mini-speakers/" > View product </a>
<h3>Nest Hub Max</h3> <p>2 Nest Audio speakers</p>
<a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-nest-hub-max/" > <img loading="lazy" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/nest-product-428x323.jpg" width="428" height="323" title="nest-product" alt="nest-product"> </a>
<p>Save $25</p> <h3> $234.98</h3>
<a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-nest-hub-max/" > View product </a>
<h2>Apps to push you further</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida.</p>
<a href="https://themify.me/"> <i><svg aria-hidden="true"><use href="#tf-ti-control-play"></use></svg></i> Recommended Apps </a>
<h2>This week highlights</h2>
<ul data-lazy="1"> <li> <figure> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/airpods/" title="AirPods"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/airpods.jpg" title="airpods" alt="airpods" srcset="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/airpods.jpg 1200w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/airpods-544x600.jpg 544w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/airpods-768x847.jpg 768w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/airpods-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/airpods/" title="AirPods"> AirPods </a> </h3> 
 <bdi>&#36;120.00</bdi> <p><a href="?add-to-cart=57" data-quantity="1" data-product_id="57" data-product_sku="" aria-label="Add &ldquo;AirPods&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/iphone-12-pro-max/" title="iPhone 12 Pro Max"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/iPhone-12-max-pro.jpg" title="iPhone-12-max-pro" alt="iPhone-12-max-pro" srcset="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/iPhone-12-max-pro.jpg 1200w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/iPhone-12-max-pro-544x600.jpg 544w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/iPhone-12-max-pro-768x847.jpg 768w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/iPhone-12-max-pro-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/iphone-12-pro-max/" title="iPhone 12 Pro Max"> iPhone 12 Pro Max </a> </h3> 
 <bdi>&#36;1,100.00</bdi> <p><a href="?add-to-cart=54" data-quantity="1" data-product_id="54" data-product_sku="" aria-label="Add &ldquo;iPhone 12 Pro Max&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-nest-wifi-cam/" title="Google Nest Wifi Cam"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/nest-cam.jpg" title="nest-cam" alt="nest-cam" srcset="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/nest-cam.jpg 1200w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/nest-cam-544x600.jpg 544w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/nest-cam-768x847.jpg 768w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/nest-cam-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-nest-wifi-cam/" title="Google Nest Wifi Cam"> Google Nest Wifi Cam </a> </h3> 
 <bdi>&#36;125.00</bdi> <p><a href="?add-to-cart=52" data-quantity="1" data-product_id="52" data-product_sku="" aria-label="Add &ldquo;Google Nest Wifi Cam&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/harman-kardon-onix/" title="Harman &#038; Kardon Onix"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/harman-kardon-onix.jpg" title="harman-kardon-onix" alt="harman-kardon-onix" srcset="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/harman-kardon-onix.jpg 1200w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/harman-kardon-onix-544x600.jpg 544w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/harman-kardon-onix-768x847.jpg 768w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/harman-kardon-onix-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/harman-kardon-onix/" title="Harman &#038; Kardon Onix"> Harman &#038; Kardon Onix </a> </h3> 
 <bdi>&#36;150.00</bdi> <p><a href="?add-to-cart=50" data-quantity="1" data-product_id="50" data-product_sku="" aria-label="Add &ldquo;Harman &amp; Kardon Onix&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-nest-thermostat/" title="Google Nest Thermostat"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-nest-thermostat.jpg" title="google-nest-thermostat" alt="google-nest-thermostat" srcset="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-nest-thermostat.jpg 1200w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-nest-thermostat-544x600.jpg 544w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-nest-thermostat-768x847.jpg 768w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-nest-thermostat-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/google-nest-thermostat/" title="Google Nest Thermostat"> Google Nest Thermostat </a> </h3> 
 <bdi>&#36;250.00</bdi> <p><a href="?add-to-cart=48" data-quantity="1" data-product_id="48" data-product_sku="" aria-label="Add &ldquo;Google Nest Thermostat&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> <li> <figure> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/samsung-galaxy-sport-gear/" title="Samsung Galaxy Sport Gear"><img loading="lazy" width="1200" height="1324" src="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/samsung-galaxy-gear-sport.jpg" title="samsung-galaxy-gear-sport" alt="samsung-galaxy-gear-sport" srcset="https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/samsung-galaxy-gear-sport.jpg 1200w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/samsung-galaxy-gear-sport-544x600.jpg 544w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/samsung-galaxy-gear-sport-768x847.jpg 768w, https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/samsung-galaxy-gear-sport-600x662.jpg 600w" sizes="(max-width: 1200px) 100vw, 1200px" /></a> </figure> <h3> <a href="https://themify.me/demo/themes/shoppe-gadgets/product/samsung-galaxy-sport-gear/" title="Samsung Galaxy Sport Gear"> Samsung Galaxy Sport Gear </a> </h3> 
 <bdi>&#36;350.00</bdi> <p><a href="?add-to-cart=45" data-quantity="1" data-product_id="45" data-product_sku="" aria-label="Add &ldquo;Samsung Galaxy Sport Gear&rdquo; to your cart" rel="nofollow">Add to cart</a></p> </li> </ul><!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2021-04-20 20:19:49',
  'post_modified_gmt' => '2021-04-20 20:19:49',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?page_id=6',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"fko889\\",\\"cols\\":[{\\"element_id\\":\\"jtdp90\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"36pa91\\",\\"cols\\":[{\\"element_id\\":\\"ed0y91\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"8jfy91\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><small><strong>FEATURED PRODUCT<\\\\/strong><\\\\/small><\\\\/p>\\\\n<h1>Stay connected with Google Duo<\\\\/h1>\\\\n<p>Make calling your loved ones much easier and much more intimate, so you never have to miss a moment!<\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_opp_bottom\\":false}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"txrw91\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View details\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}],\\"styling\\":{\\"padding_left\\":\\"50\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"resp_no_bg\\":false,\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"2hgy92\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"7dzf92\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-gadgets\\\\/files\\\\/2021\\\\/02\\\\/Gadget-featured-600x410.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-right\\",\\"width_image\\":\\"600\\",\\"title_tag\\":\\"h3\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_top\\":35,\\"padding_opp_top\\":\\"1\\",\\"padding_bottom\\":35,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top_unit\\":\\"px\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"resp_no_bg\\":false,\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"10\\",\\"background_color\\":\\"#e6e7ea\\"}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"resp_no_bg\\":false}}],\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"6\\",\\"padding_top\\":30}},{\\"element_id\\":\\"y93y704\\",\\"cols\\":[{\\"element_id\\":\\"jyuw710\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"xaq3710\\",\\"mod_settings\\":{\\"caption_image\\":\\"MI\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"POCO M3 \\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/xiomipoco.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/product\\\\/xiaomi-poco-m3\\\\/\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"bds3710\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"6\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":\\"1\\",\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"pfks710\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"ra4o710\\",\\"mod_settings\\":{\\"caption_image\\":\\"Google\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Chromecast\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/chromecast.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":\\"1\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/product\\\\/google-chrome-cast\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"vuhp710\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3pb1710\\",\\"mod_settings\\":{\\"caption_image\\":\\"Redmi\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Powerbank\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/redmi-powerbank.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/product\\\\/redmi-powerbank\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_i_h-type\\":\\"top\\",\\"p_i_h_opp_left\\":false,\\"p_i_h_opp_bottom\\":false,\\"b_p_i_h\\":\\"50,50\\",\\"b_a_i_h\\":\\"scroll\\",\\"b_r_i_h\\":\\"repeat\\",\\"border_inner-type\\":\\"top\\",\\"padding_inner_opp_left\\":false,\\"padding_inner_opp_bottom\\":false,\\"background_position_inner\\":\\"50,50\\",\\"background_attachment_inner\\":\\"scroll\\",\\"background_repeat_inner\\":\\"repeat\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"h93m711\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"9vbz711\\",\\"mod_settings\\":{\\"caption_image\\":\\"Samsung\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Smartwatch\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/samsung-smartwatch.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/product\\\\/samsung-galaxy-sport-gear\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"4jgs711\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"hy0k711\\",\\"mod_settings\\":{\\"caption_image\\":\\"Apple\\",\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"Airpods\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/airpods.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/product\\\\/airpods\\\\/\\"}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"j2ly711\\",\\"grid_class\\":\\"col6-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"4nin711\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"title_image\\":\\"More\\",\\"height_image\\":\\"112\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"74\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/more.png\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"i_t_m_opp_left\\":false,\\"i_t_m_opp_bottom\\":false}}],\\"styling\\":{\\"margin-top_opp_top\\":false,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"20\\",\\"padding_top\\":\\"20\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color-type\\":\\"color\\",\\"checkbox_b_ra_apply_all\\":\\"1\\",\\"b_ra_opp_left\\":false,\\"b_ra_opp_top\\":false,\\"b_ra_top\\":\\"8\\",\\"b_c_h\\":\\"#f8f8f8\\",\\"b_p_h\\":\\"50,50\\",\\"b_a_h\\":\\"scroll\\",\\"b_r_h\\":\\"repeat\\",\\"b_g_h-circle-radial\\":false,\\"b_t_h\\":\\"image\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"column_alignment\\":\\"col_align_middle\\"},{\\"element_id\\":\\"4xk2704\\",\\"cols\\":[{\\"element_id\\":\\"clxs712\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"6cng712\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"498\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"690\\",\\"appearance_image\\":\\"rounded\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/google-vr.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]},{\\"element_id\\":\\"ktw5712\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"8zc1712\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Entertainment that you love. With a little help from Google.<\\\\/h2>\\\\n<p>Exclusive Google Store bundle: Buy Chromecast with Google TV and 6 months of Netflix for just $119.99 CAD.*<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"rd47712\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View product\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"6\\"}},{\\"element_id\\":\\"l4wr704\\",\\"cols\\":[{\\"element_id\\":\\"at31713\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"mw17713\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Helpful thermostat cosy price.<\\\\/h2>\\\\n<p>The new Nest Thermostat<\\\\/p>\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"doih713\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View product\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\"}}]},{\\"element_id\\":\\"wbkz713\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3nqz713\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"498\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"690\\",\\"appearance_image\\":\\"rounded\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/thermo.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}},{\\"element_id\\":\\"mlyl704\\",\\"cols\\":[{\\"element_id\\":\\"q1ca714\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"f81u714\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Recommended Product<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"50\\",\\"margin_opp_bottom\\":false}},{\\"element_id\\":\\"q7m2714\\",\\"cols\\":[{\\"element_id\\":\\"ei5e714\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"mzpp714\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Room-filling Audio Package<\\\\/h3>\\\\n<p>2 Nest Audio speakers<\\\\/p>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"lssm714\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"323\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"428\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/nest-room.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/product\\\\/google-nest-speaker\\\\/\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"q9p9714\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Save $25<\\\\/p>\\\\n<h3> $234.98<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"p_margin_bottom_unit\\":\\"px\\",\\"p_margin_bottom\\":\\"10\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"20\\",\\"margin_opp_bottom\\":false,\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"x8go715\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View product\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/product\\\\/google-nest-speaker\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\",\\"alignment\\":\\"center\\"}}],\\"styling\\":{\\"background_color\\":\\"#e6e7ea\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"40\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"40\\",\\"b_ra_bottom\\":\\"8\\",\\"b_ra_left\\":\\"8\\",\\"b_ra_opp_left\\":\\"1\\",\\"b_ra_right\\":\\"8\\",\\"b_ra_opp_top\\":\\"1\\",\\"b_ra_top\\":\\"8\\"}},{\\"element_id\\":\\"mqm4715\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"mxo5715\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Nested Mini Speakers<\\\\/h3>\\\\n<p>2 Nest Audio speakers<\\\\/p>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"y5mc715\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"323\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"428\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/nest-audio.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/product\\\\/google-nest-mini-speakers\\\\/\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"7hoc715\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Save $25<\\\\/p>\\\\n<h3> $234.98<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"p_margin_bottom_unit\\":\\"px\\",\\"p_margin_bottom\\":\\"10\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"20\\",\\"padding_opp_left\\":false}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"r9i8715\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View product\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/product\\\\/google-nest-mini-speakers\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\",\\"alignment\\":\\"center\\"}}],\\"styling\\":{\\"background_color\\":\\"#e6e7ea\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"40\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"40\\",\\"b_ra_bottom\\":\\"8\\",\\"b_ra_left\\":\\"8\\",\\"b_ra_opp_left\\":\\"1\\",\\"b_ra_right\\":\\"8\\",\\"b_ra_opp_top\\":\\"1\\",\\"b_ra_top\\":\\"8\\"}},{\\"element_id\\":\\"694w715\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2nny715\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Nest Hub Max<\\\\/h3>\\\\n<p>2 Nest Audio speakers<\\\\/p>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"t8u9715\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"323\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"428\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/nest-product.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/product\\\\/google-nest-hub-max\\\\/\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"4azy716\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Save $25<\\\\/p>\\\\n<h3> $234.98<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"22\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"p_margin_bottom_unit\\":\\"px\\",\\"p_margin_bottom\\":\\"10\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"20\\",\\"padding_opp_left\\":false}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"sodc716\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View product\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/product\\\\/google-nest-hub-max\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"blue\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"normal\\",\\"alignment\\":\\"center\\"}}],\\"styling\\":{\\"background_color\\":\\"#e6e7ea\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"40\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"40\\",\\"b_ra_bottom\\":\\"8\\",\\"b_ra_left\\":\\"8\\",\\"b_ra_opp_left\\":\\"1\\",\\"b_ra_right\\":\\"8\\",\\"b_ra_opp_top\\":\\"1\\",\\"b_ra_top\\":\\"8\\"}}],\\"gutter\\":\\"gutter-narrow\\"}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_bottom\\":false,\\"padding_top\\":\\"6\\"}},{\\"element_id\\":\\"z060704\\",\\"cols\\":[{\\"element_id\\":\\"mw6b716\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"yt05716\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Apps to push you further<\\\\/h2>\\"}},{\\"element_id\\":\\"9mfz103\\",\\"cols\\":[{\\"element_id\\":\\"jtq0103\\",\\"grid_class\\":\\"col4-1\\"},{\\"element_id\\":\\"fjl9103\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"nwcm289\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida.<\\\\/p>\\"}}]},{\\"element_id\\":\\"ltaz264\\",\\"grid_class\\":\\"col4-1\\"}],\\"gutter\\":\\"gutter-none\\"},{\\"element_id\\":\\"1zt3716\\",\\"cols\\":[{\\"element_id\\":\\"w5xs716\\",\\"grid_class\\":\\"col3-1\\"},{\\"element_id\\":\\"4fei717\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"nz9a59\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon_type\\":\\"icon\\",\\"icon\\":\\"ti-control-play\\",\\"label\\":\\"Recommended Apps\\",\\"hide_label\\":false,\\"null\\":\\"hide\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_color_bg\\":\\"tb_default_color\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"large\\",\\"font_color_icon\\":\\"#198be3\\",\\"background_color_icon\\":\\"#ffffff_0.10\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"link_color\\":\\"#ffffff\\",\\"b_sh_i_inset\\":false,\\"b_sh_i_color\\":\\"#000000_0.25\\",\\"b_sh_i_spread_unit\\":\\"px\\",\\"b_sh_i_blur_unit\\":\\"px\\",\\"b_sh_i_blur\\":\\"10\\",\\"b_sh_i_vOffset_unit\\":\\"px\\",\\"b_sh_i_vOffset\\":\\"3\\",\\"b_sh_i_hOffset_unit\\":\\"px\\",\\"b_sh_i_hOffset\\":\\"0\\"}}]},{\\"element_id\\":\\"9h3q717\\",\\"grid_class\\":\\"col3-1\\"}],\\"gutter\\":\\"gutter-none\\"}]}],\\"styling\\":{\\"padding_top\\":\\"12\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"12\\",\\"padding_opp_bottom\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-gadgets\\\\/files\\\\/2021\\\\/03\\\\/banner-gadget-bottom.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"cover_color\\":\\"#000000_0.45\\",\\"cover_color-type\\":\\"color\\",\\"text_align\\":\\"center\\",\\"font_color\\":\\"#ffffff\\",\\"cover_color_hover\\":\\"#000000_0.30\\",\\"cover_color_hover-type\\":\\"hover_color\\"}},{\\"element_id\\":\\"jtmg704\\",\\"cols\\":[{\\"element_id\\":\\"d8p4717\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2wb7717\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>This week highlights<\\\\/h2>\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"50\\",\\"margin_opp_bottom\\":false}},{\\"mod_name\\":\\"products\\",\\"element_id\\":\\"uj4w303\\",\\"mod_settings\\":{\\"post_per_page_products\\":\\"6\\",\\"hide_page_nav_products\\":\\"yes\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"layout_products\\":\\"auto_tiles\\",\\"hide_sales_badge\\":\\"no\\",\\"show_empty_rating\\":false,\\"hide_rating_products\\":\\"no\\",\\"hide_add_to_cart_products\\":\\"no\\",\\"hide_price_products\\":\\"no\\",\\"unlink_post_title_products\\":\\"no\\",\\"show_product_tags\\":\\"no\\",\\"show_product_categories\\":\\"no\\",\\"hide_post_title_products\\":\\"no\\",\\"unlink_feat_img_products\\":\\"no\\",\\"hide_feat_img_products\\":\\"no\\",\\"description_products\\":\\"none\\",\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"0\\",\\"tab_visible_opt_slider\\":\\"0\\",\\"visible_opt_slider\\":\\"1\\",\\"effect_slider\\":\\"scroll\\",\\"layout_slider\\":\\"slider-default\\",\\"template_products\\":\\"list\\",\\"order_products\\":\\"desc\\",\\"orderby_products\\":\\"date\\",\\"hide_outofstock_products\\":\\"no\\",\\"hide_free_products\\":\\"no\\",\\"tag_products\\":\\"0|single\\",\\"hide_child_products\\":\\"no\\",\\"category_products\\":\\"0|single\\",\\"query_type\\":\\"category\\",\\"query_products\\":\\"all\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_bottom\\":\\"1\\",\\"padding_top\\":\\"6\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 77,
  'post_date' => '2021-03-15 08:22:45',
  'post_date_gmt' => '2021-03-15 08:22:45',
  'post_content' => '<!-- wp:themify-builder/canvas /-->',
  'post_title' => 'Wishlist',
  'post_excerpt' => '',
  'post_name' => 'wishlist',
  'post_modified' => '2021-03-15 08:22:47',
  'post_modified_gmt' => '2021-03-15 08:22:47',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?page_id=77',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"iujp352\\",\\"cols\\":[{\\"element_id\\":\\"78c6353\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 57,
  'post_date' => '2021-03-09 07:17:58',
  'post_date_gmt' => '2021-03-09 07:17:58',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'AirPods',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est qui dolorem ipsum.',
  'post_name' => 'airpods',
  'post_modified' => '2021-08-03 18:36:25',
  'post_modified_gmt' => '2021-08-03 18:36:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=57',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615274408:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"coji252\\",\\"cols\\":[{\\"element_id\\":\\"qhnu253\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '58',
    '_regular_price' => '120',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '120',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/airpods.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 54,
  'post_date' => '2021-03-09 07:17:14',
  'post_date_gmt' => '2021-03-09 07:17:14',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'iPhone 12 Pro Max',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'iphone-12-pro-max',
  'post_modified' => '2021-03-09 07:17:14',
  'post_modified_gmt' => '2021-03-09 07:17:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=54',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615274098:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"23k6109\\",\\"cols\\":[{\\"element_id\\":\\"rn7k110\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '55',
    '_regular_price' => '1100',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '1100',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'smartphone',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/iPhone-12-max-pro.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 52,
  'post_date' => '2021-03-09 07:15:39',
  'post_date_gmt' => '2021-03-09 07:15:39',
  'post_content' => 'Deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum. Excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum.',
  'post_title' => 'Google Nest Wifi Cam',
  'post_excerpt' => 'Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias.',
  'post_name' => 'google-nest-wifi-cam',
  'post_modified' => '2021-03-09 07:15:39',
  'post_modified_gmt' => '2021-03-09 07:15:39',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=52',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615274043:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"g8jy65\\",\\"cols\\":[{\\"element_id\\":\\"87dt65\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '53',
    '_regular_price' => '125',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '125',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hub',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/nest-cam.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 50,
  'post_date' => '2021-03-09 07:14:46',
  'post_date_gmt' => '2021-03-09 07:14:46',
  'post_content' => 'Molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Harman & Kardon Onix',
  'post_excerpt' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit.',
  'post_name' => 'harman-kardon-onix',
  'post_modified' => '2021-03-09 07:14:46',
  'post_modified_gmt' => '2021-03-09 07:14:46',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=50',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273947:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"7jkp784\\",\\"cols\\":[{\\"element_id\\":\\"6qbn785\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '51',
    '_regular_price' => '150',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '150',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/harman-kardon-onix.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 48,
  'post_date' => '2021-03-09 07:13:59',
  'post_date_gmt' => '2021-03-09 07:13:59',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Google Nest Thermostat',
  'post_excerpt' => 'Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.',
  'post_name' => 'google-nest-thermostat',
  'post_modified' => '2021-03-09 07:13:59',
  'post_modified_gmt' => '2021-03-09 07:13:59',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=48',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273903:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"4b4n118\\",\\"cols\\":[{\\"element_id\\":\\"yj6d120\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '49',
    '_regular_price' => '250',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '250',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hub',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-nest-thermostat.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 45,
  'post_date' => '2021-03-09 07:12:18',
  'post_date_gmt' => '2021-03-09 07:12:18',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid.',
  'post_title' => 'Samsung Galaxy Sport Gear',
  'post_excerpt' => 'Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
  'post_name' => 'samsung-galaxy-sport-gear',
  'post_modified' => '2021-11-27 03:18:55',
  'post_modified_gmt' => '2021-11-27 03:18:55',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=45',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273835:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"9vc1180\\",\\"cols\\":[{\\"element_id\\":\\"76fw181\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '46',
    '_regular_price' => '350',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '5.8.0',
    '_price' => '350',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'smartwatch',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/samsung-galaxy-gear-sport.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 43,
  'post_date' => '2021-03-09 07:11:03',
  'post_date_gmt' => '2021-03-09 07:11:03',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'JBL Wireless Headphone Audio',
  'post_excerpt' => 'Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_name' => 'jbl-wireless-headphone-audio',
  'post_modified' => '2021-03-09 07:11:03',
  'post_modified_gmt' => '2021-03-09 07:11:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=43',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273730:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"h8oa474\\",\\"cols\\":[{\\"element_id\\":\\"ckxs475\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '44',
    '_regular_price' => '300',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '300',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/jbl-audio-headphone.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 41,
  'post_date' => '2021-03-09 07:08:54',
  'post_date_gmt' => '2021-03-09 07:08:54',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Garmin Fenix 5',
  'post_excerpt' => 'Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_name' => 'garmin-fenix-5',
  'post_modified' => '2021-03-09 07:08:54',
  'post_modified_gmt' => '2021-03-09 07:08:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=41',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273601:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"5usm506\\",\\"cols\\":[{\\"element_id\\":\\"db5r509\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '42',
    '_regular_price' => '800',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '800',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'smartwatch',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/garmin-fenix-5.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 38,
  'post_date' => '2021-03-09 07:07:34',
  'post_date_gmt' => '2021-03-09 07:07:34',
  'post_content' => 'Molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.
',
  'post_title' => 'Amazon Echo Dot 3rd Gen',
  'post_excerpt' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo.',
  'post_name' => 'amazon-echo-dot-3rd-gen',
  'post_modified' => '2021-03-09 07:07:34',
  'post_modified_gmt' => '2021-03-09 07:07:34',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=38',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273529:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ew2n712\\",\\"cols\\":[{\\"element_id\\":\\"ru83713\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '40',
    '_regular_price' => '45',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '45',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'hub',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/amazon-nest.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 36,
  'post_date' => '2021-03-09 07:05:45',
  'post_date_gmt' => '2021-03-09 07:05:45',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_title' => 'Segway Ninebot S Pro',
  'post_excerpt' => 'Nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.',
  'post_name' => 'segway-ninebot-s-pro',
  'post_modified' => '2021-03-09 07:05:45',
  'post_modified_gmt' => '2021-03-09 07:05:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=36',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615273447:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"dkae17\\",\\"cols\\":[{\\"element_id\\":\\"hhig18\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '37',
    '_regular_price' => '800',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '800',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'segway',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/ninebot-spro.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 70,
  'post_date' => '2021-03-03 06:48:46',
  'post_date_gmt' => '2021-03-03 06:48:46',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid.',
  'post_title' => 'Google Nest Mini Speakers',
  'post_excerpt' => 'Totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
  'post_name' => 'google-nest-mini-speakers',
  'post_modified' => '2021-03-10 06:49:15',
  'post_modified_gmt' => '2021-03-10 06:49:15',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=70',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358955:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"yn73402\\",\\"cols\\":[{\\"element_id\\":\\"cfod403\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '71',
    '_regular_price' => '100',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '100',
    '_wp_old_date' => '2021-03-10',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-nest-mini.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 68,
  'post_date' => '2021-03-03 06:47:45',
  'post_date_gmt' => '2021-03-03 06:47:45',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Google Nest Speaker',
  'post_excerpt' => 'Magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_name' => 'google-nest-speaker',
  'post_modified' => '2021-03-10 06:49:10',
  'post_modified_gmt' => '2021-03-10 06:49:10',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=68',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358950:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ohzq688\\",\\"cols\\":[{\\"element_id\\":\\"uobt689\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '69',
    '_regular_price' => '234',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '234',
    '_wp_old_date' => '2021-03-10',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-nest.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 66,
  'post_date' => '2021-03-02 06:45:03',
  'post_date_gmt' => '2021-03-02 06:45:03',
  'post_content' => 'Molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Google Chrome Cast',
  'post_excerpt' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit.',
  'post_name' => 'google-chrome-cast',
  'post_modified' => '2021-11-30 07:01:07',
  'post_modified_gmt' => '2021-11-30 07:01:07',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=66',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358650:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ipbv578\\",\\"cols\\":[{\\"element_id\\":\\"1ggj581\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '67',
    '_wp_old_date' => '2021-03-10',
    '_regular_price' => '60',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '5.8.0',
    '_price' => '60',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio, hub',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/chromecast.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 64,
  'post_date' => '2021-03-02 06:43:52',
  'post_date_gmt' => '2021-03-02 06:43:52',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_title' => 'Google Nest Hub Max',
  'post_excerpt' => 'Nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.',
  'post_name' => 'google-nest-hub-max',
  'post_modified' => '2021-03-10 06:44:57',
  'post_modified_gmt' => '2021-03-10 06:44:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=64',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358559:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"hf7e894\\",\\"cols\\":[{\\"element_id\\":\\"m1ex895\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '65',
    '_wp_old_date' => '2021-03-10',
    '_regular_price' => '360',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '360',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'audio, hub',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/google-nest-hub.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 62,
  'post_date' => '2021-03-01 06:42:07',
  'post_date_gmt' => '2021-03-01 06:42:07',
  'post_content' => 'Deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum. Excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum.',
  'post_title' => 'Redmi Powerbank',
  'post_excerpt' => 'Vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias.',
  'post_name' => 'redmi-powerbank',
  'post_modified' => '2021-05-19 20:55:15',
  'post_modified_gmt' => '2021-05-19 20:55:15',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=62',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358488:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '63',
    '_wp_old_date' => '2021-03-10',
    '_regular_price' => '25',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.9.0',
    '_price' => '25',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"zroz134\\",\\"cols\\":[{\\"element_id\\":\\"3rrj134\\",\\"grid_class\\":\\"col-full\\"}]}]',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'smartphone',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/redmi-powerbank.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 60,
  'post_date' => '2021-03-01 06:40:32',
  'post_date_gmt' => '2021-03-01 06:40:32',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_title' => 'Xiaomi Poco M3',
  'post_excerpt' => 'Voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est qui dolorem ipsum.',
  'post_name' => 'xiaomi-poco-m3',
  'post_modified' => '2021-11-28 20:38:22',
  'post_modified_gmt' => '2021-11-28 20:38:22',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?post_type=product&#038;p=60',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1615358382:172',
    '_edit_last' => '172',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"z7rd383\\",\\"cols\\":[{\\"element_id\\":\\"rkun384\\",\\"grid_class\\":\\"col-full\\"}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_thumbnail_id' => '61',
    '_wp_old_date' => '2021-03-10',
    '_regular_price' => '250',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '5.8.0',
    '_price' => '250',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'smartphone',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-gadgets/files/2021/03/xiaomi-poco-m3.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 19,
  'post_date' => '2021-03-09 06:51:48',
  'post_date_gmt' => '2021-03-09 06:51:48',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '19',
  'post_modified' => '2021-04-27 19:30:48',
  'post_modified_gmt' => '2021-04-27 19:30:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadget/?p=19',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => 'shop',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 150,
  'post_date' => '2021-03-20 11:16:28',
  'post_date_gmt' => '2021-03-20 11:16:28',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '150',
  'post_modified' => '2021-04-27 19:30:48',
  'post_modified_gmt' => '2021-04-27 19:30:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?p=150',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'taxonomy',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '20',
    '_menu_item_object' => 'product_cat',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 151,
  'post_date' => '2021-03-20 11:16:28',
  'post_date_gmt' => '2021-03-20 11:16:28',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '151',
  'post_modified' => '2021-04-27 19:30:48',
  'post_modified_gmt' => '2021-04-27 19:30:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?p=151',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'taxonomy',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '18',
    '_menu_item_object' => 'product_cat',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 152,
  'post_date' => '2021-03-20 11:16:28',
  'post_date_gmt' => '2021-03-20 11:16:28',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '152',
  'post_modified' => '2021-04-27 19:30:48',
  'post_modified_gmt' => '2021-04-27 19:30:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?p=152',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'taxonomy',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '17',
    '_menu_item_object' => 'product_cat',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 153,
  'post_date' => '2021-03-20 11:16:28',
  'post_date_gmt' => '2021-03-20 11:16:28',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '153',
  'post_modified' => '2021-04-27 19:30:48',
  'post_modified_gmt' => '2021-04-27 19:30:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?p=153',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'taxonomy',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '21',
    '_menu_item_object' => 'product_cat',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 194,
  'post_date' => '2021-04-27 19:30:48',
  'post_date_gmt' => '2021-04-27 19:30:48',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '194',
  'post_modified' => '2021-04-27 19:30:48',
  'post_modified_gmt' => '2021-04-27 19:30:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?p=194',
  'menu_order' => 6,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '81',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 193,
  'post_date' => '2021-04-27 19:30:48',
  'post_date_gmt' => '2021-04-27 19:30:48',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '193',
  'post_modified' => '2021-04-27 19:30:48',
  'post_modified_gmt' => '2021-04-27 19:30:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-gadgets/?p=193',
  'menu_order' => 7,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '89',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_text" );
$widgets[1002] = array (
  'title' => '',
  'text' => '<h3><a href="https://themify.me/demo/themes/shoppe-gadgets">GADGET</a></h3>
2406 Brook St, Newcombville Nova Scotia, Canada

<a href="mailto:info@gedgets.com">info@gedgets.com</a>

<a href="tel:017-624-1234">017-624-1234</a>',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1003] = array (
  'title' => 'Shop',
  'text' => '<a href="#">Best Sellers</a>

<a href="#">Computers</a>

<a href="#">Audio TV</a>

<a href="#">Applicances</a>',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1004] = array (
  'title' => 'Information',
  'text' => '<a href="#">About Us</a>

<a href="#">Blogs</a>

<a href="#">Contact Us</a>

<a href="#">Orders &amp; Shipping</a>

<a href="#">Billing &amp; payments</a>',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1005] = array (
  'title' => 'Support',
  'text' => '<a href="#">Order Status</a>

<a href="#">Refund Policies</a>

<a href="#">Complaints</a>

<a href="#">Help</a>

<a href="#">Contact</a>',
  'filter' => true,
  'visual' => true,
  'tf_search_ajax' => '',
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_search" );
$widgets[1006] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1007] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1008] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1009] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1010] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1011] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );



$sidebars_widgets = array (
  'footer-widget-1' => 
  array (
    0 => 'text-1002',
  ),
  'footer-widget-2' => 
  array (
    0 => 'text-1003',
  ),
  'footer-widget-3' => 
  array (
    0 => 'text-1004',
  ),
  'footer-widget-4' => 
  array (
    0 => 'text-1005',
  ),
  'sidebar-main' => 
  array (
    0 => 'search-1006',
    1 => 'recent-posts-1007',
    2 => 'recent-comments-1008',
    3 => 'archives-1009',
    4 => 'categories-1010',
    5 => 'meta-1011',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-search_post_type' => 'all',
  'setting-webfonts_list' => 'recommended',
  'setting-customizer_responsive_design_tablet_landscape' => '1024',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '480',
  'setting-mobile_menu_trigger_point' => '900',
  'setting-header_design' => 'header-logo-left',
  'setting-footer_design' => 'footer-horizontal-left',
  'setting-exclude_footer_site_logo' => 'on',
  'setting-use_float_back' => 'on',
  'setting-footer_widgets' => 'footerwidget-4col',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-imagefilter_applyto' => 'featuredonly',
  'setting-more_posts' => 'infinite',
  'setting-entries_nav' => 'numbered',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-lazy-blur' => '25',
  'setting-cache-live' => '10080',
  'setting-webp-quality' => '5',
  'setting-default_layout' => 'sidebar1',
  'setting-default_post_layout' => 'list-post',
  'setting-post_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar1',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-search-result_layout' => 'sidebar1',
  'setting-search-result_post_layout' => 'list-post',
  'setting-search-result_layout_display' => 'excerpt',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar1',
  'setting-shop_layout' => 'sidebar-none',
  'setting-shop_content_width' => 'default_width',
  'setting-shop_archive_layout' => 'sidebar-none',
  'setting-custom_post_product_archive_content_width' => 'default_width',
  'setting-products_layout' => 'grid3',
  'setting-shop_masonry_disabled' => 'on',
  'setting-product_post_gutter' => 'gutter',
  'setting-products_slider' => 'enable',
  'setting-single_product_layout' => 'sidebar-none',
  'setting-custom_post_product_single_content_width' => 'default_width',
  'setting-related_products_limit' => '3',
  'setting-product_description_type' => 'long',
  'setting-wishlist_page' => '77',
  'setting-cart_style' => 'dropdown',
  'setting-cart_show_seconds' => 'off',
  'setting-spark_color' => '#198be3',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/shoppe-gadgets/wp-content/themes/themify-shoppe/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/shoppe-gadgets/wp-content/themes/themify-shoppe/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'YouTube',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/shoppe-gadgets/wp-content/themes/themify-shoppe/themify/img/social/youtube.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'Pinterest',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/shoppe-gadgets/wp-content/themes/themify-shoppe/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-4' => 'font-icon',
  'setting-link_title_themify-link-4' => 'Twitter',
  'setting-link_ficon_themify-link-4' => 'fa-twitter',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Facebook',
  'setting-link_ficon_themify-link-5' => 'fa-facebook',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'YouTube',
  'setting-link_ficon_themify-link-6' => 'fa-youtube',
  'setting-link_type_themify-link-7' => 'font-icon',
  'setting-link_title_themify-link-7' => 'Pinterest',
  'setting-link_ficon_themify-link-7' => 'fa-pinterest',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-5":"themify-link-5","themify-link-6":"themify-link-6","themify-link-7":"themify-link-7"}',
  'setting-link_field_hash' => '8',
  'setting-twitter_settings_cache' => '10',
  'setting-recaptcha_version' => 'v2',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_gallery_lightbox' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'skin' => 'gadgets',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'custom_css_post_id' => -1,
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
