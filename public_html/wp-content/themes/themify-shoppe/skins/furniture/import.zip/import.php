<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 16,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 2,
  'name' => 'simple',
  'slug' => 'simple',
  'term_group' => 0,
  'taxonomy' => 'product_type',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 17,
  'name' => 'Storage',
  'slug' => 'storage',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 18,
  'name' => 'Lamp',
  'slug' => 'lamp',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 19,
  'name' => 'Sofa',
  'slug' => 'sofa',
  'term_group' => 0,
  'taxonomy' => 'product_cat',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 19,
  'post_date' => '2020-11-27 06:54:50',
  'post_date_gmt' => '2020-11-27 06:54:50',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><img src="https://themify.me/demo/themes/ultra-furniture/files/2020/11/about-banner-top.jpg" width="1158" height="556">
<h3>As we evolve, our home should, too</h3>
<p>This year has definitely introduced us to a new definition of normal. In embracing this new normal, however, should also be incorporated in our homes as more individuals are now finding themselves working from home. As your situation changes, allow us to help you reinvent your house into your oasis.</p>
<img src="https://themify.me/demo/themes/ultra-furniture/files/2020/11/about-quote-image-480x510.jpg" width="480" height="510">
<h3>Simplicity</h3>
<h3>Functionality</h3>
<h3>Trendy</h3>
<p>Simplicity, functionality and modernity….the perfect ingredients to your ideal home. Creating a design-forward home means creating a refined home that keeps us grounded amidst our busy lives that tends to distract us from who we really are. Your home should be a statement of the lifestyle you would like to embrace.</p>
<h3>S</h3>
<h3>Simplicity</h3> <p>Less is more - make a statement by showcasing space with simple and minimalistic designs. A minimalist design doesn’t mean an empty space, but rather to show restraint and careful paring down to get a place of clarity.</p>
<h3>F</h3>
<h3>Functionality</h3> <p>Your home should not just be pleasing to the eye, but a cozy space you should enjoy spending time in. Therefore, functionality is a key ingredient in ensuring comfort in your space, because a comfortable interior equals healthy and happy individuals.</p>
<h3>T</h3>
<h3>Trendy</h3> <p>With everything from contemporary to vintage, a trendy home furnishings gives your home more character and personality that showcase who you are. Discover modern furnitures that’s sleek, chic and affordable that would definitely give life to your space.  </p>
<img src="https://themify.me/demo/themes/ultra-furniture/files/2020/11/carpenter.jpg" width="485" height="738">
<h3>From carpenter to furniture enterprise</h3>
<ul> <li id="timeline-0"> 1998 <h2> Carpenter </h2> <p>Customized furniture has been our pride from the beginning.  Delicately created by the hands of our skillful and professional carpenters</p> </li> <li id="timeline-1"> 2005 <h2> Our First Furniture Shop </h2> <p>We opened our first shop in 2005 to make our customized furniture available to the public, with curated collections to create a space you love to call home.</p> </li> <li id="timeline-2"> 2012 <h2> Time to go international </h2> <p>Bringing our collection from design to delivery anywhere in the world, in the most efficient way possible.  Our exclusive pieces have been made available online so we can offer our designs no matter where you are in the world.</p> </li> <li id="timeline-3"> Today <h2> We are top 5 furniture enterprise </h2> <p>Earning our spot at the Top 5 furniture enterprise, it is our intention to create collections that live well together and can translate into any space.</p> </li> </ul>
<h3>We are hiring</h3>
<p>We are continuously looking for talent! Look through our available positions.</p>
<a href="https://themify.me/" > View All Position </a>
<img src="https://themify.me/demo/themes/ultra-furniture/files/2020/11/career-bg.jpg" width="1079" height="612"><!--/themify_builder_static-->',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2022-01-11 07:12:34',
  'post_modified_gmt' => '2022-01-11 07:12:34',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?page_id=19',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"beqo892\\",\\"cols\\":[{\\"element_id\\":\\"cdx3895\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"oht5896\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"556\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"1158\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-furniture\\\\/files\\\\/2020\\\\/11\\\\/about-banner-top.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"100\\",\\"breakpoint_tablet_landscape\\":{\\"padding_top\\":\\"50\\",\\"padding_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}},{\\"element_id\\":\\"arbp893\\",\\"cols\\":[{\\"element_id\\":\\"q0ma898\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ifum899\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>As we evolve, our home should, too<\\\\/h3>\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"margin_top\\":\\"30\\",\\"font_color_type\\":\\"font_color_solid\\",\\"custom_parallax_scroll_zindex\\":\\"3\\",\\"font_size_h3\\":\\"40\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"margin_right\\":\\"-50\\",\\"text_align\\":\\"right\\",\\"breakpoint_tablet_landscape\\":{\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"30\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"breakpoint_mobile\\":{\\"text_align\\":\\"left\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"0\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"margin_top\\":\\"30\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"30\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"-50\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"margin_top\\":\\"30\\",\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"u9v2899\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><span style=\\\\\\"font-weight: 400;\\\\\\">This year has definitely introduced us to a new definition of normal. In embracing this new normal, however, should also be incorporated in our homes as more individuals are now finding themselves working from home. As your situation changes, allow us to help you reinvent your house into your oasis.<\\\\/span><\\\\/p>\\",\\"margin_right\\":\\"80\\",\\"p_margin_top\\":\\"30\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"0\\",\\"margin_opp_top\\":false,\\"p_margin_top_unit\\":\\"px\\",\\"p_margin_top\\":\\"10\\",\\"margin_opp_bottom\\":false,\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_opp_bottom\\":false},\\"breakpoint_tablet\\":{\\"margin_right\\":40,\\"margin_right_unit\\":\\"px\\"}}}]},{\\"element_id\\":\\"tc89900\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"gilc900\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"510\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"480\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-furniture\\\\/files\\\\/2020\\\\/11\\\\/about-quote-image-480x510.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"custom_parallax_scroll_zindex\\":\\"1\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"25\\",\\"margin_opp_top\\":false},\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_vp\\":\\"0,100\\",\\"v_speed\\":\\"1\\",\\"v_dir\\":\\"up\\"}}}}}]}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_top\\":\\"100\\",\\"padding_bottom\\":\\"100\\",\\"padding_opp_top\\":\\"1\\",\\"breakpoint_tablet_landscape\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"50\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"50\\"},\\"breakpoint_mobile\\":{\\"padding_bottom\\":0,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top\\":0,\\"padding_top_unit\\":\\"px\\"}}},{\\"element_id\\":\\"dsvw893\\",\\"cols\\":[{\\"element_id\\":\\"cnsy901\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"iss1902\\",\\"cols\\":[{\\"element_id\\":\\"5zti903\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"61v6903\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Simplicity<\\\\/h3>\\",\\"padding_bottom\\":\\"15\\",\\"padding_top\\":\\"20\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#ffffff_0.45\\",\\"background_image-type\\":\\"image\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"15\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-furniture\\\\/files\\\\/2020\\\\/11\\\\/simplicity.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-bottom\\":\\"25\\",\\"margin-top_opp_top\\":false,\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"%\\",\\"padding_top\\":\\"15\\"}}},{\\"element_id\\":\\"hd6b904\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"65h8904\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Functionality<\\\\/h3>\\",\\"padding_bottom\\":\\"15\\",\\"padding_top\\":\\"20\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#ffffff_0.45\\",\\"background_image-type\\":\\"image\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"15\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-furniture\\\\/files\\\\/2020\\\\/11\\\\/functionality.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"breakpoint_mobile\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-bottom\\":\\"25\\",\\"margin-top_opp_top\\":false}}},{\\"element_id\\":\\"s39m905\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"63ke905\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Trendy<\\\\/h3>\\",\\"padding_bottom\\":\\"15\\",\\"padding_top\\":\\"20\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_color\\":\\"#ffffff_0.45\\",\\"background_image-type\\":\\"image\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"20\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"15\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-furniture\\\\/files\\\\/2020\\\\/11\\\\/trendy.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"col_tablet_landscape\\":\\"column3-1\\",\\"col_tablet\\":\\"column3-1\\"},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"35zc905\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><span style=\\\\\\"font-weight: 400;\\\\\\">Simplicity, functionality and modernity….the perfect ingredients to your ideal home. Creating a design-forward home means creating a refined home that keeps us grounded amidst our busy lives that tends to distract us from who we really are. Your home should be a statement of the lifestyle you would like to embrace.<\\\\/span><\\\\/p>\\",\\"p_margin_bottom\\":\\"30\\",\\"p_margin_top\\":\\"30\\",\\"font_color_type\\":\\"font_color_solid\\"}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"column_alignment\\":\\"col_align_bottom\\",\\"styling\\":{\\"padding_top\\":0,\\"padding_bottom\\":0,\\"padding_opp_top\\":\\"1\\"}},{\\"element_id\\":\\"dxdy893\\",\\"cols\\":[{\\"element_id\\":\\"ujys906\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"zhv8906\\",\\"cols\\":[{\\"element_id\\":\\"cpfa907\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"9zah907\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>S<\\\\/h3>\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-type\\":\\"image\\",\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"7\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"5\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"breakpoint_tablet\\":{\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"5.5\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"breakpoint_tablet_landscape\\":{\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"6\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}}],\\"grid_width\\":10,\\"styling\\":{\\"background_color\\":\\"#f0f0f0\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"3403907\\",\\"grid_class\\":\\"col4-3\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"9mff907\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Simplicity<\\\\/h3>\\\\n<p><span style=\\\\\\"font-weight: 400;\\\\\\">Less is more - make a statement by showcasing space with simple and minimalistic designs. A minimalist design doesn’t mean an empty space, but rather to show restraint and careful paring down to get a place of clarity.<\\\\/span><\\\\/p>\\"}}],\\"grid_width\\":86.7999999999999971578290569595992565155029296875}],\\"column_alignment\\":\\"col_align_middle\\",\\"column_h\\":1,\\"col_tablet\\":\\"column4-1-4-3\\",\\"col_mobile\\":\\"column4-1-4-3\\",\\"styling\\":{\\"margin_bottom\\":55}},{\\"element_id\\":\\"q09p908\\",\\"cols\\":[{\\"element_id\\":\\"80w7908\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"g3o1908\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>F<\\\\/h3>\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-type\\":\\"image\\",\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"7\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"5\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"},\\"breakpoint_tablet\\":{\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"5.5\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"breakpoint_tablet_landscape\\":{\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"6\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"center\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}}],\\"grid_width\\":10,\\"styling\\":{\\"background_color\\":\\"#f0f0f0\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"eth4909\\",\\"grid_class\\":\\"col4-3\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"arx3909\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Functionality<\\\\/h3>\\\\n<p><span style=\\\\\\"font-weight: 400;\\\\\\">Your home should not just be pleasing to the eye, but a cozy space you should enjoy spending time in. Therefore, functionality is a key ingredient in ensuring comfort in your space, because a comfortable interior equals healthy and happy individuals.<\\\\/span><\\\\/p>\\"}}],\\"grid_width\\":86.7999999999999971578290569595992565155029296875}],\\"column_alignment\\":\\"col_align_middle\\",\\"column_h\\":1,\\"col_tablet\\":\\"column4-1-4-3\\",\\"col_mobile\\":\\"column4-1-4-3\\",\\"styling\\":{\\"margin_bottom\\":55}},{\\"element_id\\":\\"xl5s909\\",\\"cols\\":[{\\"element_id\\":\\"h74f909\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"uzc0910\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>T<\\\\/h3>\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-type\\":\\"image\\",\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"7\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\",\\"text_align\\":\\"center\\",\\"font_color_type\\":\\"font_color_solid\\",\\"breakpoint_mobile\\":{\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"5\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"breakpoint_tablet\\":{\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"5.5\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"breakpoint_tablet_landscape\\":{\\"font_style_h3_regular\\":\\"italic\\",\\"line_height_h3_unit\\":\\"em\\",\\"line_height_h3\\":\\"0.4\\",\\"font_size_h3_unit\\":\\"em\\",\\"font_size_h3\\":\\"6\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}}],\\"grid_width\\":10,\\"styling\\":{\\"background_color\\":\\"#f0f0f0\\",\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"7ak4910\\",\\"grid_class\\":\\"col4-3\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"w3m4910\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Trendy<\\\\/h3>\\\\n<p><span style=\\\\\\"font-weight: 400;\\\\\\">With everything from contemporary to vintage, a trendy home furnishings gives your home more character and personality that showcase who you are. Discover modern furnitures that’s sleek, chic and affordable that would definitely give life to your space.  <\\\\/span><\\\\/p>\\"}}],\\"grid_width\\":86.7999999999999971578290569595992565155029296875}],\\"column_alignment\\":\\"col_align_middle\\",\\"column_h\\":1,\\"col_tablet\\":\\"column4-1-4-3\\",\\"col_mobile\\":\\"column4-1-4-3\\",\\"styling\\":{\\"margin_bottom\\":2}}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}}],\\"column_h\\":1,\\"styling\\":{\\"padding_top\\":59,\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"25\\"}}},{\\"element_id\\":\\"tati893\\",\\"cols\\":[{\\"element_id\\":\\"r9g8911\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"cdwc911\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"738\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"485\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-furniture\\\\/files\\\\/2020\\\\/11\\\\/carpenter.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_vp\\":\\"0,100\\",\\"v_speed\\":\\"1\\",\\"v_dir\\":\\"up\\"}}}}}],\\"grid_width\\":39.60000000000000142108547152020037174224853515625},{\\"element_id\\":\\"ranz911\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"xmzz911\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>From carpenter to furniture enterprise<\\\\/h3>\\",\\"font_size_h3\\":\\"40\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"-20\\",\\"margin_top\\":\\"40\\",\\"margin_bottom\\":\\"30\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"margin_top\\":\\"40\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"30\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"margin_top\\":\\"40\\"}}},{\\"mod_name\\":\\"timeline\\",\\"element_id\\":\\"yoiz911\\",\\"mod_settings\\":{\\"template_timeline\\":\\"list\\",\\"source_timeline\\":\\"text\\",\\"post_per_page_post_timeline\\":\\"4\\",\\"text_source_timeline\\":[{\\"title_timeline\\":\\"Carpenter\\",\\"date_timeline\\":\\"1998\\",\\"content_timeline\\":\\"<p><span style=\\\\\\"font-weight: 400;\\\\\\">Customized furniture has been our pride from the beginning.  Delicately created by the hands of our skillful and professional carpenters<\\\\/span><\\\\/p>\\"},{\\"title_timeline\\":\\"Our First Furniture Shop\\",\\"date_timeline\\":\\"2005\\",\\"content_timeline\\":\\"<p><span style=\\\\\\"font-weight: 400;\\\\\\">We opened our first shop in 2005 to make our customized furniture available to the public, with curated collections to create a space you love to call home.<\\\\/span><\\\\/p>\\"},{\\"title_timeline\\":\\"Time to go international\\",\\"date_timeline\\":\\"2012\\",\\"content_timeline\\":\\"<p><span style=\\\\\\"font-weight: 400;\\\\\\">Bringing our collection from design to delivery anywhere in the world, in the most efficient way possible.  Our exclusive pieces have been made available online so we can offer our designs no matter where you are in the world.<\\\\/span><\\\\/p>\\"},{\\"title_timeline\\":\\"We are top 5 furniture enterprise\\",\\"date_timeline\\":\\"Today\\",\\"content_timeline\\":\\"<p><span style=\\\\\\"font-weight: 400;\\\\\\">Earning our spot at the Top 5 furniture enterprise, it is our intention to create collections that live well together and can translate into any space.<\\\\/span><\\\\/p>\\"}],\\"hide_feat_img_post_timeline\\":\\"no\\",\\"display_post_timeline\\":\\"excerpt\\",\\"orderby_post_timeline\\":\\"date\\",\\"order_post_timeline\\":\\"desc\\",\\"category_post_timeline\\":\\"0|single\\",\\"tax_timeline\\":\\"category\\",\\"post_type_timeline\\":\\"post\\",\\"start_at_end\\":\\"no\\"}}],\\"grid_width\\":60.39999999999999857891452847979962825775146484375}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column-full\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_top\\":\\"100\\",\\"padding_opp_top\\":\\"1\\",\\"padding_bottom\\":\\"100\\",\\"breakpoint_tablet\\":{\\"padding_bottom\\":0,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top\\":0,\\"padding_top_unit\\":\\"px\\"}}},{\\"element_id\\":\\"s3qx893\\",\\"cols\\":[{\\"element_id\\":\\"j89h912\\",\\"grid_class\\":\\"col4-1\\",\\"grid_width\\":14,\\"styling\\":{\\"padding_left\\":\\"0\\"}},{\\"element_id\\":\\"afdc912\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"xi5u912\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>We are hiring<\\\\/h3>\\",\\"font_size_h3\\":\\"70\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"margin_right\\":\\"-35\\",\\"text_align\\":\\"right\\",\\"font_color_type\\":\\"font_color_solid\\",\\"padding_left\\":0,\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"0\\",\\"margin_opp_top\\":false,\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"55\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_gradient_color_h1-circle-radial\\":false,\\"font_gradient_color_h1-gradient-angle\\":\\"180\\",\\"font_gradient_color_h1-gradient-type\\":\\"linear\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\"},\\"breakpoint_tablet\\":{\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"55\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"0\\",\\"margin_opp_top\\":false,\\"text_align\\":\\"center\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"},\\"custom_parallax_scroll_zindex\\":\\"3\\",\\"breakpoint_tablet_landscape\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"0\\",\\"margin_opp_top\\":false,\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_left\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"text_align\\":\\"center\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"l4ae913\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><span style=\\\\\\"font-weight: 400;\\\\\\">We are continuously looking for talent! Look through our available positions.<\\\\/span><\\\\/p>\\",\\"p_margin_bottom\\":\\"30\\",\\"margin_left\\":35,\\"margin_left_unit\\":\\"%\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_right\\":\\"0\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":\\"1\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_opp_top\\":false},\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_right\\":\\"0\\",\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"text_align\\":\\"center\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"},\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"10\\",\\"breakpoint_tablet_landscape\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"5\\",\\"margin_opp_left\\":\\"1\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"5\\",\\"margin_opp_top\\":false,\\"text_align\\":\\"center\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"595i913\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View All Position\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"black\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"outline\\",\\"buttons_shape\\":\\"normal\\",\\"buttons_size\\":\\"normal\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":35,\\"padding_bottom\\":14,\\"breakpoint_mobile\\":{\\"margin_left_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_left\\":\\"0\\",\\"margin_bottom\\":\\"40\\"},\\"alignment\\":\\"center\\",\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"40\\",\\"margin_opp_top\\":false,\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"0\\",\\"padding_opp_top\\":false},\\"breakpoint_tablet_landscape\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_bottom\\":\\"30\\"}}}],\\"grid_width\\":29,\\"styling\\":{\\"breakpoint_mobile\\":{\\"font_style_regular\\":\\"normal\\",\\"padding_top\\":\\"0\\",\\"padding_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}},{\\"element_id\\":\\"j8pn913\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"nt80913\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-furniture\\\\/files\\\\/2020\\\\/11\\\\/career-bg.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"custom_parallax_scroll_zindex\\":\\"1\\"}}],\\"grid_width\\":57}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column-full\\",\\"col_tablet\\":\\"column-full\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"breakpoint_mobile\\":{\\"padding_top\\":\\"50\\",\\"padding_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 21,
  'post_date' => '2020-11-27 06:55:21',
  'post_date_gmt' => '2020-11-27 06:55:21',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h1>Contact Us</h1>
<h3>Do you have a question for us? We\'re here to help!</h3> <p>Our corporate office is open Monday to Friday, 8am to 5pm central time. <br />You can send us an email at <a href="mailto:customercare@website.com">customercare@website.com</a> or call our toll-free number at 0182-182-008-017.</p>
<h3>Information</h3>
<img src="https://themify.me/demo/themes/ultra-furniture/files/2020/11/information-image.jpg" width="570" height="546" title="" alt="">
<h4>Toronto</h4> <p>70-76 Sheppard Ave W <br />North York,<br />ON M2N 1M2 Canada</p>
<h4>Phone</h4> <p>416-509-6995 <br />416-555-0161</p>
<h4>Email</h4> <p><a href="https://themify.me/">customercare@website.com</a></p>
<a href="https://www.facebook.com/themify">
 <i><svg><use href="#tf-ti-facebook"></use></svg></i>
 </a>
 
 
 <a href="https://www.twitter.com/themify">
 <i><svg><use href="#tf-ti-twitter-alt"></use></svg></i>
 </a>
 
 
 <a href="https://www.youtube.com/user/themifyme">
 <i><svg><use href="#tf-ti-youtube"></use></svg></i>
 </a>
 
 
 <a href="https://www.linkedin.com/company/themify/">
 <i><svg><use href="#tf-ti-linkedin"></use></svg></i>
 </a>
<h3>Stay in touch</h3>
<form action="https://themify.me/demo/themes/shoppe-furniture/wp-admin/admin-ajax.php" class="builder-contact" id="tb_74hp256-form" method="post" data-post-id="0" data-element-id="74hp256" data-orig-id="" > <label for="tb_74hp256-contact-name">Name *</label> <input type="text" name="contact-name" placeholder="" id="tb_74hp256-contact-name" value="" required/> <label for="tb_74hp256-contact-email">Email *</label> <input type="text" name="contact-email" placeholder="" id="tb_74hp256-contact-email" value="" required/> <label for="tb_74hp256-contact-subject">Subject *</label> <input type="text" name="contact-subject" placeholder="" id="tb_74hp256-contact-subject" value="" required/> <label for="tb_74hp256-contact-message">Message *</label> <textarea name="contact-message" placeholder="" id="tb_74hp256-contact-message" rows="8" cols="45" required></textarea> <button type="submit"> Send</button> </form>
<img src="https://themify.me/demo/themes/ultra-furniture/files/2020/11/contact-info-image.jpg" width="570" height="676" title="" alt=""><!--/themify_builder_static-->',
  'post_title' => 'Contact Us',
  'post_excerpt' => '',
  'post_name' => 'contact-us',
  'post_modified' => '2020-12-29 05:06:28',
  'post_modified_gmt' => '2020-12-29 05:06:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?page_id=21',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"xvd0246\\",\\"cols\\":[{\\"element_id\\":\\"obqe248\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2mew249\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Contact Us<\\\\/h1>\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_size_h1_unit\\":\\"px\\",\\"font_size_h1\\":\\"80\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\",\\"breakpoint_mobile\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"h1_margin_bottom_unit\\":\\"px\\",\\"h1_margin_top_unit\\":\\"px\\",\\"t_shh1_blur_unit\\":\\"px\\",\\"t_shh1_vShadow_unit\\":\\"px\\",\\"t_shh1_hShadow_unit\\":\\"px\\",\\"letter_spacing_h1_unit\\":\\"px\\",\\"line_height_h1_unit\\":\\"px\\",\\"font_size_h1_unit\\":\\"px\\",\\"font_size_h1\\":\\"35\\",\\"font_gradient_color_h1-circle-radial\\":false,\\"font_gradient_color_h1-gradient-angle\\":\\"180\\",\\"font_gradient_color_h1-gradient-type\\":\\"linear\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\"},\\"breakpoint_tablet\\":{\\"h1_margin_bottom_unit\\":\\"px\\",\\"h1_margin_top_unit\\":\\"px\\",\\"t_shh1_blur_unit\\":\\"px\\",\\"t_shh1_vShadow_unit\\":\\"px\\",\\"t_shh1_hShadow_unit\\":\\"px\\",\\"letter_spacing_h1_unit\\":\\"px\\",\\"line_height_h1_unit\\":\\"px\\",\\"font_size_h1_unit\\":\\"px\\",\\"font_size_h1\\":\\"60\\",\\"font_gradient_color_h1-circle-radial\\":false,\\"font_gradient_color_h1-gradient-angle\\":\\"180\\",\\"font_gradient_color_h1-gradient-type\\":\\"linear\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\"}}}]}],\\"styling\\":{\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-furniture\\\\/files\\\\/2020\\\\/11\\\\/contact-us-banner.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_top\\":12,\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":12,\\"padding_opp_top\\":\\"1\\",\\"font_color\\":\\"#ffffff\\"}},{\\"element_id\\":\\"ja3t246\\",\\"cols\\":[{\\"element_id\\":\\"l87w250\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"l04f250\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Do you have a question for us? We\\\'re here to help!<\\\\/h3>\\\\n<p><span style=\\\\\\"font-weight: 400;\\\\\\">Our corporate office is open Monday to Friday, 8am to 5pm central time. <br \\\\/>You can send us an email at <\\\\/span><a href=\\\\\\"mailto:customercare@website.com\\\\\\"><span style=\\\\\\"font-weight: 400;\\\\\\">customercare@website.com<\\\\/span><\\\\/a><span style=\\\\\\"font-weight: 400;\\\\\\"> or call our toll-free number at 0182-182-008-017.<\\\\/span><\\\\/p>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"30\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}]}],\\"styling\\":{\\"padding_top\\":107,\\"padding_opp_left\\":false,\\"padding_bottom\\":107,\\"padding_opp_top\\":\\"1\\",\\"hide_anchor\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top_unit\\":\\"px\\",\\"breakpoint_mobile\\":{\\"padding_bottom\\":30,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top\\":\\"60\\",\\"padding_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false},\\"breakpoint_tablet\\":{\\"padding_bottom\\":74,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top\\":74,\\"padding_top_unit\\":\\"px\\"},\\"breakpoint_tablet_landscape\\":{\\"padding_bottom\\":65,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top\\":65,\\"padding_top_unit\\":\\"px\\"}}},{\\"element_id\\":\\"qwbk246\\",\\"cols\\":[{\\"element_id\\":\\"yfyr251\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"tmwr251\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Information<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"50\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text_align\\":\\"right\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_opp_left\\":false,\\"margin_right\\":\\"-60\\",\\"margin_opp_top\\":false,\\"margin_top\\":\\"30\\",\\"custom_parallax_scroll_zindex\\":\\"3\\",\\"breakpoint_mobile\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"35\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_align\\":\\"left\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_top\\":0,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"40\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"}}}],\\"grid_width\\":25.667000000000001591615728102624416351318359375,\\"styling\\":{\\"breakpoint_tablet\\":{\\"padding_bottom\\":0,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right\\":0,\\"padding_right_unit\\":\\"px\\",\\"padding_left\\":55,\\"padding_left_unit\\":\\"px\\"},\\"breakpoint_mobile\\":{\\"padding_left\\":25,\\"padding_left_unit\\":\\"px\\"}}},{\\"element_id\\":\\"v1e3252\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"441i252\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":false,\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-furniture\\\\/files\\\\/2020\\\\/11\\\\/information-image.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\",\\"custom_parallax_scroll_zindex\\":\\"1\\",\\"height_image\\":\\"546\\",\\"width_image\\":\\"570\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_vp\\":\\"0,100\\",\\"v_speed\\":\\"1\\",\\"v_dir\\":\\"up\\"}}}}}],\\"grid_width\\":43,\\"styling\\":{\\"margin-top_opp_top\\":false,\\"breakpoint_tablet\\":{\\"padding_left\\":0,\\"padding_left_unit\\":\\"px\\",\\"padding_right\\":0,\\"padding_right_unit\\":\\"px\\"}}},{\\"element_id\\":\\"mxmo252\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"j2nm253\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Toronto<\\\\/h4>\\\\n<p>70-76 Sheppard Ave W <br \\\\/>North York,<br \\\\/>ON M2N 1M2 Canada<\\\\/p>\\",\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#dddddd\\",\\"border-type\\":\\"bottom\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":0,\\"padding_opp_top\\":false,\\"breakpoint_tablet\\":{\\"h4_margin_bottom_unit\\":\\"px\\",\\"h4_margin_top_unit\\":\\"px\\",\\"t_shh4_blur_unit\\":\\"px\\",\\"t_shh4_vShadow_unit\\":\\"px\\",\\"t_shh4_hShadow_unit\\":\\"px\\",\\"letter_spacing_h4_unit\\":\\"px\\",\\"line_height_h4_unit\\":\\"px\\",\\"font_size_h4_unit\\":\\"px\\",\\"font_gradient_color_h4-circle-radial\\":false,\\"font_gradient_color_h4-gradient-angle\\":\\"180\\",\\"font_gradient_color_h4-gradient-type\\":\\"linear\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\"}}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"nzjp253\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Phone<\\\\/h4>\\\\n<p>416-509-6995 <br \\\\/>416-555-0161<\\\\/p>\\",\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#dddddd\\",\\"border-type\\":\\"bottom\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":0,\\"padding_opp_top\\":false,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_top\\":\\"20\\",\\"padding_bottom_unit\\":\\"px\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0bhm253\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>Email<\\\\/h4>\\\\n<p><a href=\\\\\\"https:\\\\/\\\\/themify.me\\\\/\\\\\\">customercare@website.com<\\\\/a><\\\\/p>\\",\\"border_bottom_width\\":\\"1\\",\\"border_bottom_color\\":\\"#dddddd\\",\\"border-type\\":\\"bottom\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":0,\\"padding_opp_top\\":false,\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_top\\":\\"20\\",\\"padding_bottom_unit\\":\\"px\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"vkje253\\",\\"mod_settings\\":{\\"content_icon\\":[{\\"icon\\":\\"ti-facebook\\",\\"icon_color_bg\\":\\"transparent\\",\\"link\\":\\"https:\\\\/\\\\/www.facebook.com\\\\/themify\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"},{\\"icon\\":\\"ti-twitter-alt\\",\\"icon_color_bg\\":\\"transparent\\",\\"link\\":\\"https:\\\\/\\\\/www.twitter.com\\\\/themify\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"},{\\"icon\\":\\"ti-youtube\\",\\"icon_color_bg\\":\\"transparent\\",\\"link\\":\\"https:\\\\/\\\\/www.youtube.com\\\\/user\\\\/themifyme\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"},{\\"icon\\":\\"ti-linkedin\\",\\"icon_color_bg\\":\\"transparent\\",\\"link\\":\\"https:\\\\/\\\\/www.linkedin.com\\\\/company\\\\/themify\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\"}],\\"icon_arrangement\\":\\"icon_horizontal\\",\\"icon_style\\":\\"circle\\",\\"icon_size\\":\\"normal\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"15\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":\\"1\\",\\"margin_top_unit\\":\\"px\\",\\"margin_top\\":\\"15\\"}}],\\"grid_width\\":31.332999999999998408384271897375583648681640625,\\"styling\\":{\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"3\\",\\"padding_opp_left\\":\\"1\\",\\"padding_right\\":\\"3\\",\\"padding_opp_top\\":false,\\"breakpoint_mobile\\":{\\"padding_top\\":\\"40\\",\\"padding_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"3\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"3\\",\\"padding_opp_top\\":false},\\"breakpoint_tablet\\":{\\"padding_top\\":18,\\"padding_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"3\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"3\\",\\"padding_opp_top\\":false}}}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column4-1-4-2-4-1\\",\\"col_tablet\\":\\"column3-1\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"130\\",\\"padding_opp_top\\":false,\\"hide_anchor\\":false,\\"margin-top_opp_top\\":false,\\"breakpoint_mobile\\":{\\"padding_bottom\\":\\"50\\",\\"padding_bottom_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"},\\"breakpoint_tablet_landscape\\":{\\"padding_bottom\\":65,\\"padding_bottom_unit\\":\\"px\\"}}},{\\"element_id\\":\\"etiw246\\",\\"cols\\":[{\\"element_id\\":\\"quw8254\\",\\"grid_class\\":\\"col-full\\"}],\\"styling\\":{\\"padding_top\\":244,\\"padding_opp_left\\":false,\\"padding_bottom\\":244,\\"padding_opp_top\\":\\"1\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_top_unit\\":\\"px\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-furniture\\\\/files\\\\/2020\\\\/11\\\\/map.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"j2dg247\\",\\"cols\\":[{\\"element_id\\":\\"pgu7255\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"emab256\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Stay in touch<\\\\/h3>\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"50\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_top\\":\\"30\\",\\"text_align\\":\\"right\\",\\"font_color_type\\":\\"font_color_solid\\",\\"custom_parallax_scroll_zindex\\":\\"3\\",\\"margin_right\\":\\"-80\\",\\"border-type\\":\\"top\\",\\"breakpoint_mobile\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"35\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_align\\":\\"left\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"},\\"breakpoint_tablet\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"40\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\"},\\"breakpoint_tablet_landscape\\":{\\"margin_top\\":\\"0\\",\\"margin_top_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_right\\":\\"-80\\",\\"margin_opp_top\\":false,\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"50\\"}}},{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"74hp256\\",\\"mod_settings\\":{\\"field_name_label\\":\\"Name\\",\\"field_email_label\\":\\"Email\\",\\"field_subject_label\\":\\"Subject\\",\\"field_message_label\\":\\"Message\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_sendcopy_subject\\":\\"COPY:\\",\\"field_send_label\\":\\"Send\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"field_name_require\\":\\"yes\\",\\"field_email_require\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_email_active\\":\\"yes\\",\\"field_subject_active\\":\\"yes\\",\\"field_subject_require\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_extra\\":\\"{ \\\\\\"fields\\\\\\": [] }\\",\\"field_order\\":\\"{}\\",\\"field_optin_label\\":\\"Subscribe to my newsletter.\\",\\"field_optin_active\\":false,\\"mailchimp_list\\":\\"0f2a95e5de\\",\\"provider\\":\\"mailchimp\\",\\"field_sendcopy_active\\":false,\\"field_captcha_active\\":false,\\"include_name_mail\\":false,\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":false,\\"user_role\\":\\"admin\\",\\"send_to_admins\\":false,\\"layout_contact\\":\\"style1\\",\\"border_send_top_style\\":\\"none\\",\\"border_send-type\\":\\"all\\",\\"in_m_opp_left\\":false,\\"in_m_opp_top\\":false,\\"breakpoint_mobile\\":{\\"padding_top\\":30,\\"padding_top_unit\\":\\"px\\"},\\"checkbox_r_c_sd_apply_all\\":false,\\"r_c_sd_left_unit\\":\\"px\\",\\"r_c_sd_opp_left\\":false,\\"r_c_sd_right_unit\\":\\"px\\",\\"r_c_sd_bottom_unit\\":\\"px\\",\\"r_c_sd_opp_bottom\\":false,\\"r_c_sd_top_unit\\":\\"px\\",\\"checkbox_p_sd_apply_all\\":false,\\"p_sd_left_unit\\":\\"px\\",\\"p_sd_opp_left\\":false,\\"p_sd_bottom_unit\\":\\"px\\",\\"p_sd_right_unit\\":\\"px\\",\\"p_sd_opp_top\\":false,\\"p_sd_top_unit\\":\\"px\\",\\"border_send_left_style\\":\\"solid\\",\\"border_send_bottom_style\\":\\"solid\\",\\"border_send_right_style\\":\\"solid\\",\\"t_sh_b_blur_unit\\":\\"px\\",\\"t_sh_b_vShadow_unit\\":\\"px\\",\\"t_sh_b_hShadow_unit\\":\\"px\\",\\"font_size_send_unit\\":\\"px\\"}}],\\"styling\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}},{\\"element_id\\":\\"0prs257\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"9acd257\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"676\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"570\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-furniture\\\\/files\\\\/2020\\\\/11\\\\/contact-info-image.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"custom_parallax_scroll_zindex\\":\\"1\\"}}]}],\\"mobile_dir\\":\\"rtl\\",\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_top\\":\\"100\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"100\\",\\"padding_opp_top\\":\\"1\\",\\"breakpoint_mobile\\":{\\"padding_bottom\\":\\"50\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_top\\":\\"50\\",\\"padding_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":\\"1\\"},\\"breakpoint_tablet\\":{\\"padding_bottom\\":52,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top\\":52,\\"padding_top_unit\\":\\"px\\"},\\"breakpoint_tablet_landscape\\":{\\"padding_bottom\\":65,\\"padding_bottom_unit\\":\\"px\\",\\"padding_top\\":65,\\"padding_top_unit\\":\\"px\\"},\\"hide_anchor\\":false}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 11,
  'post_date' => '2020-11-27 04:51:35',
  'post_date_gmt' => '2020-11-27 04:51:35',
  'post_content' => '<!-- wp:themify-builder/canvas /--><!--themify_builder_static--><h4>New Collection</h4> <h2>15% Off Custom</h2> <p>Save big on custom design furnitures. For a limited time only, shop our custom collection and save an extra 15% off!</p>
<a href="https://themify.me/" >
 View Collection
 </a>
<img src="https://themify.me/demo/themes/pro-furniture/files/2020/07/sofa-section-image.jpg" width="520" height="612" title="" alt="">
<h2>Sofa Collection</h2> <p>Need to bring life to your living room or simply need a bit more space to lounge? Every piece is customized to fit your home. </p>
<a href="https://themify.me/" >
 View Collection
 </a>
<ul data-lazy="1">
 <li>
 
 <figure>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/capella-mid-century/" title="Capella Mid Century"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/capella-mid-century-350x200.jpg" width="350" height="200" title="capella-mid-century" alt="capella-mid-century"></a>
 </figure> 
 
 
 <h3>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/capella-mid-century/" title="Capella Mid Century">
 
 Capella Mid Century
 </a>
 </h3>
 
 <bdi>&#36;700.00</bdi> <p><a href="?add-to-cart=52" data-quantity="1" data-product_id="52" data-product_sku="" aria-label="Add &ldquo;Capella Mid Century&rdquo; to your cart" rel="nofollow">Add to cart</a></p> 
 </li>
 <li>
 
 <figure>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/karlstad-leather-sofa/" title="Karlstad Leather Sofa"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/karlstaad-sofa-leather-350x200.jpg" width="350" height="200" title="karlstaad-sofa-leather" alt="karlstaad-sofa-leather"></a>
 </figure> 
 
 
 <h3>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/karlstad-leather-sofa/" title="Karlstad Leather Sofa">
 
 Karlstad Leather Sofa
 </a>
 </h3>
 
 <bdi>&#36;1,000.00</bdi> <p><a href="?add-to-cart=50" data-quantity="1" data-product_id="50" data-product_sku="" aria-label="Add &ldquo;Karlstad Leather Sofa&rdquo; to your cart" rel="nofollow">Add to cart</a></p> 
 </li>
 <li>
 
 <figure>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/capella-leather-gala/" title="Capella Leather Gala"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/capella-leather-gala-350x200.jpg" width="350" height="200" title="capella-leather-gala" alt="capella-leather-gala"></a>
 </figure> 
 
 
 <h3>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/capella-leather-gala/" title="Capella Leather Gala">
 
 Capella Leather Gala
 </a>
 </h3>
 
 <bdi>&#36;1,100.00</bdi> <p><a href="?add-to-cart=48" data-quantity="1" data-product_id="48" data-product_sku="" aria-label="Add &ldquo;Capella Leather Gala&rdquo; to your cart" rel="nofollow">Add to cart</a></p> 
 </li>
 <li>
 
 <figure>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/giorgetti-leather-sofa/" title="Giorgetti Leather Sofa"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/giorgetti-leather-sofa-350x200.jpg" width="350" height="200" title="giorgetti-leather-sofa" alt="giorgetti-leather-sofa"></a>
 </figure> 
 
 
 <h3>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/giorgetti-leather-sofa/" title="Giorgetti Leather Sofa">
 
 Giorgetti Leather Sofa
 </a>
 </h3>
 
 <bdi>&#36;700.00</bdi> <p><a href="?add-to-cart=46" data-quantity="1" data-product_id="46" data-product_sku="" aria-label="Add &ldquo;Giorgetti Leather Sofa&rdquo; to your cart" rel="nofollow">Add to cart</a></p> 
 </li>
 </ul>
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/12/black-marble-motive-800x512.jpg" width="800" height="512" title="black-marble-motive" alt="black-marble-motive" srcset="https://themify.me/demo/themes/shoppe-furniture/files/2020/12/black-marble-motive.jpg 800w, https://themify.me/demo/themes/shoppe-furniture/files/2020/12/black-marble-motive-600x384.jpg 600w, https://themify.me/demo/themes/shoppe-furniture/files/2020/12/black-marble-motive-768x492.jpg 768w" sizes="(max-width: 800px) 100vw, 800px" />
<h2>Retro Black Marble</h2>
<p>From living room goals to kitchen and bedroom perfection, view a vast array of our retro black marble collection for that perfect accent that is sure to bring more character to your home.</p>
<a href="https://themify.me/" >
 View Collection
 </a>
<h2>New Arrivals</h2>
<ul data-lazy="1">
 <li>
 
 <figure>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/natural-retro-cabinet/" title="Natural Retro Cabinet"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/natural-retro-cabinet-363x337.jpg" width="363" height="337" title="natural-retro-cabinet" alt="natural-retro-cabinet"></a>
 </figure> 
 
 
 <h3>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/natural-retro-cabinet/" title="Natural Retro Cabinet">
 
 Natural Retro Cabinet
 </a>
 </h3>
 
 <bdi>&#36;1,000.00</bdi> <p><a href="?add-to-cart=36" data-quantity="1" data-product_id="36" data-product_sku="" aria-label="Add &ldquo;Natural Retro Cabinet&rdquo; to your cart" rel="nofollow">Add to cart</a></p> 
 </li>
 <li>
 
 <figure>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/retro-record-player-storage/" title="Retro Record Player Storage"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/retro-storeage-record-363x337.jpg" width="363" height="337" title="retro-storeage-record" alt="retro-storeage-record"></a>
 </figure> 
 
 
 <h3>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/retro-record-player-storage/" title="Retro Record Player Storage">
 
 Retro Record Player Storage
 </a>
 </h3>
 
 <bdi>&#36;1,500.00</bdi> <p><a href="?add-to-cart=34" data-quantity="1" data-product_id="34" data-product_sku="" aria-label="Add &ldquo;Retro Record Player Storage&rdquo; to your cart" rel="nofollow">Add to cart</a></p> 
 </li>
 <li>
 
 <figure>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/dining-room-cabinet/" title="Dining Room Cabinet"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/dining-cabinet-363x337.jpg" width="363" height="337" title="dining-cabinet" alt="dining-cabinet"></a>
 </figure> 
 
 
 <h3>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/dining-room-cabinet/" title="Dining Room Cabinet">
 
 Dining Room Cabinet
 </a>
 </h3>
 
 <bdi>&#36;1,200.00</bdi> <p><a href="?add-to-cart=32" data-quantity="1" data-product_id="32" data-product_sku="" aria-label="Add &ldquo;Dining Room Cabinet&rdquo; to your cart" rel="nofollow">Add to cart</a></p> 
 </li>
 </ul>
<h2>Work From Home</h2>
<p>Give your home office a little bit of love to get you excited and motivated to work each day. Shop our vast array of collections that fits all your needs for your work-from-home setting.</p>
<img src="https://themify.me/demo/themes/pro-furniture/files/2020/07/modern-chair-a.jpg" width="200" height="200" title="Dining Room Cabinet" alt="Dining Room Cabinet">
<img src="https://themify.me/demo/themes/pro-furniture/files/2020/07/modern-chair-b.jpg" width="202" height="200" title="Dining Room Cabinet" alt="Dining Room Cabinet">
<img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/12/girl-work-from-home-933x647.jpg" width="933" height="647" title="girl-work-from-home" alt="girl-work-from-home" srcset="https://themify.me/demo/themes/shoppe-furniture/files/2020/12/girl-work-from-home.jpg 933w, https://themify.me/demo/themes/shoppe-furniture/files/2020/12/girl-work-from-home-600x416.jpg 600w, https://themify.me/demo/themes/shoppe-furniture/files/2020/12/girl-work-from-home-768x533.jpg 768w" sizes="(max-width: 933px) 100vw, 933px" />
<h2>Trends 2020</h2> <p>2020 is definitely a year of the gentle curve as we slowly move towards custom design furnitures that add more character and personality unique to each home. Take a look through our designer-curated pieces that fit you and your home. Shop from our site wide collection.</p>
<img src="https://themify.me/demo/themes/pro-furniture/files/2020/07/lamp-a.jpg" width="555" height="526" title="Dining Room Cabinet" alt="Dining Room Cabinet">
<img src="https://themify.me/demo/themes/pro-furniture/files/2020/07/lamp-b.jpg" width="555" height="526" title="Dining Room Cabinet" alt="Dining Room Cabinet">
<ul data-lazy="1">
 <li>
 
 <figure>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/wide-egio-classic/" title="Wide Egio Classic"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/wide-egio-classic-250x250.jpg" width="250" height="250" title="wide-egio-classic" alt="wide-egio-classic" srcset="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/wide-egio-classic-250x250.jpg 250w, https://themify.me/demo/themes/shoppe-furniture/files/2020/11/wide-egio-classic-300x300.jpg 300w, https://themify.me/demo/themes/shoppe-furniture/files/2020/11/wide-egio-classic-100x100.jpg 100w" sizes="(max-width: 250px) 100vw, 250px" /></a>
 </figure> 
 
 
 <h3>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/wide-egio-classic/" title="Wide Egio Classic">
 
 Wide Egio Classic
 </a>
 </h3>
 
 <bdi>&#36;200.00</bdi> <p><a href="?add-to-cart=44" data-quantity="1" data-product_id="44" data-product_sku="" aria-label="Add &ldquo;Wide Egio Classic&rdquo; to your cart" rel="nofollow">Add to cart</a></p> 
 </li>
 <li>
 
 <figure>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/round-light-pendant-70/" title="Round Light Pendant 70"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/copper-round-250x250.jpg" width="250" height="250" title="copper-round" alt="copper-round" srcset="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/copper-round-250x250.jpg 250w, https://themify.me/demo/themes/shoppe-furniture/files/2020/11/copper-round-300x300.jpg 300w, https://themify.me/demo/themes/shoppe-furniture/files/2020/11/copper-round-100x100.jpg 100w" sizes="(max-width: 250px) 100vw, 250px" /></a>
 </figure> 
 
 
 <h3>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/round-light-pendant-70/" title="Round Light Pendant 70">
 
 Round Light Pendant 70
 </a>
 </h3>
 
 <bdi>&#36;120.00</bdi> <p><a href="?add-to-cart=42" data-quantity="1" data-product_id="42" data-product_sku="" aria-label="Add &ldquo;Round Light Pendant 70&rdquo; to your cart" rel="nofollow">Add to cart</a></p> 
 </li>
 <li>
 
 <figure>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/big-barn-pendant/" title="Big Barn Pendant"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/big-barn-pendant-250x250.jpg" width="250" height="250" title="big-barn-pendant" alt="big-barn-pendant" srcset="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/big-barn-pendant-250x250.jpg 250w, https://themify.me/demo/themes/shoppe-furniture/files/2020/11/big-barn-pendant-300x300.jpg 300w, https://themify.me/demo/themes/shoppe-furniture/files/2020/11/big-barn-pendant-100x100.jpg 100w" sizes="(max-width: 250px) 100vw, 250px" /></a>
 </figure> 
 
 
 <h3>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/big-barn-pendant/" title="Big Barn Pendant">
 
 Big Barn Pendant
 </a>
 </h3>
 
 <bdi>&#36;200.00</bdi> <p><a href="?add-to-cart=40" data-quantity="1" data-product_id="40" data-product_sku="" aria-label="Add &ldquo;Big Barn Pendant&rdquo; to your cart" rel="nofollow">Add to cart</a></p> 
 </li>
 <li>
 
 <figure>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/retro-light-cone/" title="Retro Light Cone"><img loading="lazy" src="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/retro-light-cone-250x250.jpg" width="250" height="250" title="retro-light-cone" alt="retro-light-cone" srcset="https://themify.me/demo/themes/shoppe-furniture/files/2020/11/retro-light-cone-250x250.jpg 250w, https://themify.me/demo/themes/shoppe-furniture/files/2020/11/retro-light-cone-300x300.jpg 300w, https://themify.me/demo/themes/shoppe-furniture/files/2020/11/retro-light-cone-100x100.jpg 100w" sizes="(max-width: 250px) 100vw, 250px" /></a>
 </figure> 
 
 
 <h3>
 <a href="https://themify.me/demo/themes/shoppe-furniture/product/retro-light-cone/" title="Retro Light Cone">
 
 Retro Light Cone
 </a>
 </h3>
 
 <bdi>&#36;125.00</bdi> <p><a href="?add-to-cart=38" data-quantity="1" data-product_id="38" data-product_sku="" aria-label="Add &ldquo;Retro Light Cone&rdquo; to your cart" rel="nofollow">Add to cart</a></p> 
 </li>
 </ul><!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2020-12-29 04:36:50',
  'post_modified_gmt' => '2020-12-29 04:36:50',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?page_id=11',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"fups90\\",\\"cols\\":[{\\"element_id\\":\\"zgc992\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"x875549\\",\\"mod_settings\\":{\\"content_text\\":\\"<h4>New Collection<\\\\/h4>\\\\n<h2>15% Off Custom<\\\\/h2>\\\\n<p><span style=\\\\\\"font-weight: 400;\\\\\\">Save big on custom design furnitures. For a limited time only, shop our custom collection and save an extra 15% off!<\\\\/span><\\\\/p>\\",\\"padding_opp_left\\":\\"1\\",\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-type\\":\\"image\\",\\"font_size_h4_unit\\":\\"px\\",\\"font_size_h4\\":\\"14\\",\\"font_color_type_h4\\":\\"font_color_h4_solid\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"40\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"3z3x94\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View Collection\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"outline\\",\\"buttons_shape\\":\\"squared\\",\\"buttons_size\\":\\"normal\\",\\"b_p\\":\\"50,50\\",\\"b_r\\":\\"repeat\\"}}],\\"styling\\":{\\"background_color\\":\\"#ffffff_0.93\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"repeat\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_left\\":\\"2\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom\\":\\"3\\",\\"padding_right\\":\\"2\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"3\\",\\"breakpoint_mobile\\":{\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_opp_left\\":\\"1\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_opp_top\\":\\"1\\"}}},{\\"element_id\\":\\"z0r195\\",\\"grid_class\\":\\"col3-2\\"}],\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"hide_anchor\\":false,\\"row_width\\":\\"fullwidth\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"8\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"8\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-furniture\\\\/files\\\\/2020\\\\/12\\\\/hero-banner-homepage.jpg\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\"}},{\\"element_id\\":\\"k26290\\",\\"cols\\":[{\\"element_id\\":\\"b8yy97\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"lbzd97\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"612\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"520\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/pro-furniture\\\\/files\\\\/2020\\\\/07\\\\/sofa-section-image.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"25\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"},\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"motion_effects\\":{\\"v\\":{\\"val\\":{\\"v_vp\\":\\"0,100\\",\\"v_speed\\":\\"1\\",\\"v_dir\\":\\"up\\"}}}}}]},{\\"element_id\\":\\"trjo97\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"2aji98\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Sofa Collection<\\\\/h2>\\\\n<p><span style=\\\\\\"font-weight: 400;\\\\\\">Need to bring life to your living room or simply need a bit more space to lounge? Every piece is customized to fit your home. <\\\\/span><\\\\/p>\\",\\"breakpoint_tablet\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"},\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"36\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"0n4398\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View Collection\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"outline\\",\\"buttons_shape\\":\\"squared\\",\\"buttons_size\\":\\"normal\\"}},{\\"element_id\\":\\"u91t98\\",\\"cols\\":[{\\"element_id\\":\\"ijv899\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"products\\",\\"element_id\\":\\"hfq4100\\",\\"mod_settings\\":{\\"post_per_page_products\\":\\"6\\",\\"hide_page_nav_products\\":\\"yes\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"layout_products\\":\\"grid2\\",\\"hide_sales_badge\\":\\"no\\",\\"show_empty_rating\\":false,\\"hide_rating_products\\":\\"no\\",\\"hide_add_to_cart_products\\":\\"no\\",\\"hide_price_products\\":\\"no\\",\\"unlink_post_title_products\\":\\"no\\",\\"show_product_tags\\":\\"no\\",\\"show_product_categories\\":\\"no\\",\\"hide_post_title_products\\":\\"no\\",\\"unlink_feat_img_products\\":\\"no\\",\\"hide_feat_img_products\\":\\"no\\",\\"description_products\\":\\"none\\",\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"0\\",\\"tab_visible_opt_slider\\":\\"0\\",\\"visible_opt_slider\\":\\"1\\",\\"effect_slider\\":\\"scroll\\",\\"layout_slider\\":\\"slider-default\\",\\"template_products\\":\\"list\\",\\"order_products\\":\\"desc\\",\\"orderby_products\\":\\"date\\",\\"hide_outofstock_products\\":\\"no\\",\\"hide_free_products\\":\\"no\\",\\"tag_products\\":\\"0\\",\\"hide_child_products\\":\\"no\\",\\"category_products\\":\\"sofa|single\\",\\"query_type\\":\\"category\\",\\"query_products\\":\\"all\\",\\"img_height_products\\":\\"200\\",\\"img_width_products\\":\\"350\\",\\"checkbox_p_i_r_c_apply_all\\":\\"1\\",\\"p_i_r_c_opp_left\\":false,\\"p_i_r_c_opp_bottom\\":false,\\"p_i_r_c_top\\":\\"0\\",\\"p_i_b-type\\":\\"top\\"}}]}],\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_bottom\\":\\"30\\",\\"padding_top\\":26,\\"padding_opp_left\\":false,\\"padding_opp_top\\":false,\\"breakpoint_mobile\\":{\\"padding_bottom\\":0,\\"padding_bottom_unit\\":\\"px\\"},\\"padding_top_unit\\":\\"px\\"}}],\\"styling\\":{\\"breakpoint_tablet\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"},\\"breakpoint_tablet_landscape\\":{\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"},\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"}}],\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":2,\\"padding_opp_top\\":false,\\"padding_top\\":\\"6\\",\\"breakpoint_mobile\\":{\\"padding_top\\":10,\\"padding_top_unit\\":\\"%\\"}}},{\\"element_id\\":\\"e32u161\\",\\"cols\\":[{\\"element_id\\":\\"2kym162\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"bp2p163\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"auto_fullwidth\\":\\"1\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-furniture\\\\/files\\\\/2020\\\\/12\\\\/black-marble-motive.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"height_image\\":\\"512\\",\\"width_image\\":\\"800\\"}}],\\"grid_width\\":51,\\"styling\\":{\\"padding_opp_left\\":false,\\"padding_opp_top\\":\\"1\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"breakpoint_mobile\\":{\\"padding_bottom\\":0,\\"padding_bottom_unit\\":\\"%\\",\\"padding_top\\":0,\\"padding_top_unit\\":\\"%\\"},\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"border_left_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_top_style\\":\\"solid\\",\\"border-type\\":\\"top\\",\\"margin-bottom_unit\\":\\"px\\",\\"margin-top_opp_top\\":false,\\"margin-top_unit\\":\\"px\\"}},{\\"element_id\\":\\"ush2163\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"4srd163\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Retro Black Marble<\\\\/h2>\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"76\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"-15\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"70\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"breakpoint_mobile\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"35\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"5\\",\\"margin_opp_left\\":\\"1\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"5\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"5\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"},\\"breakpoint_tablet\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"40\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"breakpoint_tablet_landscape\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"60\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"h1_margin_bottom_unit\\":\\"px\\",\\"h1_margin_top_unit\\":\\"px\\",\\"t_shh1_blur_unit\\":\\"px\\",\\"t_shh1_vShadow_unit\\":\\"px\\",\\"t_shh1_hShadow_unit\\":\\"px\\",\\"letter_spacing_h1_unit\\":\\"px\\",\\"line_height_h1_unit\\":\\"px\\",\\"font_size_h1_unit\\":\\"px\\",\\"font_gradient_color_h1-circle-radial\\":false,\\"font_gradient_color_h1-gradient-angle\\":\\"180\\",\\"font_gradient_color_h1-gradient-type\\":\\"linear\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\"},\\"checkbox_margin_apply_all\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"u60r164\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><span style=\\\\\\"font-weight: 400;\\\\\\">From living room goals to kitchen and bedroom perfection, view a vast array of our retro black marble collection for that perfect accent that is sure to bring more character to your home.<\\\\/span><\\\\/p>\\",\\"padding_left\\":0,\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"0\\",\\"padding_right\\":66,\\"padding_opp_top\\":false,\\"padding_top\\":\\"10\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_left\\":80,\\"margin_left_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"breakpoint_mobile\\":{\\"margin_left\\":\\"5\\",\\"margin_left_unit\\":\\"px\\",\\"padding_right\\":\\"28\\",\\"padding_right_unit\\":\\"px\\",\\"padding_left\\":\\"28\\",\\"padding_left_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"0\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"10\\"}}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"bwhn164\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"View Collection\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"black\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"outline\\",\\"buttons_shape\\":\\"squared\\",\\"buttons_size\\":\\"normal\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"margin_left\\":80,\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"b_p\\":\\"50,50\\",\\"b_r\\":\\"repeat\\",\\"b_i-circle-radial\\":false,\\"b_i-gradient-angle\\":\\"180\\",\\"b_i-gradient-type\\":\\"linear\\",\\"b_i-type\\":\\"image\\",\\"breakpoint_mobile\\":{\\"margin_left\\":\\"28\\",\\"margin_left_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":false,\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"}}}],\\"grid_width\\":49}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"col_tablet\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"hide_anchor\\":false,\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"di9r90\\",\\"cols\\":[{\\"element_id\\":\\"kw8e102\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"t3g7102\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>New Arrivals<\\\\/h2>\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"30\\",\\"margin_opp_top\\":false,\\"breakpoint_tablet\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"40\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"},\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"font_size_h2\\":\\"36\\"}},{\\"mod_name\\":\\"products\\",\\"element_id\\":\\"6lgz102\\",\\"mod_settings\\":{\\"post_per_page_products\\":\\"6\\",\\"hide_page_nav_products\\":\\"yes\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"layout_products\\":\\"grid3\\",\\"hide_sales_badge\\":\\"no\\",\\"show_empty_rating\\":false,\\"hide_rating_products\\":\\"no\\",\\"hide_add_to_cart_products\\":\\"no\\",\\"hide_price_products\\":\\"no\\",\\"unlink_post_title_products\\":\\"no\\",\\"show_product_tags\\":\\"no\\",\\"show_product_categories\\":\\"no\\",\\"hide_post_title_products\\":\\"no\\",\\"unlink_feat_img_products\\":\\"no\\",\\"hide_feat_img_products\\":\\"no\\",\\"description_products\\":\\"none\\",\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"0\\",\\"tab_visible_opt_slider\\":\\"0\\",\\"visible_opt_slider\\":\\"1\\",\\"effect_slider\\":\\"scroll\\",\\"layout_slider\\":\\"slider-default\\",\\"template_products\\":\\"list\\",\\"order_products\\":\\"desc\\",\\"orderby_products\\":\\"date\\",\\"hide_outofstock_products\\":\\"no\\",\\"hide_free_products\\":\\"no\\",\\"tag_products\\":\\"0\\",\\"hide_child_products\\":\\"no\\",\\"category_products\\":\\"storage|single\\",\\"query_type\\":\\"category\\",\\"query_products\\":\\"all\\",\\"img_height_products\\":\\"337\\",\\"img_width_products\\":\\"363\\",\\"checkbox_p_i_r_c_apply_all\\":\\"1\\",\\"p_i_r_c_opp_left\\":false,\\"p_i_r_c_opp_bottom\\":false,\\"p_i_r_c_top\\":\\"0\\",\\"p_i_b-type\\":\\"top\\"}}]}],\\"styling\\":{\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_top\\":\\"1\\",\\"breakpoint_mobile\\":{\\"padding_bottom\\":0,\\"padding_bottom_unit\\":\\"%\\",\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false}}},{\\"element_id\\":\\"61a6306\\",\\"cols\\":[{\\"element_id\\":\\"o75d306\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ohls307\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Work From Home<\\\\/h2>\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"76\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"70\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"text_align\\":\\"right\\",\\"font_color_type\\":\\"font_color_solid\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"-15\\",\\"custom_parallax_scroll_zindex\\":\\"3\\",\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"breakpoint_mobile\\":{\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"35\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"5\\",\\"margin_opp_left\\":\\"1\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"5\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"%\\",\\"margin_top\\":\\"5\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_align\\":\\"left\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"},\\"breakpoint_tablet\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"45\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"-10\\",\\"margin_opp_left\\":\\"1\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"-10\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"},\\"breakpoint_tablet_landscape\\":{\\"h2_margin_bottom_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"t_shh2_blur_unit\\":\\"px\\",\\"t_shh2_vShadow_unit\\":\\"px\\",\\"t_shh2_hShadow_unit\\":\\"px\\",\\"letter_spacing_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"50\\",\\"font_gradient_color_h2-circle-radial\\":false,\\"font_gradient_color_h2-gradient-angle\\":\\"180\\",\\"font_gradient_color_h2-gradient-type\\":\\"linear\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\",\\"background_position\\":\\"50,50\\",\\"background_repeat\\":\\"repeat\\",\\"background_image-circle-radial\\":false,\\"background_image-gradient-angle\\":\\"180\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-type\\":\\"image\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"t_shh3_blur_unit\\":\\"px\\",\\"t_shh3_vShadow_unit\\":\\"px\\",\\"t_shh3_hShadow_unit\\":\\"px\\",\\"letter_spacing_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"font_size_h3_unit\\":\\"px\\",\\"font_size_h3\\":\\"56\\",\\"font_gradient_color_h3-circle-radial\\":false,\\"font_gradient_color_h3-gradient-angle\\":\\"180\\",\\"font_gradient_color_h3-gradient-type\\":\\"linear\\",\\"font_color_type_h3\\":\\"font_color_h3_solid\\",\\"h1_margin_bottom_unit\\":\\"px\\",\\"h1_margin_top_unit\\":\\"px\\",\\"t_shh1_blur_unit\\":\\"px\\",\\"t_shh1_vShadow_unit\\":\\"px\\",\\"t_shh1_hShadow_unit\\":\\"px\\",\\"letter_spacing_h1_unit\\":\\"px\\",\\"line_height_h1_unit\\":\\"px\\",\\"font_size_h1_unit\\":\\"px\\",\\"font_gradient_color_h1-circle-radial\\":false,\\"font_gradient_color_h1-gradient-angle\\":\\"180\\",\\"font_gradient_color_h1-gradient-type\\":\\"linear\\",\\"font_color_type_h1\\":\\"font_color_h1_solid\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"%\\",\\"margin_right\\":\\"0\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"},\\"checkbox_margin_apply_all\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_opp_left\\":false,\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"}},{\\"element_id\\":\\"ivcd307\\",\\"cols\\":[{\\"element_id\\":\\"5gtf307\\",\\"grid_class\\":\\"col2-1\\"},{\\"element_id\\":\\"7ba2307\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"rv3h307\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><span style=\\\\\\"font-weight: 400;\\\\\\">Give your home office a little bit of love to get you excited and motivated to work each day. Shop our vast array of collections that fits all your needs for your work-from-home setting.<\\\\/span><\\\\/p>\\",\\"padding_left\\":\\"0\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"0\\",\\"padding_right\\":\\"40\\",\\"padding_opp_top\\":false,\\"padding_top\\":\\"10\\",\\"margin_opp_left\\":false,\\"margin_opp_top\\":false,\\"margin_bottom\\":\\"30\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_left\\":0,\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_bottom\\":\\"10\\",\\"padding_right_unit\\":\\"px\\",\\"padding_right\\":0,\\"padding_opp_top\\":\\"1\\",\\"padding_top_unit\\":\\"px\\",\\"padding_top\\":\\"10\\"},\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_top_unit\\":\\"px\\",\\"breakpoint_tablet_landscape\\":{\\"padding_right\\":2,\\"padding_right_unit\\":\\"px\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"text_align\\":\\"right\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}}]}],\\"col_tablet_landscape\\":\\"column-full\\",\\"col_tablet\\":\\"column-full\\",\\"styling\\":{\\"breakpoint_tablet\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":\\"10\\",\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"},\\"breakpoint_tablet_landscape\\":{\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"%\\",\\"padding_left\\":4,\\"padding_opp_left\\":\\"1\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_right_unit\\":\\"%\\",\\"padding_right\\":4,\\"padding_opp_top\\":false,\\"padding_top_unit\\":\\"px\\"}}},{\\"element_id\\":\\"anvh308\\",\\"cols\\":[{\\"element_id\\":\\"tfi9308\\",\\"grid_class\\":\\"col4-1\\"},{\\"element_id\\":\\"p9m9308\\",\\"grid_class\\":\\"col4-1\\"},{\\"element_id\\":\\"47br308\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"s6ju308\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"200\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"200\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/pro-furniture\\\\/files\\\\/2020\\\\/07\\\\/modern-chair-a.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}}]},{\\"element_id\\":\\"1scz308\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"z9ug308\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"200\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"202\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/pro-furniture\\\\/files\\\\/2020\\\\/07\\\\/modern-chair-b.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-center\\"}}]}],\\"gutter\\":\\"gutter-none\\",\\"col_tablet_landscape\\":\\"column4-1\\",\\"col_mobile\\":\\"column4-2\\"}]},{\\"element_id\\":\\"mf4x309\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"4q87309\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"647\\",\\"auto_fullwidth\\":\\"1\\",\\"width_image\\":\\"933\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-furniture\\\\/files\\\\/2020\\\\/12\\\\/girl-work-from-home.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"0\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"0\\",\\"background_position\\":\\"50,50\\",\\"background_zoom\\":false,\\"background_attachment\\":\\"scroll\\",\\"background_repeat\\":\\"fullcover\\",\\"background_video_options\\":\\"mute\\",\\"background_slider_speed\\":\\"2000\\",\\"background_slider_mode\\":\\"fullcover\\",\\"background_slider_size\\":\\"large\\",\\"background_type\\":\\"image\\",\\"margin-top_opp_top\\":false,\\"breakpoint_mobile\\":{\\"padding_bottom\\":0,\\"padding_bottom_unit\\":\\"%\\",\\"padding_top\\":0,\\"padding_top_unit\\":\\"%\\"},\\"checkbox_padding_apply_all\\":false,\\"padding_left_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"background_gradient-circle-radial\\":false,\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient-type\\":\\"linear\\"}}],\\"gutter\\":\\"gutter-narrow\\",\\"col_tablet_landscape\\":\\"column4-2\\",\\"col_tablet\\":\\"column4-2\\",\\"col_mobile\\":\\"column-full\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\"}},{\\"element_id\\":\\"p2fb91\\",\\"cols\\":[{\\"element_id\\":\\"dgu9106\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"z8w5106\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Trends 2020<\\\\/h2>\\\\n<p><span style=\\\\\\"font-weight: 400;\\\\\\">2020 is definitely a year of the gentle curve as we slowly move towards custom design furnitures that add more character and personality unique to each home. Take a look through our designer-curated pieces that fit you and your home. Shop from our site wide collection.<\\\\/span><\\\\/p>\\",\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"30\\",\\"margin_opp_top\\":false,\\"font_size_h2_unit\\":\\"px\\",\\"font_size_h2\\":\\"36\\",\\"font_color_type_h2\\":\\"font_color_h2_solid\\"}},{\\"element_id\\":\\"j8dy106\\",\\"cols\\":[{\\"element_id\\":\\"e1a8106\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"t6cs107\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"526\\",\\"auto_fullwidth\\":\\"1\\",\\"width_image\\":\\"555\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/pro-furniture\\\\/files\\\\/2020\\\\/07\\\\/lamp-a.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\",\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"25\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"}}}]},{\\"element_id\\":\\"zlcg107\\",\\"grid_class\\":\\"col2-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"cni8107\\",\\"mod_settings\\":{\\"image_zoom_icon\\":false,\\"param_image\\":\\"regular\\",\\"height_image\\":\\"526\\",\\"auto_fullwidth\\":\\"1\\",\\"width_image\\":\\"555\\",\\"appearance_image\\":false,\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/pro-furniture\\\\/files\\\\/2020\\\\/07\\\\/lamp-b.jpg\\",\\"caption_on_overlay\\":false,\\"style_image\\":\\"image-top\\"}}]}],\\"col_tablet_landscape\\":\\"column4-2\\",\\"styling\\":{\\"margin_opp_left\\":false,\\"margin_bottom\\":\\"45\\",\\"margin_opp_top\\":false,\\"breakpoint_mobile\\":{\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"25\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\"}}},{\\"mod_name\\":\\"products\\",\\"element_id\\":\\"08b1108\\",\\"mod_settings\\":{\\"post_per_page_products\\":\\"4\\",\\"hide_page_nav_products\\":\\"yes\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"layout_products\\":\\"grid4\\",\\"hide_sales_badge\\":\\"no\\",\\"show_empty_rating\\":false,\\"hide_rating_products\\":\\"no\\",\\"hide_add_to_cart_products\\":\\"no\\",\\"hide_price_products\\":\\"no\\",\\"unlink_post_title_products\\":\\"no\\",\\"show_product_tags\\":\\"no\\",\\"show_product_categories\\":\\"no\\",\\"hide_post_title_products\\":\\"no\\",\\"unlink_feat_img_products\\":\\"no\\",\\"img_height_products\\":\\"250\\",\\"img_width_products\\":\\"250\\",\\"hide_feat_img_products\\":\\"no\\",\\"description_products\\":\\"none\\",\\"height_slider\\":\\"variable\\",\\"show_arrow_buttons_vertical\\":false,\\"show_arrow_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"wrap_slider\\":\\"yes\\",\\"play_pause_control\\":\\"no\\",\\"speed_opt_slider\\":\\"normal\\",\\"scroll_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"1\\",\\"mob_visible_opt_slider\\":\\"0\\",\\"tab_visible_opt_slider\\":\\"0\\",\\"visible_opt_slider\\":\\"1\\",\\"effect_slider\\":\\"scroll\\",\\"layout_slider\\":\\"slider-default\\",\\"template_products\\":\\"list\\",\\"order_products\\":\\"desc\\",\\"orderby_products\\":\\"date\\",\\"hide_outofstock_products\\":\\"no\\",\\"hide_free_products\\":\\"no\\",\\"tag_products\\":\\"0\\",\\"hide_child_products\\":\\"no\\",\\"category_products\\":\\"lamp|single\\",\\"query_type\\":\\"category\\",\\"query_products\\":\\"all\\",\\"checkbox_p_i_r_c_apply_all\\":\\"1\\",\\"p_i_r_c_opp_left\\":false,\\"p_i_r_c_opp_bottom\\":false,\\"p_i_r_c_top\\":\\"0\\",\\"p_i_b-type\\":\\"top\\"}}]}],\\"styling\\":{\\"padding_bottom_unit\\":\\"%\\",\\"padding_top_unit\\":\\"%\\",\\"padding_opp_left\\":false,\\"padding_bottom\\":\\"6\\",\\"padding_opp_top\\":\\"1\\",\\"padding_top\\":\\"6\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 9,
  'post_date' => '2020-11-26 09:49:08',
  'post_date_gmt' => '2020-11-26 09:49:08',
  'post_content' => '',
  'post_title' => 'Wishlist',
  'post_excerpt' => '',
  'post_name' => 'wishlist',
  'post_modified' => '2020-11-26 09:49:08',
  'post_modified_gmt' => '2020-11-26 09:49:08',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/wishlist/',
  'menu_order' => 0,
  'post_type' => 'page',
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 68,
  'post_date' => '2020-12-19 00:51:20',
  'post_date_gmt' => '2020-12-19 00:51:20',
  'post_content' => '',
  'post_title' => 'Optin Form',
  'post_excerpt' => '',
  'post_name' => 'optin-form',
  'post_modified' => '2020-12-19 00:52:47',
  'post_modified_gmt' => '2020-12-19 00:52:47',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=tbuilder_layout_part&#038;p=68',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout_part',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"addq42\\",\\"cols\\":[{\\"element_id\\":\\"sp9n42\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"optin\\",\\"element_id\\":\\"aq2v160\\",\\"mod_settings\\":{\\"label_firstname\\":\\"First Name\\",\\"default_fname\\":\\"John\\",\\"label_lastname\\":\\"Last Name\\",\\"default_lname\\":\\"Doe\\",\\"message\\":\\"<p>Post updated. <a href=\\\\\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/ultra-agency2\\\\/tbuilder-layout-part\\\\/optin-form\\\\/\\\\\\">View post<\\\\/a><\\\\/p>\\\\n<p><button class=\\\\\\"notice-dismiss\\\\\\" type=\\\\\\"button\\\\\\"><span class=\\\\\\"screen-reader-text\\\\\\">Dismiss this notice.<\\\\/span><\\\\/button><\\\\/p>\\",\\"layout\\":\\"tb_optin_horizontal\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"success_action\\":\\"s2\\",\\"lname_hide\\":\\"1\\",\\"fname_hide\\":\\"1\\",\\"mailchimp_list\\":\\"0f2a95e5de\\",\\"provider\\":\\"mailchimp\\",\\"button_icon\\":\\"ti-email\\",\\"b_in_top_style\\":\\"none\\",\\"b_in-type\\":\\"bottom\\",\\"b_in_left_style\\":\\"none\\",\\"b_in_right_style\\":\\"none\\",\\"p_in_opp_left\\":false,\\"p_in_opp_top\\":\\"1\\",\\"p_sb_opp_left\\":false,\\"p_sb_opp_top\\":false,\\"p_in_bottom\\":\\"14\\",\\"p_in_top\\":\\"14\\",\\"bg_c_s\\":\\"#ffffff\\",\\"b_in_bottom_width\\":\\"1\\",\\"b_in_bottom_color\\":\\"#000000\\",\\"m_sb_opp_left\\":false,\\"m_sb_opp_top\\":false,\\"p_sb_left\\":\\"0\\",\\"p_sb_right\\":\\"0\\",\\"b_sh_sb_inset\\":false,\\"r_c_sb_opp_left\\":false,\\"r_c_sb_opp_bottom\\":false,\\"b_s-type\\":\\"top\\",\\"f_c_s\\":\\"#000000\\"}}]}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 52,
  'post_date' => '2020-11-29 05:34:44',
  'post_date_gmt' => '2020-11-29 05:34:44',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae',
  'post_title' => 'Capella Mid Century',
  'post_excerpt' => 'Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat',
  'post_name' => 'capella-mid-century',
  'post_modified' => '2020-12-19 05:57:54',
  'post_modified_gmt' => '2020-12-19 05:57:54',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=product&#038;p=52',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1608357336:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_regular_price' => '700',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.8.0',
    '_price' => '700',
    '_thumbnail_id' => '91',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"yogp308\\",\\"cols\\":[{\\"element_id\\":\\"wp4s309\\",\\"grid_class\\":\\"col-full\\"}]}]',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'sofa',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-furniture/files/2020/11/capella-mid-century.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 50,
  'post_date' => '2020-11-29 05:33:49',
  'post_date_gmt' => '2020-11-29 05:33:49',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore,',
  'post_title' => 'Karlstad Leather Sofa',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'karlstad-leather-sofa',
  'post_modified' => '2020-12-19 05:57:44',
  'post_modified_gmt' => '2020-12-19 05:57:44',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=product&#038;p=50',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1608357324:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_regular_price' => '1000',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.8.0',
    '_price' => '1000',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"nfbl273\\",\\"cols\\":[{\\"element_id\\":\\"ddbg337\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_thumbnail_id' => '92',
    '_wp_old_slug' => 'karlstad-two-seater',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'sofa',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-furniture/files/2020/11/karlstaad-sofa-leather.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 48,
  'post_date' => '2020-11-29 05:32:26',
  'post_date_gmt' => '2020-11-29 05:32:26',
  'post_content' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Capella Leather Gala',
  'post_excerpt' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_name' => 'capella-leather-gala',
  'post_modified' => '2020-12-19 05:57:18',
  'post_modified_gmt' => '2020-12-19 05:57:18',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=product&#038;p=48',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1608357298:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_regular_price' => '1100',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.8.0',
    '_price' => '1100',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"j8fr732\\",\\"cols\\":[{\\"element_id\\":\\"vcfm734\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_thumbnail_id' => '93',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'sofa',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-furniture/files/2020/11/capella-leather-gala.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 46,
  'post_date' => '2020-11-29 05:28:26',
  'post_date_gmt' => '2020-11-29 05:28:26',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore.',
  'post_title' => 'Giorgetti Leather Sofa',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
',
  'post_name' => 'giorgetti-leather-sofa',
  'post_modified' => '2020-12-19 05:56:51',
  'post_modified_gmt' => '2020-12-19 05:56:51',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=product&#038;p=46',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1608357279:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_regular_price' => '700',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.8.0',
    '_price' => '700',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"575u755\\",\\"cols\\":[{\\"element_id\\":\\"yapg782\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_thumbnail_id' => '94',
    '_wp_old_slug' => 'capella-ottoman',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'sofa',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-furniture/files/2020/11/giorgetti-leather-sofa.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 44,
  'post_date' => '2020-11-29 05:25:36',
  'post_date_gmt' => '2020-11-29 05:25:36',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore,
',
  'post_title' => 'Wide Egio Classic',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt',
  'post_name' => 'wide-egio-classic',
  'post_modified' => '2020-12-19 05:56:25',
  'post_modified_gmt' => '2020-12-19 05:56:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=product&#038;p=44',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1608357280:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_regular_price' => '200',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.8.0',
    '_price' => '200',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"wlu0797\\",\\"cols\\":[{\\"element_id\\":\\"c875799\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_thumbnail_id' => '95',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'lamp',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-furniture/files/2020/11/wide-egio-classic.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 42,
  'post_date' => '2020-11-29 05:24:15',
  'post_date_gmt' => '2020-11-29 05:24:15',
  'post_content' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Round Light Pendant 70',
  'post_excerpt' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
',
  'post_name' => 'round-light-pendant-70',
  'post_modified' => '2020-12-19 05:56:21',
  'post_modified_gmt' => '2020-12-19 05:56:21',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=product&#038;p=42',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1608357281:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_regular_price' => '120',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.8.0',
    '_price' => '120',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"f8h1526\\",\\"cols\\":[{\\"element_id\\":\\"dxhv527\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_thumbnail_id' => '96',
    '_wp_old_slug' => 'vintage-light-pendant-70',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'lamp',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-furniture/files/2020/11/copper-round.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 40,
  'post_date' => '2020-11-29 04:29:49',
  'post_date_gmt' => '2020-11-29 04:29:49',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
',
  'post_title' => 'Big Barn Pendant',
  'post_excerpt' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore.',
  'post_name' => 'big-barn-pendant',
  'post_modified' => '2020-12-19 05:56:10',
  'post_modified_gmt' => '2020-12-19 05:56:10',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=product&#038;p=40',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1608357282:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_regular_price' => '200',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.8.0',
    '_price' => '200',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"o0e0523\\",\\"cols\\":[{\\"element_id\\":\\"gbrv524\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_thumbnail_id' => '97',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'lamp',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-furniture/files/2020/11/big-barn-pendant.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 38,
  'post_date' => '2020-11-29 04:23:50',
  'post_date_gmt' => '2020-11-29 04:23:50',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae',
  'post_title' => 'Retro Light Cone',
  'post_excerpt' => 'Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat',
  'post_name' => 'retro-light-cone',
  'post_modified' => '2020-12-19 05:56:04',
  'post_modified_gmt' => '2020-12-19 05:56:04',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=product&#038;p=38',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1608357283:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_regular_price' => '125',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.8.0',
    '_price' => '125',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"ntue520\\",\\"cols\\":[{\\"element_id\\":\\"bg9l525\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_thumbnail_id' => '98',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'lamp',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-furniture/files/2020/11/retro-light-cone.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 36,
  'post_date' => '2020-11-29 04:20:09',
  'post_date_gmt' => '2020-11-29 04:20:09',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae',
  'post_title' => 'Natural Retro Cabinet',
  'post_excerpt' => 'Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat',
  'post_name' => 'natural-retro-cabinet',
  'post_modified' => '2020-12-19 05:55:57',
  'post_modified_gmt' => '2020-12-19 05:55:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=product&#038;p=36',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1608357283:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_regular_price' => '1000',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.8.0',
    '_price' => '1000',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"a6o1387\\",\\"cols\\":[{\\"element_id\\":\\"dq24389\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_thumbnail_id' => '99',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'storage',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-furniture/files/2020/11/natural-retro-cabinet.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 34,
  'post_date' => '2020-11-29 04:19:27',
  'post_date_gmt' => '2020-11-29 04:19:27',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore,',
  'post_title' => 'Retro Record Player Storage',
  'post_excerpt' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
  'post_name' => 'retro-record-player-storage',
  'post_modified' => '2020-12-19 05:55:53',
  'post_modified_gmt' => '2020-12-19 05:55:53',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=product&#038;p=34',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1608357284:172',
    '_edit_last' => '172',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_regular_price' => '1500',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.8.0',
    '_price' => '1500',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"e9j2452\\",\\"cols\\":[{\\"element_id\\":\\"cf7u454\\",\\"grid_class\\":\\"col-full\\"}]}]',
    '_thumbnail_id' => '100',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'storage',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-furniture/files/2020/11/retro-storeage-record.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 32,
  'post_date' => '2020-11-29 04:14:51',
  'post_date_gmt' => '2020-11-29 04:14:51',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni',
  'post_title' => 'Dining Room Cabinet',
  'post_excerpt' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_name' => 'dining-room-cabinet',
  'post_modified' => '2021-01-13 01:16:41',
  'post_modified_gmt' => '2021-01-13 01:16:41',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?post_type=product&#038;p=32',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1610500465:2',
    '_edit_last' => '2',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
    'content_width' => 'default_width',
    '_regular_price' => '1200',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock_status' => 'instock',
    '_wc_average_rating' => '0',
    '_wc_review_count' => '0',
    '_product_version' => '4.8.0',
    '_price' => '1200',
    '_thumbnail_id' => '112',
    '_wp_old_slug' => 'retro-shoes-cabinet',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"um2z692\\",\\"cols\\":[{\\"element_id\\":\\"49gk693\\",\\"grid_class\\":\\"col-full\\"}]}]',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
    'product_cat' => 'storage',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-furniture/files/2020/11/classic-dresser.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 13,
  'post_date' => '2020-11-27 04:52:11',
  'post_date_gmt' => '2020-11-27 04:52:11',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '13',
  'post_modified' => '2020-12-19 04:00:52',
  'post_modified_gmt' => '2020-12-19 04:00:52',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?p=13',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '11',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 87,
  'post_date' => '2020-12-19 04:00:36',
  'post_date_gmt' => '2020-12-19 04:00:36',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '87',
  'post_modified' => '2020-12-19 04:00:52',
  'post_modified_gmt' => '2020-12-19 04:00:52',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?p=87',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '19',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 14,
  'post_date' => '2020-11-27 04:52:11',
  'post_date_gmt' => '2020-11-27 04:52:11',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '14',
  'post_modified' => '2020-12-19 04:00:52',
  'post_modified_gmt' => '2020-12-19 04:00:52',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?p=14',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => 'shop',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 29,
  'post_date' => '2020-11-29 03:28:47',
  'post_date_gmt' => '2020-11-29 03:28:47',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '29',
  'post_modified' => '2020-12-19 04:00:52',
  'post_modified_gmt' => '2020-12-19 04:00:52',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-furniture/?p=29',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '21',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_text" );
$widgets[1002] = array (
  'title' => 'About',
  'text' => '<a href="https://themify.me/">Our company</a>

<a href="https://themify.me/">Our story</a>

<a href="https://themify.me/">Store events</a>

<a href="https://themify.me/">Careers</a>',
  'filter' => true,
  'visual' => true,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1003] = array (
  'title' => 'Customer Support',
  'text' => '<a href="https://themify.me/">Customer Service</a>

<a href="https://themify.me/">Contact Us</a>

<a href="https://themify.me/">FAQs</a>

<a href="https://themify.me/">Shipping &amp; Delivery</a>',
  'filter' => true,
  'visual' => true,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1004] = array (
  'title' => 'Get Help',
  'text' => '<a href="https://themify.me/">Live Chat</a>

<a href="https://themify.me/">1-855-415-9227</a>

<a href="https://themify.me/">customercare@website.com</a>',
  'filter' => true,
  'visual' => true,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_themify-layout-parts" );
$widgets[1005] = array (
  'title' => 'Stay Update',
  'layout_part' => 'optin-form',
);
update_option( "widget_themify-layout-parts", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1006] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_search" );
$widgets[1007] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1008] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1009] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1010] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1011] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1012] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );



$sidebars_widgets = array (
  'footer-widget-1' => 
  array (
    0 => 'text-1002',
  ),
  'footer-widget-2' => 
  array (
    0 => 'text-1003',
  ),
  'footer-widget-3' => 
  array (
    0 => 'text-1004',
  ),
  'footer-widget-4' => 
  array (
    0 => 'themify-layout-parts-1005',
    1 => 'themify-social-links-1006',
  ),
  'sidebar-main' => 
  array (
    0 => 'search-1007',
    1 => 'recent-posts-1008',
    2 => 'recent-comments-1009',
  ),
  'sidebar-shop' => 
  array (
    0 => 'archives-1010',
    1 => 'categories-1011',
    2 => 'meta-1012',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-search_post_type' => 'all',
  'setting-webfonts_list' => 'recommended',
  'setting-customizer_responsive_design_tablet_landscape' => '1024',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '480',
  'setting-mobile_menu_trigger_point' => '900',
  'setting-header_design' => 'header-logo-center',
  'setting-exclude_search_button' => 'on',
  'setting-footer_design' => 'footer-block',
  'setting-exclude_footer_site_logo' => 'on',
  'setting-footer_widgets' => 'footerwidget-4col',
  'setting-footer_widget_position' => 'top',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-imagefilter_applyto' => 'featuredonly',
  'setting-more_posts' => 'infinite',
  'setting-entries_nav' => 'numbered',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-lazy-blur' => '25',
  'setting-cache-live' => '10080',
  'setting-webp-quality' => '5',
  'setting-default_layout' => 'sidebar1',
  'setting-default_post_layout' => 'list-post',
  'setting-post_masonry' => 'yes',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar1',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-search-result_layout' => 'sidebar1',
  'setting-search-result_post_layout' => 'list-post',
  'setting-search-result_layout_display' => 'excerpt',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar1',
  'setting-shop_layout' => 'sidebar-none',
  'setting-shop_content_width' => 'default_width',
  'setting-shop_archive_layout' => 'sidebar-none',
  'setting-custom_post_product_archive_content_width' => 'default_width',
  'setting-products_layout' => 'grid4',
  'setting-product_post_gutter' => 'gutter',
  'setting-products_slider' => 'enable',
  'setting-single_product_layout' => 'sidebar-none',
  'setting-custom_post_product_single_content_width' => 'default_width',
  'setting-related_products_limit' => '3',
  'setting-product_description_type' => 'long',
  'setting-wishlist_page' => '9',
  'setting-cart_style' => 'dropdown',
  'setting-cart_show_seconds' => 'off',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/shoppe-furniture/wp-content/themes/themify-shoppe/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/shoppe-furniture/wp-content/themes/themify-shoppe/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'YouTube',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/shoppe-furniture/wp-content/themes/themify-shoppe/themify/img/social/youtube.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'Pinterest',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/shoppe-furniture/wp-content/themes/themify-shoppe/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Facebook',
  'setting-link_link_themify-link-5' => 'https://www.facebook.com/themify',
  'setting-link_ficon_themify-link-5' => 'fa-facebook',
  'setting-link_type_themify-link-4' => 'font-icon',
  'setting-link_title_themify-link-4' => 'Twitter',
  'setting-link_link_themify-link-4' => 'https://www.twitter.com/themify',
  'setting-link_ficon_themify-link-4' => 'fa-twitter',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'YouTube',
  'setting-link_link_themify-link-6' => 'https://www.youtube.com/user/themifyme',
  'setting-link_ficon_themify-link-6' => 'fa-youtube',
  'setting-link_type_themify-link-7' => 'font-icon',
  'setting-link_title_themify-link-7' => 'Pinterest',
  'setting-link_link_themify-link-7' => 'https://www.linkedin.com/company/themify/',
  'setting-link_ficon_themify-link-7' => 'ti-linkedin',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-5":"themify-link-5","themify-link-4":"themify-link-4","themify-link-6":"themify-link-6","themify-link-7":"themify-link-7"}',
  'setting-link_field_hash' => '8',
  'setting-twitter_settings_cache' => '10',
  'setting-recaptcha_version' => 'v2',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_gallery_lightbox' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'skin' => 'furniture',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'custom_css_post_id' => -1,
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
